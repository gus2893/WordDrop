// VersionInfo.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Globalization;
using System.Text;

#pragma warning disable 429
#pragma warning disable 162
// ReSharper disable UnreachableCode
// ReSharper disable ConditionIsAlwaysTrueOrFalse
namespace Thinksquirrel.WordGameBuilder.Internal
{
    /// <summary>
    ///     Contains Word Game Builder version information.
    /// </summary>
    public static class VersionInfo
    {
        /// <summary>
        ///     Gets the current version of Word Game Builder.
        /// </summary>
        public const string version = "2.0.1f2";

        /// <summary>
        ///     Whether or not the current Word Game Builder build is a pre-release build.
        /// </summary>
        public static bool isPreRelease
        {
            get { return !version.Contains("f"); }
        }
        /// <summary>
        ///     Whether or not this build of Word Game Builder is the pro edition.
        /// </summary>
        public const bool isProEdition =
#if WGB_PRO
            true;
#else
            false;
#endif
        /// <summary>
        ///     Whether or not this build of Word Game Builder is the standard edition.
        /// </summary>
        public const bool isStandardEdition =
#if WGB_STANDARD
            true;
#else
            false;
#endif
        /// <summary>
        ///     Gets the current Word Game Builder license, in human-readable form.
        /// </summary>
        public static string license
        {
            get
            {
                return isProEdition ? "Word Game Builder Pro" : "Word Game Builder";
            }
        }
        public static string copyright
        {
            get { return "(c) 2011-2016 Thinksquirrel Inc."; }
        }
    }
}
