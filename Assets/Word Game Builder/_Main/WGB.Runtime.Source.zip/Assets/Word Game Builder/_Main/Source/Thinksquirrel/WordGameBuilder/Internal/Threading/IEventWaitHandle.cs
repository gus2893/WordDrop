// IThreadPool.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilder.Internal.Threading
{       
    public interface IEventWaitHandle
    {
        bool WaitOne();
        bool WaitOne(TimeSpan timeout);
        bool WaitOne(int millisecondsTimeout);
        bool Set();
        bool Reset();
        void Close();
    }
}
//! \endcond
