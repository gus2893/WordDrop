﻿// LetterTileUIInput.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEngine;
using UnityEngine.EventSystems;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilder.Internal;

//! This namespace contains letter tile helper classes for Unity UI.
namespace Thinksquirrel.WordGameBuilder.Tiles.UI
{
    /// <summary>
    /// Adds input control to a letter tile, using Unity UI's pointer events.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile.
    /// </remarks>
    [RequireComponent(typeof(ILetterTileInput))]
    [AddComponentMenu("Word Game Builder/Tiles/Unity UI/Letter Tile UI Input")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.UI.LetterTileUIInput")]
    public sealed class LetterTileUIInput : WGBBase, IPointerDownHandler, IPointerUpHandler, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
    {
        ILetterTileInput m_LetterTile;

        void OnEnable()
        {
            m_LetterTile = GetComponentFromInterface<ILetterTileInput>();
        }

        #region Event system implementation
        void IPointerDownHandler.OnPointerDown(PointerEventData data)
        {
            DoOnPress(true);
        }
        void IPointerUpHandler.OnPointerUp(PointerEventData data)
        {
            DoOnPress(false);
        }
        void IPointerEnterHandler.OnPointerEnter(PointerEventData data)
        {
            DoOnHover(true);
        }
        void IPointerExitHandler.OnPointerExit(PointerEventData data)
        {
            DoOnHover(false);
        }
        void IPointerClickHandler.OnPointerClick(PointerEventData data)
        {
            DoOnClick();
        }
        #endregion

        #region Private methods
        void DoOnPress(bool isPressed)
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulatePressInput(isPressed);
            }
        }
        void DoOnHover(bool isOver)
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulateHoverInput(isOver);
            }
        }
        void DoOnClick()
        {
            if (m_LetterTile != null && m_LetterTile.isActive && m_LetterTile.enabled)
            {
                m_LetterTile.SimulateClickInput();
            }
        }
        #endregion
    }
}
