// IWildcardTileManager.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining a manager for selecting wildcard tiles. Implementations must derive from MonoBehaviour in some form.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. However, it is recommended to use the WildcardTileManager class instead.
    /// </remarks>
    public interface IWildcardTileManager : IMonoBehaviour
    {
        /// <summary>
        /// This event fires when a blank tile is selected.
        /// </summary>
        WGBEvent onWildcardTileSelect { get; set; }
        /// <summary>
        /// Selects the specified tile as a wildcard with the specified language and player.
        /// </summary>
        /// <param name='tile'>The tile to use for wildcard selection.</param>
        /// <param name='lang'>The language to use for wildcard selection.</param>
        /// <param name='player'>The player to use for wildcard selection.</param>
        void SelectWildcardTile(ILetterTile tile, WordGameLanguage lang, IWordGamePlayer player);
    }
}
