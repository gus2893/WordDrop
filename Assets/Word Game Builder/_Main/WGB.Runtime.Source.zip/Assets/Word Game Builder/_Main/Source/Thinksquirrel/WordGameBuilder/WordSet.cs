// WordSet.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.IO;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.Internal;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// A specialized data structure for storing letters and words.
    /// </summary>
    /// <remarks>
    /// The WordSet is a highly optimized structure for fast word searches. It is loaded in a compressed form, and must be decompressed before lookup operations will work.
    /// </remarks>
    [System.Serializable]
    public sealed class WordSet : ScriptableObject
    {
        /// <summary>
        /// The maximum length of a prefix in the word set's internal representation.
        /// </summary>
        /// <remarks>
        /// This value is implementation-specific and cannot be changed.
        /// </remarks>
        public const int k_MaxPrefixLength = 5;

        [SerializeField] [HideInInspector] WordGameLanguage m_Language;
        [SerializeField] [HideInInspector] int m_Count;

        [System.NonSerialized] string[] m_Prefixes = new string[0];
        [System.NonSerialized] int[] m_PrefixToSuffixLength = new int[0];
        [System.NonSerialized] string[] m_Suffixes = new string[0];
        [System.NonSerialized] int[] m_PrefixToSuffix = new int[0];

        [System.NonSerialized] Letter[] m_CachedLetters;
        [System.NonSerialized] bool m_IsExpanded;
        [System.NonSerialized] bool m_IsExpanding;

        [System.NonSerialized] SortedDictionary<string, HashSet<string>> m_OptimizeSet;
        [System.NonSerialized] SortedDictionary<string, string[]> m_WorkingSet; // TODO: Working set should be created as a new object (or else it will get sorted on *every* insert)
        [System.NonSerialized] List<string> m_RuntimeSet;
        [System.NonSerialized] List<string> m_InsertedSet;
        [System.NonSerialized] List<string> m_RemovedSet;

        [System.NonSerialized] LanguageAwareStringComparer m_Comparer;

        readonly object m_SyncLock = new object();

        internal IList<string> GetWords()
        {
            var words = new List<string>();
            int offset = 0;
            bool caseSensitive = m_Language.caseSensitive;
            m_Language.caseSensitive = false;
            for (var i = 0; i < m_Prefixes.Length; ++i)
            {
                var len = m_PrefixToSuffixLength [i];
                var end = offset + len;

                for(var j = offset; j < end; ++j)
                {
                    var wrd = m_Prefixes[i] + m_Suffixes[m_PrefixToSuffix[j]];

                    if (m_RemovedSet.BinarySearch(wrd, m_Comparer) < 0)
                    {
                        words.Add(wrd);
                    }
                }
                offset += len;
            }
            words.AddRange(m_InsertedSet);
            words.AddRange(m_RuntimeSet);
            words.Sort(m_Comparer);
            m_Language.caseSensitive = caseSensitive;
            if (words.Count != m_PrefixToSuffix.Length + m_InsertedSet.Count + m_RuntimeSet.Count - m_RemovedSet.Count)
            {
                Debug.LogError("words.Count != m_PrefixToSuffix.Length + m_InsertedSet.Count + m_RuntimeSet.Count - m_RemovedSet.Count");
            }
            return words;
        }

        internal string GetRandomWord(System.Random random)
        {
            var prefix = m_WorkingSet.Keys.GetRandomElement<string>(random);
            return prefix + m_WorkingSet [prefix].GetRandomElement(random);
        }

        /// <summary>
        /// Gets the amount of words in the word set.
        /// </summary>
        public int wordCount
        {
            get
            {
                return m_Count;
            }
        }

        /// <summary>
        /// Whether or not the word set is expanded in memory.
        /// </summary>
        public bool isExpanded
        {
            get
            {
                return m_IsExpanded;
            }
        }

        internal void Initialize(WordGameLanguage language)
        {
            m_Language = language;
            name = language.identifier + " - Word Set";
            hideFlags = HideFlags.HideInInspector | HideFlags.HideInHierarchy;
            m_Comparer = new LanguageAwareStringComparer(language);
            m_OptimizeSet = new SortedDictionary<string, HashSet<string>>(m_Comparer);
            m_WorkingSet = new SortedDictionary<string, string[]>(m_Comparer);
            m_RuntimeSet = new List<string>();
            m_InsertedSet = new List<string>();
            m_RemovedSet = new List<string>();
            m_CachedLetters = language.letters.ToArray();
        }

        /// <summary>
        /// Optimizes a word set for fast searches. This may take a while and should be done offline - not at runtime.
        /// </summary>
        public void Optimize()
        {
            DoOptimize(null, true);
        }

        internal void DoOptimize(List<string> words, bool append)
        {
            m_CachedLetters = m_Language.letters.ToArray();

            if (append)
            {
                if (words == null)
                    words = GetWords() as List<string>;
                else
                    words.AddRange(GetWords());
            }

            // Sort words
            bool caseSensitive = m_Language.caseSensitive;
            m_Language.caseSensitive = false;
            words.Sort(m_Comparer);
            m_Language.caseSensitive = caseSensitive;

            // Clear all sets
            m_OptimizeSet.Clear();
            m_WorkingSet.Clear();
            m_RuntimeSet.Clear();
            m_RemovedSet.Clear();
            m_InsertedSet.Clear();

            // Initialize optimization
            var iter = 0;
            var c = words.Count;
            var cF = (float)c;
            var skippedCount = 0;

            // Insert words into the optimize set
            for (int k = 0; k < c; ++k)
            {
                var word = words[k];
                if (!OptimizeInsert(word))
                {
                    skippedCount++;
                }
                if (iter % 5000 == 0)
                {
                    UnityEditorBinding.RunStatic("EditorUtility.DisplayProgressBar", string.Format("{0}: Optimizing", m_Language.languageName), word, iter / cF);
                }
                iter++;
            }

            // Warn about skipped words
            m_Count = c - skippedCount;

            if (skippedCount > 0)
                WGBBase.LogWarning(string.Format("{0} - {1} duplicate or invalid {2} skipped", m_Language.languageName, skippedCount, skippedCount > 1 ? "words" : "word"), "Word Game Builder", "WordSet", m_Language);

            UnityEditorBinding.RunStatic("EditorUtility.DisplayProgressBar", string.Format("{0}: Optimizing", m_Language.languageName), "Creating objects...", 1.0f);

            // Create arrays
            if (m_Count == 0)
            {
                m_Prefixes = new string[0];
                m_PrefixToSuffix = new int[0];
                m_PrefixToSuffixLength = new int[0];
            }
            else
            {
                m_Language.caseSensitive = true;

                var prefixes = new List<string>(m_OptimizeSet.Keys);
                m_Prefixes = prefixes.ToArray();
                System.Array.Sort<string>(m_Prefixes, m_Comparer);

                int prefixCount = m_Prefixes.Length;

                var suffixes = new HashSet<string>(m_Comparer);
                for (var e = m_OptimizeSet.GetEnumerator(); e.MoveNext();)
                {
                    var kvp = e.Current;
                    var val = kvp.Value;

                    for (var j = val.GetEnumerator(); j.MoveNext();)
                    {
                        suffixes.Add(j.Current);
                    }
                }

                m_Suffixes = suffixes.ToArray();
                System.Array.Sort<string>(m_Suffixes, m_Comparer);

                m_PrefixToSuffixLength = new int[prefixCount];

                var prefixToSuffix = new List<int>();

                int i = 0;
                for (var e = m_OptimizeSet.Values.GetEnumerator(); e.MoveNext();)
                {
                    var val = e.Current;
                    int len = val.Count;

                    m_PrefixToSuffixLength [i] = len;

                    int start = prefixToSuffix.Count;

                    for (var j = val.GetEnumerator(); j.MoveNext();)
                    {
                        prefixToSuffix.Add(System.Array.BinarySearch<string>(m_Suffixes, j.Current, m_Comparer));
                    }

                    prefixToSuffix.Sort(start, len, null);

                    ++i;
                }

                m_PrefixToSuffix = prefixToSuffix.ToArray();

                m_Language.caseSensitive = caseSensitive;
            }

            // Clear progress bar
            UnityEditorBinding.RunStatic("EditorUtility.ClearProgressBar");
            // Mark as dirty
            UnityEditorBinding.RunStatic("EditorUtility.SetDirty", new []{ m_Language });

            // Create working set
            DecompressInternal(null, int.MaxValue);
            m_IsExpanded = true;
        }

        /// <summary>
        /// Expands the set from compressed form.
        /// </summary>
        /// <remarks>
        /// If Language.decompressOnLoad is disabled, this must be called explicitly.
        /// </remarks>
        public void Decompress()
        {
            if (!m_IsExpanded)
            {
                // Load CSV resources
                DeserializeArrays();
                DecompressInternal(null, int.MaxValue);
                m_IsExpanded = true;
            }
        }

        /// <summary>
        /// Expands the set from compressed form. Yields when progress is updated and can be used in a coroutine.
        /// </summary>
        /// <param name='progressCallback'>
        /// The method to call each time the task's progress is updated. This method must take a float as the only argument.
        /// </param>
        /// <param name='iterationsPerFrame'>
        /// The maximum amount of iterations to process per frame. Defaults to 100.
        /// </param>
        /// <returns>An IEnumerator object. This method can be used as a coroutine.</returns>
        /// <remarks>
        /// If Language.decompressOnLoad is disabled, this must be called explicitly.
        /// </remarks>
        public IEnumerator Decompress(System.Action<float> progressCallback, int iterationsPerFrame = 100)
        {
            if (progressCallback != null)
            {
                progressCallback(0);
            }
            yield return null;

            // Load CSV resources
            DeserializeArrays();

            if (progressCallback != null)
            {
                progressCallback(.25f);
            }
            yield return null;

            if (!m_IsExpanded)
            {
                m_WorkingSet.Clear();
                int k = 0, l = m_Prefixes.Length;

                bool caseSensitive = m_Language.caseSensitive;
                m_Language.caseSensitive = true;
                var offset = 0;
                for (var i = 0; i < l; ++i)
                {
                    var key = m_Prefixes [i];
                    var len = m_PrefixToSuffixLength [i];

                    var workingVal = new string[len];

                    for (var j = 0; j < len; ++j)
                    {
                        workingVal [j] = m_Suffixes [m_PrefixToSuffix [offset + j]];
                    }

                    offset += len;

                    m_WorkingSet.Add(key, workingVal);

                    // Update progress
                    if (k % iterationsPerFrame == 0)
                    {
                        if (progressCallback != null)
                        {
                            progressCallback(.25f + ((k / (float)l) * .75f));
                        }
                        yield return null;
                    }
                    ++k;
                }
                m_Language.caseSensitive = caseSensitive;

                m_IsExpanded = true;
            }
        }

        void DecompressInternal(System.Action<float> progressCallback, int iterationsPerFrame = 100)
        {
            if (progressCallback != null) AsyncTask.Dispatch(() => progressCallback(.25f));

            m_WorkingSet.Clear();
            int k = 0, l = m_Prefixes.Length;

            var caseSensitive = m_Language.caseSensitive;
            m_Language.caseSensitive = true;
            var offset = 0;
            for (var i = 0; i < l; ++i)
            {
                var key = m_Prefixes [i];
                var len = m_PrefixToSuffixLength [i];

                var workingVal = new string[len];

                for (int j = 0; j < len; ++j)
                {
                    workingVal [j] = m_Suffixes [m_PrefixToSuffix [offset + j]];
                }

                offset += len;

                m_WorkingSet.Add(key, workingVal);

                // Update progress
                if (k % iterationsPerFrame == 0)
                {
                    var progress = k;
                    if (progressCallback != null)
                    {
                        AsyncTask.Dispatch(() =>
                        {
                            progressCallback(.25f + ((progress / (float)l) * .75f));
                        });
                    }
                }
                ++k;
            }
            m_Language.caseSensitive = caseSensitive;
        }
        Stream StringToStream(string s)
        {
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;
            return stream;
        }
        void DeserializeArrays()
        {
            try
            {
                var prefixes = new List<string>();
                var prefixToSuffixLength = new List<int>();
                var suffixes = new List<string>();
                var prefixToSuffix = new List<int>();

                var pathBase = string.Format("{0}/{1}", WordGameLanguage.k_ResourceFolder, m_Language.identifier);
                var prefixesAsset = Resources.Load(string.Format("{0}/{1}", pathBase, "prefixes"), typeof(TextAsset)) as TextAsset;
                var prefixToSuffixLengthAsset = Resources.Load(string.Format("{0}/{1}", pathBase, "prefixToSuffixLength"), typeof(TextAsset)) as TextAsset;
                var suffixesAsset = Resources.Load(string.Format("{0}/{1}", pathBase, "suffixes"), typeof(TextAsset)) as TextAsset;
                var prefixToSuffixAsset = Resources.Load(string.Format("{0}/{1}", pathBase, "prefixToSuffix"), typeof(TextAsset)) as TextAsset;

                // If the assets haven't been created yet, exit early
                if (!prefixesAsset || !prefixToSuffixLengthAsset || !suffixesAsset || !prefixToSuffixAsset)
                    return;

                var prefixesStream = StringToStream(prefixesAsset.text);
                var prefixToSuffixLengthStream = StringToStream(prefixToSuffixLengthAsset.text);
                var suffixesStream = StringToStream(suffixesAsset.text);
                var prefixToSuffixStream = StringToStream(prefixToSuffixAsset.text);

                // prefixes
                using (var csv = new CsvReader(prefixesStream))
                {
                    string[] fields;

                    while ((fields = csv.GetCsvLine()) != null)
                    {
                        for (int i = 0; i < fields.Length; i++)
                        {
                            string field = fields[i];
                            prefixes.Add(field);
                        }
                    }
                }

                // prefixToSuffixLength
                using (var csv = new CsvReader(prefixToSuffixLengthStream))
                {
                    string[] fields;

                    while ((fields = csv.GetCsvLine()) != null)
                    {
                        for (int i = 0; i < fields.Length; i++)
                        {
                            string field = fields[i];
                            prefixToSuffixLength.Add(int.Parse(field));
                        }
                    }
                }

                // suffixes
                using (var csv = new CsvReader(suffixesStream))
                {
                    string[] fields;

                    while ((fields = csv.GetCsvLine()) != null)
                    {
                        for (int i = 0; i < fields.Length; i++)
                        {
                            string field = fields[i];
                            suffixes.Add(field);
                        }
                    }
                }

                // prefixToSuffix
                using (var csv = new CsvReader(prefixToSuffixStream))
                {
                    string[] fields;

                    while ((fields = csv.GetCsvLine()) != null)
                    {
                        for (int i = 0; i < fields.Length; i++)
                        {
                            string field = fields[i];
                            prefixToSuffix.Add(int.Parse(field));
                        }
                    }
                }

                // Assign values
                m_Prefixes = prefixes.ToArray();
                m_PrefixToSuffixLength = prefixToSuffixLength.ToArray();
                m_Suffixes = suffixes.ToArray();
                m_PrefixToSuffix = prefixToSuffix.ToArray();
            }
            catch (System.Exception e)
            {
                WGBBase.LogException(e, this);
                WGBBase.LogError("Unable to parse word set!", "Word Game Builder", "WordSet", this);
            }
        }

        internal void SerializeArrays(Stream prefixesStream, Stream prefixToSuffixLengthStream, Stream suffixesStream, Stream prefixToSuffixStream)
        {
            try
            {
                // prefixes
                using (var csv = new CsvWriter(prefixesStream))
                {
                    csv.WriteFields(m_Prefixes);
                }
                
                // prefixToSuffixLength
                using (var csv = new CsvWriter(prefixToSuffixLengthStream))
                {
                    csv.WriteFields(m_PrefixToSuffixLength.Select(x => x.ToString()).ToArray());
                }
                
                // suffixes
                using (var csv = new CsvWriter(suffixesStream))
                {
                    csv.WriteFields(m_Suffixes);
                }
               
                // prefixToSuffix
                using (var csv = new CsvWriter(prefixToSuffixStream))
                {
                    csv.WriteFields(m_PrefixToSuffix.Select(x => x.ToString()).ToArray());
                }
            }
            catch (System.Exception e)
            {
                WGBBase.LogException(e, this);
                WGBBase.LogError("Unable to serialize word set!", "Word Game Builder", "WordSet", this);
            }
        }

        /// <summary>
        /// Expands the set from compressed form asynchronously.
        /// </summary>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        /// <remarks>
        /// If Language.decompressOnLoad is disabled, this must be called explicitly.
        /// </remarks>
        public AsyncTask DecompressAsync()
        {
            return DecompressAsync(null);
        }

        /// <summary>
        /// Expands the set from compressed form asynchronously.
        /// </summary>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        /// <param name='callback'>
        /// The method to call upon completion.
        /// </param>
        /// <remarks>
        /// If Language.decompressOnLoad is disabled, this must be called explicitly.
        /// </remarks>
        public AsyncTask DecompressAsync(System.Action callback)
        {
            // Load CSV resources
            DeserializeArrays();

            return AsyncTask.Create(task =>
            {
                lock (m_SyncLock)
                {
                    if (!m_IsExpanded && !m_IsExpanding)
                    {
                        m_IsExpanding = true;
                        DecompressInternal(null, int.MaxValue);
                        m_IsExpanded = true;
                        if (callback != null)
                        {
                            AsyncTask.Dispatch(callback);
                        }
                    }
                }
            });
        }

        /// <summary>
        /// Expands the set from compressed form asynchronously.
        /// </summary>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        /// <param name='callback'>
        /// The method to call upon completion.
        /// </param>
        /// <param name='progressCallback'>
        /// The method to call each time the task's progress is updated. This method must take a float as the only argument.
        /// </param>
        /// <param name='iterationsPerFrame'>
        /// The amount of iterations per progress frame.
        /// </param>
        /// <remarks>
        /// If Language.decompressOnLoad is disabled, this must be called explicitly.
        /// </remarks>
        public AsyncTask DecompressAsync(System.Action callback, System.Action<float> progressCallback, int iterationsPerFrame = 100)
        {
            // Load CSV resources
            DeserializeArrays();

            return AsyncTask.Create(task =>
            {
                lock (m_SyncLock)
                {
                    if (!m_IsExpanded && !m_IsExpanding)
                    {
                        m_IsExpanding = true;
                        DecompressInternal(progressCallback, iterationsPerFrame);
                        m_IsExpanded = true;

                        if (callback != null)
                        {
                            AsyncTask.Dispatch(callback);
                        }
                    }
                }
            });
        }

        /// <summary>
        /// Compress the set into compressed form to save memory. Also clears the runtime set.
        /// </summary>
        /// <remarks>
        /// The word set cannot be used in compressed form.
        /// </remarks>
        public void CollapseSet()
        {
            m_WorkingSet.Clear();
            m_RuntimeSet.Clear();
            m_Prefixes = new string[0];
            m_PrefixToSuffixLength = new int[0];
            m_Suffixes = new string[0];
            m_PrefixToSuffix = new int[0];
            m_IsExpanded = false;
            m_IsExpanding = false;
        }

        /// <summary>
        /// Inserts a word into the set.
        /// </summary>
        /// <param name = "word">The word to insert into the set.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        public bool Insert(string word)
        {
            if (string.IsNullOrEmpty(word))
                return false;

            string prefix = GetPrefix(word);
            string suffix = GetSuffix(word, prefix);

            if (prefix == null)
                return false;

            string[] values;
            int i = m_RemovedSet.BinarySearch(word, m_Comparer);

            if (i >= 0)
            {
                m_RemovedSet.RemoveAt(i);
                m_InsertedSet.Add(word);
                AddWord(prefix, suffix, true);
                var caseSensitive = m_Language.caseSensitive;
                m_Language.caseSensitive = true;
                m_InsertedSet.Sort(m_Comparer);
                m_Language.caseSensitive = caseSensitive;
                return true;
            }

            if (m_WorkingSet.TryGetValue(prefix, out values))
            {
                i = System.Array.BinarySearch<string>(values, suffix, m_Comparer);

                if (i < 0)
                {
                    m_InsertedSet.Add(word);
                    var caseSensitive = m_Language.caseSensitive;
                    m_Language.caseSensitive = true;
                    AddWord(prefix, suffix, true);
                    m_InsertedSet.Sort(m_Comparer);
                    m_Language.caseSensitive = caseSensitive;
                    return true;
                }
            }
            else
            {
                m_InsertedSet.Add(word);
                var caseSensitive = m_Language.caseSensitive;
                m_Language.caseSensitive = true;
                AddWord(prefix, suffix, true);
                m_InsertedSet.Sort(m_Comparer);
                m_Language.caseSensitive = caseSensitive;
                return true;
            }

            return false;
        }

        bool OptimizeInsert(string word)
        {
            if (string.IsNullOrEmpty(word))
                return false;

            bool caseSensitive = m_Language.caseSensitive;
            m_Language.caseSensitive = true;

            // Get the prefix and suffix of the word
            string prefix = GetPrefix(word);
            string suffix = GetSuffix(word, prefix);

            if (prefix == null)
                return false;

            var result = OptimizeAddWord(prefix, suffix, true);

            m_Language.caseSensitive = caseSensitive;

            return result;
        }

        /// <summary>
        /// Inserts an enumerable of words into the set.
        /// </summary>
        /// <param name="words">The words to insert.</param>
        public void InsertRange(IEnumerable<string> words)
        {
            bool caseSensitive = m_Language.caseSensitive;

            for (var i = words.GetEnumerator(); i.MoveNext();)
            {
                var word = i.Current;

                m_Language.caseSensitive = false;

                if (Contains(word))
                    continue;

                // Get the prefix and suffix of the word
                string prefix = GetPrefix(word);
                string suffix = GetSuffix(word, prefix);

                m_Language.caseSensitive = true;

                AddWord(prefix, suffix, false);
            }

            if (Application.isPlaying)
                m_RuntimeSet.Sort(m_Comparer);

            m_Language.caseSensitive = caseSensitive;
        }

        bool AddWord(string prefix, string suffix, bool runtimeSort)
        {
            if (prefix == null)
                return false;

            if (Application.isPlaying)
            {
                var word = prefix + suffix;

                // Validation
                for (int i = 0; i < word.Length; ++i)
                {
                    bool match = false;
                    for (int j = 0, letterCount = m_CachedLetters.Length; j < letterCount; ++j)
                    {
                        var letter = m_CachedLetters[j];
                        if (m_Language.culture.TextInfo.ToUpper(suffix [i]) == m_Language.culture.TextInfo.ToUpper(letter.character)) // Always case-insensitive
                        {
                            match = true;
                            break;
                        }
                    }
                    if (!match)
                        return false;
                }

                m_RuntimeSet.Add(word);
                if (runtimeSort) m_RuntimeSet.Sort(m_Comparer);
                return true;
            }

            // Validation
            for (int i = 0; i < suffix.Length; ++i)
            {
                bool match = false;
                for (int j = 0, letterCount = m_CachedLetters.Length; j < letterCount; ++j)
                {
                    var letter = m_CachedLetters [j];
                    if (m_Language.culture.TextInfo.ToUpper(suffix [i]) == m_Language.culture.TextInfo.ToUpper(letter.character)) // Always case-insensitive
                    {
                        match = true;
                        break;
                    }
                }
                if (!match)
                    return false;
            }

            string[] suffixes;
            if (!m_WorkingSet.ContainsKey(prefix))
            {
                // Create a new prefix
                suffixes = new[] { suffix };
                m_WorkingSet.Add(prefix, suffixes);
            }
            else
            {
                suffixes = m_WorkingSet [prefix];
                suffixes = AddItem(suffixes, suffix);
                System.Array.Sort<string>(suffixes, m_Comparer);
                m_WorkingSet [prefix] = suffixes;
            }

            return true;
        }
        bool OptimizeAddWord(string prefix, string suffix, bool runtimeSort)
        {
            if (prefix == null)
                return false;

            // Validation
            for (int i = 0; i < suffix.Length; ++i)
            {
                bool match = false;
                for (int j = 0, letterCount = m_CachedLetters.Length; j < letterCount; ++j)
                {
                    var letter = m_CachedLetters [j];
                    if (m_Language.culture.TextInfo.ToUpper(suffix [i]) == m_Language.culture.TextInfo.ToUpper(letter.character)) // Always case-insensitive
                    {
                        match = true;
                        break;
                    }
                }
                if (!match)
                    return false;
            }

            HashSet<string> suffixes;
            if (!m_OptimizeSet.ContainsKey(prefix))
            {
                // Create a new prefix
                suffixes = new HashSet<string>(m_Comparer);
                m_OptimizeSet.Add(prefix, suffixes);
            }
            else
            {
                suffixes = m_OptimizeSet [prefix];
            }

            if (!suffixes.Add(suffix))
            {
                return false;
            }
            return true;
        }

        string GetPrefix(string word)
        {
            int l = word.Length;
            var wordChars = word.ToCharArray();
            var prefixChars = new char[k_MaxPrefixLength];
            int prefixPointer = 0;

            int i = 0;
            int letterCount = m_CachedLetters.Length;
            bool done = false;
            while (i < letterCount && prefixPointer < l && !done)
            {
                for (int j = 0; j < letterCount; j++)
                {
                    var letter = m_CachedLetters[j];
                    if (prefixPointer > 4 || prefixPointer > l / 2)
                    {
                        done = true;
                        break;
                    }
                    if (m_Comparer.Equals(wordChars[prefixPointer], letter.character))
                    {
                        i = 0;
                        prefixChars [prefixPointer] = wordChars [prefixPointer++];
                    }
                }
                i++;
            }

            return i >= letterCount ? null : new string(prefixChars).TrimEnd('\0');
        }

        string GetSuffix(string word, string prefix)
        {
            return prefix == null ? null : word.Substring(prefix.Length);
        }

        static IEnumerable<string> Permute(string word, int maxIterations, int i)
        {
            if (i <= maxIterations)
            {
                if (word.Length > 1)
                {
                    char character = word [0];
                    for (var j = Permute(word.Substring(1), maxIterations, ++i).GetEnumerator(); j.MoveNext();)
                    {
                        var subPermute = j.Current;

                        for (int k = 0; k <= subPermute.Length; k++)
                        {
                            string pre = subPermute.Substring(0, k);
                            string post = subPermute.Substring(k);

                            if (post.Contains(character.ToString()))
                                continue;

                            yield return pre + character + post;
                        }

                    }
                }
                else
                {
                    yield return word;
                }
            }
        }

        /// <summary>
        /// Returns true if the word set contains a word.
        /// </summary>
        /// <remarks>
        /// Search operations in the word set use the underlying dictionary strings, unlike the WordChecker class (which uses letter tiles).
        /// </remarks>
        /// <param name = "word">The word to search for.</param>
        /// <returns><c>true</c> if the word was found, otherwise <c>false</c>.</returns>
        public bool Contains(string word)
        {
            if (!isExpanded)
                return false;

            if (string.IsNullOrEmpty(word))
                return false;

            string prefix = GetPrefix(word);
            string suffix = GetSuffix(word, prefix);

            if (prefix == null)
                return false;

            string[] values;

            if (m_WorkingSet.TryGetValue(prefix, out values))
            {
                return System.Array.BinarySearch<string>(values, suffix, m_Comparer) >= 0;
            }
            return m_RuntimeSet.BinarySearch(word, m_Comparer) >= 0;
        }

        /// <summary>
        /// Returns the amount of words that starts with the specified prefix.
        /// </summary>
        /// <remarks>
        /// Accepts a pre-allocated list (should be empty) to use for calculations.
        /// </remarks>
        /// <param name = "prefix">The prefix to search for.</param>
        /// <param name = "maxWordLength">The maximum allowed word length.</param>
        /// <param name = "maxIterations">The maximum amount of iterations to perform.</param>
        /// <param name = "stringList">A scratch list for prefix calculations.</param>
        /// <returns>The amount of words found.</returns>
        public int Contains(string prefix, int maxWordLength, int maxIterations, IList<string> stringList)
        {
            if (string.IsNullOrEmpty(prefix))
                return 0;

            int c = 0;
            stringList.Clear();

            // Add letters until a prefix is found, checking every letter added.
            string initial = prefix;
            int i = 0;
            int p = 0;
            AddLettersRecursively(initial, stringList, maxWordLength, maxIterations, ref i, ref p, ref c);

            return c;
        }

        internal WordResult FindWordInternal(string word, bool ordered, int maxWordLength, int maxIterations, AsyncTask task)
        {
            if (task != null)
            {
                if (task.shouldAbort)
                {
                    return WordResult.empty;
                }
            }
            string input = word;
            if (word.Length > maxWordLength)
            {
                WGBBase.LogWarning(string.Format("Over maximum word length - trimming word to {0} characters.", maxWordLength), "Word Game Builder", "WordSet", m_Language);
                word = word.Substring(0, maxWordLength);
            }
            if (ordered)
            {
                if (Contains(word))
                {
                    return new WordResult(word, word, new [] { word }, true, true);
                }
            }
            else
            {
                var permutations = Permute(word, maxIterations, 0);
                var allWords = new List<string>();

                for (var i = permutations.GetEnumerator(); i.MoveNext();)
                {
                    var wrd = i.Current;

                    if (task != null)
                    {
                        if (task.shouldAbort)
                        {
                            break;
                        }
                    }
                    if (Contains(wrd))
                    {
                        allWords.Add(wrd);
                    }
                }

                if (allWords.Count > 0)
                {
                    return new WordResult(input, allWords [0], allWords, true, false);
                }
            }

            return WordResult.empty;
        }

        /// <summary>
        /// Finds the word in the set.
        /// </summary>
        /// <returns>
        /// A WordResult representing the results of the lookup operation.
        /// </returns>
        /// <param name='word'>
        /// The string input for the lookup operation.
        /// </param>
        /// <param name='ordered'>
        /// If true, performs a check on the string, in order. If false, performs a permutation check on every combination of the string.
        /// </param>
        /// <remarks>
        /// Search operations in the word set use the underlying dictionary strings, unlike the WordChecker class, which uses letter tiles.
        /// </remarks>
        public WordResult FindWord(string word, bool ordered)
        {
            return FindWordInternal(word, ordered, 10000, 10000, null);
        }

        /// <summary>
        /// Finds the word in the set.
        /// </summary>
        /// <returns>
        /// A WordResult representing the results of the lookup operation.
        /// </returns>
        /// <param name='word'>
        /// The string input for the lookup operation.
        /// </param>
        /// <param name='ordered'>
        /// If true, performs a check on the string, in order. If false, performs a permutation check on every combination of the string.
        /// </param>
        /// <param name='maxWordLength'>
        /// The maximum length of a word input. If the input is longer than this value, it will be truncated.
        /// </param>
        /// <param name='maxIterations'>
        /// The maximum amount of iterations for any permutation checks.
        /// </param>
        /// <remarks>
        /// Search operations in the word set use the underlying dictionary strings, unlike the WordChecker class, which uses letter tiles.
        /// </remarks>
        public WordResult FindWord(string word, bool ordered, int maxWordLength, int maxIterations)
        {
            return FindWordInternal(word, ordered, maxWordLength, maxIterations, null);
        }

        /// <summary>
        /// Finds the word in the set, asynchronously.
        /// </summary>
        /// <returns>
        /// An Task representing the asynchronous task.
        /// </returns>
        /// <param name='word'>
        /// The string input for the lookup operation.
        /// </param>
        /// <param name='ordered'>
        /// If true, performs a check on the string, in order. If false, performs a permutation check on every combination of the string.
        /// </param>
        /// <param name='callback'>
        /// The method to call upon completion. This method must take a WordResult as the only argument.
        /// </param>
        /// <remarks>
        /// Search operations in the word set use the underlying dictionary strings, unlike the WordChecker class, which uses letter tiles.
        /// </remarks>
        public AsyncTask FindWordAsync(string word, bool ordered, System.Action<WordResult> callback)
        {
            return FindWordAsync(word, ordered, 10000, 10000, callback);
        }

        /// <summary>
        /// Finds the word in the set, asynchronously.
        /// </summary>
        /// <returns>
        /// An Task representing the asynchronous task.
        /// </returns>
        /// <param name='word'>
        /// The string input for the lookup operation.
        /// </param>
        /// <param name='ordered'>
        /// If true, performs a check on the string, in order. If false, performs a permutation check on every combination of the string.
        /// </param>
        /// <param name='maxWordLength'>
        /// The maximum length of a word input. If the input is longer than this value, it will be truncated.
        /// </param>
        /// <param name='maxIterations'>
        /// The maximum amount of iterations for any permutation checks.
        /// </param>
        /// <param name='callback'>
        /// The method to call upon completion. This method must take a WordResult as the only argument.
        /// </param>
        /// <remarks>
        /// Search operations in the word set use the underlying dictionary strings, unlike the WordChecker class, which uses letter tiles.
        /// </remarks>
        public AsyncTask FindWordAsync(string word, bool ordered, int maxWordLength, int maxIterations, System.Action<WordResult> callback)
        {
            AsyncTask t = AsyncTask.Create(task =>
            {
                WordResult result = FindWordInternal(word, ordered, maxWordLength, maxIterations, task);

                AsyncTask.Dispatch(() => callback(result));
            });

            return t;
        }

        /// <summary>
        /// Returns all words that begin with a prefix, up to maxIterations. Returns Wordresult.empty if no words are found.
        /// </summary>
        /// <param name='prefix'>
        /// The prefix to search.
        /// </param>
        /// <param name='maxWordLength'>
        /// The maximum allowed word length.
        /// </param>
        /// <param name='maxIterations'>
        /// The maximum amount of iterations allowed.
        /// </param>
        /// <returns>
        /// A WordResult representing the results of the lookup operation.
        /// </returns>
        public WordResult FindWords(string prefix, int maxWordLength, int maxIterations)
        {
            if (string.IsNullOrEmpty(prefix))
                return WordResult.empty;

            // Add letters until a prefix is found, checking every letter added.
            string initial = prefix;
            var stringList = new List<string>(maxIterations);
            var finalList = new List<string>(maxIterations);
            int i = 0;
            int p = 0;
            AddLettersRecursively(initial, stringList, finalList, maxWordLength, maxIterations, ref i, ref p);

            return finalList.Count > 0 ? new WordResult(prefix, finalList[0], finalList, true, false) : WordResult.empty;
        }

        /// <summary>
        /// Asynchronously returns all words that begin with a prefix, up to maxIterations.
        /// </summary>
        /// <returns>
        /// An Task representing the asynchronous task.
        /// </returns>
        /// <param name='prefix'>
        /// The prefix to search.
        /// </param>
        /// <param name='maxWordLength'>
        /// The maximum allowed word length.
        /// </param>
        /// <param name='maxIterations'>
        /// The maximum amount of iterations allowed.
        /// </param>
        /// <param name='callback'>
        /// The method to call upon completion. This method must take a WordResult as the only argument.
        /// </param>
        public AsyncTask FindWordsAsync(string prefix, int maxWordLength, int maxIterations, System.Action<WordResult> callback)
        {
            return AsyncTask.Create(task =>
            {
                var result = FindWords(prefix, maxWordLength, maxIterations);

                AsyncTask.Dispatch(() => callback(result));
            });
        }

        void AddLettersRecursively(string prefix, IList<string> stringList, List<string> finalList, int maxWordLength, int maxIterations, ref int i, ref int p)
        {
            if (i >= maxIterations)
            {
                return;
            }

            stringList.Add(prefix);

            if (prefix.Length < maxWordLength)
            {
                m_CachedLetters.Shuffle(m_Language.GetRandomNumberGenerator());

                // Add more words to the stringList - one for every letter
                for (int j = 0; j < m_CachedLetters.Length; j++)
                {
                    var l = m_CachedLetters[j];
                    stringList.Add(prefix + l.character);
                }
            }

            while (p < stringList.Count)
            {
                if (i >= maxIterations)
                {
                    return;
                }

                string str = stringList [p];

                if (str.Length <= k_MaxPrefixLength)
                {
                    string[] values;
                    // Word is a prefix, break early with the whole bucket (guaranteed words from here on out)
                    if (m_WorkingSet.TryGetValue(str, out values))
                    {
                        for (int j = 0; j < values.Length; ++j)
                        {
                            var s = values[j];
                            finalList.Add(str + s);
                        }
                        i++;
                        p++;
                        break;
                    }
                }

                // Word is in the dictionary, add it to the final list
                if (Contains(str))
                {
                    finalList.Add(str);
                }

                // Increase iterations and the pointer into the stringList
                i++;
                p++;
            }

            if (prefix.Length < maxWordLength)
            {
                m_CachedLetters.Shuffle(m_Language.GetRandomNumberGenerator());

                // Do it again! This algorithm has terrible worst case performance, but great real-world performance with short prefixes
                for (int j = 0; j < m_CachedLetters.Length; j++)
                {
                    var l = m_CachedLetters[j];
                    if (i >= maxIterations)
                    {
                        return;
                    }
                    AddLettersRecursively(prefix + l.character, stringList, finalList, maxWordLength, maxIterations, ref i, ref p);
                }
            }

        }

        void AddLettersRecursively(string prefix, IList<string> stringList, int maxWordLength, int maxIterations, ref int i, ref int p, ref int c)
        {
            if (i >= maxIterations)
            {
                return;
            }

            stringList.Add(prefix);

            if (prefix.Length < maxWordLength)
            {
                m_CachedLetters.Shuffle(m_Language.GetRandomNumberGenerator());

                // Add more words to the stringList - one for every letter
                for (int j = 0; j < m_CachedLetters.Length; j++)
                {
                    var l = m_CachedLetters[j];
                    stringList.Add(prefix + l.character);
                }
            }

            while (p < stringList.Count)
            {
                if (i >= maxIterations)
                {
                    return;
                }

                string str = stringList [p];

                if (str.Length <= k_MaxPrefixLength)
                {
                    string[] values;
                    // Word is a prefix, break early with the whole bucket (guaranteed words from here on out)
                    if (m_WorkingSet.TryGetValue(str, out values))
                    {
                        c += values.Length;
                        i++;
                        p++;
                        break;
                    }
                }

                // Word is in the dictionary, add it to the final list
                if (Contains(str))
                {
                    c++;
                }

                // Increase iterations and the pointer into the stringList
                i++;
                p++;
            }

            if (prefix.Length < maxWordLength)
            {
                m_CachedLetters.Shuffle(m_Language.GetRandomNumberGenerator());

                // Do it again! This algorithm has terrible worst case performance, but great real-world performance with short prefixes
                for (int j = 0; j < m_CachedLetters.Length; j++)
                {
                    var l = m_CachedLetters[j];
                    if (i >= maxIterations)
                    {
                        return;
                    }
                    AddLettersRecursively(prefix + l.character, stringList, maxWordLength, maxIterations, ref i, ref p, ref c);
                }
            }

        }

        /// <summary>
        /// Removes a word from the set.
        /// </summary>
        /// <param name="word">The word to remove.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        public bool Remove(string word)
        {
            if (string.IsNullOrEmpty(word))
                return false;

            string prefix = GetPrefix(word);
            string suffix = GetSuffix(word, prefix);

            if (prefix == null)
                return false;

            string[] values;
            int i;

            if (m_RemovedSet.BinarySearch(word, m_Comparer) < 0)
            {
                if (m_WorkingSet.TryGetValue(prefix, out values))
                {
                    i = System.Array.BinarySearch<string>(values, suffix, m_Comparer);

                    if (i >= 0)
                    {
                        m_WorkingSet[prefix] = RemoveItem<string>(values, i);
                        m_RemovedSet.Add(word);
                        var caseSensitive = m_Language.caseSensitive;
                        m_Language.caseSensitive = true;
                        m_RemovedSet.Sort(m_Comparer);
                        m_Language.caseSensitive = caseSensitive;
                        return true;
                    }
                }

                i = m_RuntimeSet.BinarySearch(word, m_Comparer);
                if (i >= 0)
                {
                    m_RuntimeSet.RemoveAt(i);
                    m_RemovedSet.Add(word);
                    var caseSensitive = m_Language.caseSensitive;
                    m_Language.caseSensitive = true;
                    m_RemovedSet.Sort(m_Comparer);
                    m_Language.caseSensitive = caseSensitive;
                    return true;
                }
            }

            return false;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        static T[] RemoveItem<T>(T[] source, int index)
        {
            T[] dest = new T[source.Length - 1];
            if( index > 0 )
                System.Array.Copy(source, 0, dest, 0, index);

            if( index < source.Length - 1 )
                System.Array.Copy(source, index + 1, dest, index, source.Length - index - 1);

            return dest;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        static T[] AddItem<T>(T[] source, T item)
        {
            int i = source.Length;
            T[] dest = new T[i + 1];
            System.Array.Copy(source, dest, i);
            dest[i] = item;

            return dest;
        }
    }

    //! \cond PRIVATE
    // String comparer
    class LanguageAwareStringComparer : IComparer<string>, IEqualityComparer<string>, IComparer<char>, IEqualityComparer<char>
    {
        readonly WordGameLanguage m_Language;

        public LanguageAwareStringComparer(WordGameLanguage language)
        {
            m_Language = language;
        }

        #region IComparer implementation

        public int Compare(string x, string y)
        {
            return m_Language.caseSensitive ? string.Compare(x, y, System.StringComparison.Ordinal) : m_Language.culture.CompareInfo.Compare(x, y, CompareOptions.OrdinalIgnoreCase);
        }

        public int Compare(char x, char y)
        {
            return m_Language.caseSensitive ? x.CompareTo(y) : m_Language.culture.TextInfo.ToUpper(x).CompareTo(m_Language.culture.TextInfo.ToUpper(y));
        }

        #endregion

        #region IEqualityComparer implementation

        public bool Equals(string x, string y)
        {
            return Compare(x, y) == 0;
        }

        public bool Equals(char x, char y)
        {

            return Compare(x, y) == 0;
        }

        public int GetHashCode(string obj)
        {
            return m_Language.caseSensitive ? obj.GetHashCode() : m_Language.culture.TextInfo.ToUpper(obj).GetHashCode();
        }

        public int GetHashCode(char obj)
        {
            return m_Language.caseSensitive ? obj.GetHashCode() : m_Language.culture.TextInfo.ToUpper(obj).GetHashCode();
        }

        #endregion
    }
    //! \endcond
}
