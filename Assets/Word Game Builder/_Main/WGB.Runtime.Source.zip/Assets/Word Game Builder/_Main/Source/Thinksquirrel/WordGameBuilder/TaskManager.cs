﻿// TaskManager.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Provides methods for dealing with asynchronous tasks.
    /// </summary>
    public static class TaskManager
    {
        /// <summary>
        /// Get all currently active tasks.
        /// </summary>
        /// <remarks>
        /// When enumerating through tasks, it is still recommended to check their status, as they may have finished during enumeration.
        /// </remarks>
        /// <returns>An enumerable with all active tasks.</returns>
        public static IEnumerable<AsyncTask> GetActiveTasks()
        {
            return AsyncTask._activeTasks;
        }

        /// <summary>
        /// Abort all currently running asynchronous tasks.
        /// </summary>
        public static void AbortAllTasks()
        {
            foreach (var task in AsyncTask._activeTasks)
            {
                task.Abort();
            }
        }

        /// <summary>
        /// Abort all currently running asynchronous tasks and wait for completion.
        /// </summary>
        public static void AbortAllTasksAndWait()
        {
            foreach (var task in AsyncTask._activeTasks)
            {
                task.AbortWait();
            }
        }
    }
}
