﻿// ILetterTileInput.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining letter tile input events.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. It is recommended to use the LetterTile class instead.
    /// </remarks>
    public interface ILetterTileInput : ILetterTile
    {
        /// <summary>
        /// Simulates a tile press action from user input.
        /// </summary>
        /// <param name='isPressed'>If <c>true</c>, the tile has just been pressed down. If <c>false</c>, the tile has just been released.</param>
        void SimulatePressInput(bool isPressed);
        /// <summary>
        /// Simulates a tile click action from user input.
        /// </summary>
        void SimulateClickInput();
        /// <summary>
        /// Simulates a tile hover action from user input.
        /// </summary>
        /// <param name='isOver'>If <c>true</c>, the user has started hovering over the tile. If <c>false</c>, the tile is no longer being hovered over.</param>
        void SimulateHoverInput(bool isOver);
    }
}
