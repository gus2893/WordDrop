﻿// Graph.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections;
using System.Collections.Generic;

namespace Thinksquirrel.WordGameBuilder.Internal
{
    sealed class Node<T>
    {
        bool m_Enabled = true;
        NodeList<T> m_Neighbors;
        List<float> m_Costs;
        T m_Value;
        
        public bool enabled
        {
            get
            {
                return m_Enabled;
            }
        }
        public NodeList<T> neighbors
        {
            get
            {
                if (m_Neighbors == null)
                    m_Neighbors = new NodeList<T>();
                
                return m_Neighbors;
            }
        }
        
        public IList<float> costs
        {
            get
            {
                if (m_Costs == null)
                    m_Costs = new List<float>();
                
                return m_Costs;
            }
        }
        public T value
        {
            get
            {
                return m_Value;
            }
            set
            {
                m_Value = value;
            }
        }

        public void ClearNeighbors()
        {
            if (m_Neighbors != null)
                m_Neighbors.Clear();
        }

        public Node() : this(default(T), null, true) {}
        public Node(T value) : this(value, null, true) {}
        public Node(T value, bool enabled) : this(value, null, enabled) {}
        public Node(T value, NodeList<T> neighbors) : this(value, neighbors, true) {}
        public Node(T value, NodeList<T> neighbors, bool enabled)
        {
            this.m_Value = value;
            this.m_Neighbors = neighbors;
            this.m_Enabled = enabled;
        }
        
        public void Toggle(bool toggle)
        {
            m_Enabled = toggle;
        }
        
    }
    sealed class NodeList<T> : List<Node<T>>, IList<T>
    {
        public NodeList() { }
        
        public NodeList(int initialSize)
        {
            for (int i = 0; i < initialSize; i++)
                base.Add(default(Node<T>));
        }
        
        public Node<T> FindByValue(T value)
        {
            for(int i = 0; i < Count; ++i)
            {
                var node = this[i];
                if (node.value.Equals(value))
                    return node;
            }
            
            return null;
        }

        #region IList implementation

        int IList<T>.IndexOf(T item)
        {
            var node = FindByValue(item);
            return node == null ? -1 : IndexOf(node);
        }

        void IList<T>.Insert(int index, T item)
        {
            var node = new Node<T>(item);
            Insert(index, node);
        }

        T IList<T>.this[int index]
        {
            get
            {
                return this[index].value;
            }
            set
            {
                this[index].value = value;
            }
        }

        #endregion

        #region ICollection implementation

        void ICollection<T>.Add(T item)
        {
            var node = new Node<T>(item);
            Add(node);
        }

        bool ICollection<T>.Contains(T item)
        {
            return FindByValue(item) != null;
        }

        void ICollection<T>.CopyTo(T[] array, int arrayIndex)
        {
            if (array == null)
                throw new System.ArgumentNullException("array");
            if (arrayIndex < 0)
                throw new System.ArgumentOutOfRangeException("arrayIndex");
            if (Count > array.Length - arrayIndex)
                throw new System.ArgumentException();

            for(int i = 0; i < array.Length - arrayIndex; ++i)
            {
                array[i + arrayIndex] = this[i].value;
            }
        }

        bool ICollection<T>.Remove(T item)
        {
            var node = FindByValue(item);

            return node != null && Remove(node);
        }

        bool ICollection<T>.IsReadOnly
        {
            get { return false; }
        }

        #endregion

        #region IEnumerable implementation

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            for (int i = 0; i < Count; ++i)
                yield return this[i] == null ? default(T) : this[i].value;
        }

        #endregion

        #region IEnumerable implementation

        IEnumerator IEnumerable.GetEnumerator()
        {
            for (int i = 0; i < Count; ++i)
                yield return this[i] == null ? default(T) : this[i].value;
        }

        #endregion
    }
    sealed class Graph<T> : IList<T>
    {
        ObjectPool<Node<T>> m_NodePool;

        bool m_Changed;
        
        public bool changed
        {
            get
            {
                return m_Changed;
            }
        }
        public delegate void GraphChangeDelegate();
        public event GraphChangeDelegate onGraphChange;
        
        public void PushGraphChange()
        {
            if (m_Changed)
            {
                if (onGraphChange != null)
                {
                    onGraphChange();
                }
                m_Changed = false;
            }
        }
        
        NodeList<T> m_NodeList;
        
        public Graph()
        {
            m_NodePool = new ObjectPool<Node<T>>(
                () => new Node<T>(),
                node =>
                    {
                        if (node.costs != null) node.costs.Clear();
                        if (node.neighbors != null) node.neighbors.Clear();
                        node.Toggle(true);
                        node.value = default(T);
                    });

            m_NodeList = new NodeList<T>();
        }

        public Graph(IEnumerable<T> enumerable) : this()
        {
            var enumerator = enumerable.GetEnumerator();

            while(enumerator.MoveNext())
            {
                T value = enumerator.Current;

                Add(value);
            }
        }

        public Node<T> Add(T value)
        {
            var node = m_NodePool.Pop();
            node.value = value;
            m_NodeList.Add(node);
            m_Changed = true;
            return node;
        }

        void ICollection<T>.Add(T value)
        {
            Add(value);
        }

        public void ToggleNode(Node<T> node)
        {
            node.Toggle(!node.enabled);
            m_Changed = true;
        }
        
        public void ToggleNode(Node<T> node, bool enabled)
        {
            if (node.enabled != enabled)
            {
                node.Toggle(enabled);
                m_Changed = true;
            }
        }
        
        public bool AddDirectedEdge(Node<T> from, Node<T> to, float cost)
        {
            if (!from.neighbors.Contains(to))
            {
                from.neighbors.Add(to);
                from.costs.Add(cost);
                m_Changed = true;
                return true;
            }
            
            return false;
        }
        
        public bool AddUndirectedEdge(Node<T> from, Node<T> to, float cost)
        {
            if (from == null || to == null)
                return false;
            
            if (!from.neighbors.Contains(to) && !to.neighbors.Contains(from))
            {
                from.neighbors.Add(to);
                from.costs.Add(cost);
                
                to.neighbors.Add(from);
                to.costs.Add(cost);
                m_Changed = true;
                return true;
            }
            
            return false;
        }

        public void ClearAllEdges()
        {
            for(int i = 0; i < m_NodeList.Count; ++i)
            {
                m_NodeList[i].ClearNeighbors();
            }
        }

        public bool Contains(T value)
        {
            return m_NodeList.FindByValue(value) != null;
        }
        
        public Node<T> Find(T value)
        {
            return m_NodeList.FindByValue(value);
        }
        
        public void Remove(Node<T> node)
        {
            if (node != null)
            {
                m_NodeList.Remove(node);
                m_NodePool.Push(node);
                m_Changed = true;
            }
        }

        public bool Remove(T value)
        {
            Node<T> nodeToRemove = m_NodeList.FindByValue(value);
            
            if (nodeToRemove == null)
                return false;
            
            m_NodeList.Remove(nodeToRemove);
            m_NodePool.Push(nodeToRemove);
            
            for (int i = 0; i < m_NodeList.Count; i++)
            {
                Node<T> node = m_NodeList[i];

                int index = node.neighbors.IndexOf(nodeToRemove);
                if (index != -1)
                {
                    node.neighbors.RemoveAt(index);
                    node.costs.RemoveAt(index);
                }
            }
            
            m_Changed = true;
            return true;
        }

        public void Clear()
        {
            for(int i = m_NodeList.Count - 1; i >= 0; --i)
            {
                var node = m_NodeList[i];

                m_NodeList.RemoveAt(i);
                m_NodePool.Push(node);
            }
        }

        public int IndexOf(T value)
        {
            var node = m_NodeList.FindByValue(value);

            return node != null ? m_NodeList.IndexOf(node) : -1;
        }

        public Node<T> Insert(int index, T value)
        {
            var node = m_NodePool.Pop();
            node.value = value;
            m_NodeList.Insert(index, node);
            return node;
        }

        void IList<T>.Insert(int index, T value)
        {
            Insert(index, value);
        }

        public void RemoveAt(int index)
        {
            m_NodePool.Push(m_NodeList[index]);

            m_NodeList.RemoveAt(index);
        }

        public Node<T> this[int i]
        {
            get
            {
                return m_NodeList[i];
            }
        }

        T IList<T>.this[int i]
        {
            get
            {
                return m_NodeList[i].value;
            }
            set
            {
                m_NodeList[i].value = value;
            }
        }

        public int nodeCount
        {
            get
            {
                return m_NodeList.Count;
            }
        }

        int ICollection<T>.Count
        {
            get { return m_NodeList.Count; }
        }

        bool ICollection<T>.IsReadOnly
        {
            get { return false; }
        }

        void ICollection<T>.CopyTo(T[] array, int arrayIndex)
        {
            if (array == null)
                throw new System.ArgumentNullException("array");
            if (arrayIndex < 0)
                throw new System.ArgumentOutOfRangeException("arrayIndex");
            if (m_NodeList.Count > array.Length - arrayIndex)
                throw new System.ArgumentException();

            for(int i = 0; i < array.Length - arrayIndex; ++i)
            {
                array[i + arrayIndex] = m_NodeList[i].value;
            }
        }

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            for(int i = 0; i < m_NodeList.Count; ++i)
            {
                yield return m_NodeList[i].value;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return m_NodeList.GetEnumerator();
        }
    }
}
