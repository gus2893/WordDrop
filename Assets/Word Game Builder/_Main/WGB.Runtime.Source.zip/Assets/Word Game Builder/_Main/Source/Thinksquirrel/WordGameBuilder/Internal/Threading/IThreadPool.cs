// IThreadPool.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilder.Internal.Threading
{       
    public interface IThreadPool : IDisposable
    {
        void SetPriority();        
        void For(int iterations, ParallelAction action);
        void RunInBackground(Action action);
        void RunOnMainThread(Action action);
        int GetThreadCount();
    }

    public delegate void ParallelAction(int index);
}
//! \endcond
