// CsvReader.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Thinksquirrel.WordGameBuilder.Internal
{
    /// <summary>
    /// A data-reader style interface for reading CSV (and otherwise-char-separated) files.
    /// </summary>
    /// <remarks>
    /// Original CsvReader code (c) Jouni Heikniemi. (http://www.heikniemi.fi/jhlib/)
    /// "JHLib is free. It is not released under any formal license such as GPL; it's just plainly and simply free.
    /// You can do whatever you wish with the code; I don't offer support or carry responsibility for anything related to the source or the binaries."
    /// </remarks>
    sealed class CsvReader : System.IDisposable
    {

    #region Private variables

        Stream m_Stream;
        StreamReader m_Reader;
        char m_Separator;

    #endregion

    #region Constructors

        /// <summary>
        /// Creates a new Csv reader for the given stream.
        /// </summary>
        /// <param name="s">The stream to read the CSV from.</param>
        public CsvReader(Stream s) : this(s, ',')
        {
        }

        /// <summary>
        /// Creates a new reader for the given stream, encoding and separator character.
        /// </summary>
        /// <param name="s">The stream to read the data from.</param>
        /// <param name="separator">The separator character between the fields</param>
        public CsvReader(Stream s, char separator)
        {

            m_Separator = separator;
            m_Stream = s;
            if (!s.CanRead)
            {
                throw new CsvReaderException("Could not read the given data stream!");
            }
            m_Reader = new StreamReader(s);
        }
        
    #endregion

    #region Properties

        /// <summary>
        /// The separator character for the fields. Comma for normal CSV.
        /// </summary>
        public char separator
        {
            get { return m_Separator; }
            set { m_Separator = value; }
        }

    #endregion

    #region Parsing

        /// <summary>
        /// Returns the fields for the next row of data (or null if at eof)
        /// </summary>
        /// <returns>A string array of fields or null if at the end of file.</returns>
        public string[] GetCsvLine()
        {

            string data = m_Reader.ReadLine();
            if (data == null)
                return null;
            if (data.Length == 0)
                return new string[0];
      
            var result = new List<string>();

            ParseCsvFields(result, data);
      
            return result.ToArray();
        }

        // Parses the fields and pushes the fields into the result list
        void ParseCsvFields(ICollection<string> result, string data)
        {
            int pos = -1;
            while (pos < data.Length)
                result.Add(ParseCsvField(data, ref pos));
        }

        // Parses the field at the given position of the data, modified pos to match
        // the first unparsed position and returns the parsed field
        string ParseCsvField(string data, ref int startSeparatorPosition)
        {

            if (startSeparatorPosition == data.Length - 1)
            {
                startSeparatorPosition++;
                // The last field is empty
                return "";
            }

            int fromPos = startSeparatorPosition + 1;

            // Determine if this is a quoted field
            if (data [fromPos] == '"')
            {
                // If we're at the end of the string, let's consider this a field that
                // only contains the quote
                if (fromPos == data.Length - 1)
                {
                    fromPos++;
                    return "\"";
                }

                // Otherwise, return a string of appropriate length with double quotes collapsed
                // Note that FSQ returns data.Length if no single quote was found
                int nextSingleQuote = FindSingleQuote(data, fromPos + 1);
                startSeparatorPosition = nextSingleQuote + 1;
                return data.Substring(fromPos + 1, nextSingleQuote - fromPos - 1).Replace("\"\"", "\"");
            }

            // The field ends in the next separator or EOL
            int nextSeparator = data.IndexOf(m_Separator, fromPos);
            if (nextSeparator == -1)
            {
                startSeparatorPosition = data.Length;
                return data.Substring(fromPos);
            }
            startSeparatorPosition = nextSeparator;
            return data.Substring(fromPos, nextSeparator - fromPos);
        }

        // Returns the index of the next single quote mark in the string
        // (starting from startFrom)
        static int FindSingleQuote(string data, int startFrom)
        {

            int i = startFrom - 1;
            while (++i < data.Length)
                if (data [i] == '"')
                {
                    // If this is a double quote, bypass the chars
                    if (i < data.Length - 1 && data [i + 1] == '"')
                    {
                        i++;
                        continue;
                    }
                    return i;
                }
            // If no quote found, return the end value of i (data.Length)
            return i;
        }

    #endregion


        /// <summary>
        /// Disposes the reader. The underlying stream is closed.
        /// </summary>
        public void Dispose()
        {
            // Closing the reader closes the underlying stream, too
            if (m_Reader != null)
                m_Reader.Dispose();
            else
            if (m_Stream != null)
                m_Stream.Dispose(); // In case we failed before the reader was constructed
            System.GC.SuppressFinalize(this);
        }
    }

    /// <summary>
    /// Exception class for CsvReader exceptions.
    /// </summary>
    [System.Serializable]
    class CsvReaderException : System.Exception
    {

        /// <summary>
        /// Constructs a new CsvReaderException.
        /// </summary>
        public CsvReaderException() : this("The CSV Reader encountered an error.")
        {
        }

        /// <summary>
        /// Constructs a new exception with the given message.
        /// </summary>
        /// <param name="message">The exception message.</param>
        public CsvReaderException(string message) : base(message)
        {
        }

        /// <summary>
        /// Constructs a new exception with the given message and the inner exception.
        /// </summary>
        /// <param name="message">The exception message.</param>
        /// <param name="inner">Inner exception that caused this issue.</param>
        public CsvReaderException(string message, System.Exception inner) : base(message, inner)
        {
        }
    }
}
