// WGBBase.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;

[assembly:System.Runtime.CompilerServices.InternalsVisibleTo("WGB.Editor")]
#if WGB_DEVELOPMENT
[assembly:System.Runtime.CompilerServices.InternalsVisibleTo("Assembly-CSharp-Editor")]
#endif

//! This namespace contains all core Word Game Builder classes.
namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// The base class for all Word Game Builder components.
    /// </summary>
    [AddComponentMenu("")]
    public abstract class WGBBase : MonoBehaviour
    {
        /// <summary>
        /// Additional user data associated with this object. This is unused by default.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IMonoBehaviour.userData">IMonoBehaviour</see>.
        /// </remarks>
        public object userData { get; set; }

        /// <summary>
        /// Instantiate a GameObject from interface type T.
        /// </summary>
        /// <typeparam name="T">The interface type to instantiate. Must be an IMonoBehaviour.</typeparam>
        /// <param name="original">The object to instantiate.</param>
        /// <returns>The instantiated object as an interface.</returns>
        public static T InstantiateFromInterface<T>(T original) where T : class, IMonoBehaviour
        {
            return Object.Instantiate(original as MonoBehaviour) as T;
        }
        /// <summary>
        /// Instantiate a GameObject from interface type T at the specified position and rotation.
        /// </summary>
        /// <typeparam name="T">The interface type to instantiate. Must be an IMonoBehaviour.</typeparam>
        /// <param name="original">The object to instantiate.</param>
        /// <param name="position">The position to instantiate the new object at.</param>
        /// <param name="rotation">The rotation to instantiate the new object at.</param>
        /// <returns>The instantiated object as an interface.</returns>
        public static T InstantiateFromInterface<T>(T original, Vector3 position, Quaternion rotation) where T : class, IMonoBehaviour
        {
            return Object.Instantiate(original as MonoBehaviour, position, rotation) as T;
        }
        /// <summary>
        /// Finds the first object of interface type T.
        /// </summary>
        /// <typeparam name="T">The interface type to find. Must be an IMonoBehaviour.</typeparam>
        /// <returns>The first found object as an interface. Returns null if no objects were found.</returns>
        public static T FindObjectOfTypeFromInterface<T>() where T : class, IMonoBehaviour
        {
            return WGBExtensions.FindInterface<T>(Object.FindObjectsOfType(typeof(MonoBehaviour)));
        }
        /// <summary>
        /// Finds all objects of interface type T.
        /// </summary>
        /// <typeparam name="T">The interface type to find. Must be an IMonoBehaviour.</typeparam>
        /// <returns>An array of found objects, as an interface. Returns an empty array if no objects were found.</returns>
        public static T[] FindObjectsOfTypeFromInterface<T>() where T : class, IMonoBehaviour
        {
            return WGBExtensions.FindInterfaces<T>(Object.FindObjectsOfType(typeof(MonoBehaviour)));
        }
        /// <summary>
        /// Gets a component from its interface type.
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <returns>The found object as an interface. Returns null if no object was found.</returns>
        public T GetComponentFromInterface<T>() where T : class, IMonoBehaviour
        {
            // Analysis disable InvokeAsExtensionMethod
            return WGBExtensions.GetComponentFromInterface<T>(this);
            // Analysis restore InvokeAsExtensionMethod
        }
        /// <summary>
        /// Gets all components from its interface type.
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <returns>An array of found objects, as an interface. Returns an empty array if no objects were found.</returns>
        public T[] GetComponentsFromInterface<T>() where T : class, IMonoBehaviour
        {
            // Analysis disable InvokeAsExtensionMethod
            return WGBExtensions.GetComponentsFromInterface<T>(this);
            // Analysis restore InvokeAsExtensionMethod
        }
        /// <summary>
        /// Gets a component from its interface type, searching through this GameObject and all children.
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <returns>The found object as an interface. Returns null if no object was found.</returns>
        public T GetComponentInChildrenFromInterface<T>() where T : class, IMonoBehaviour
        {
            // Analysis disable InvokeAsExtensionMethod
            return WGBExtensions.GetComponentInChildrenFromInterface<T>(this);
            // Analysis restore InvokeAsExtensionMethod
        }
        /// <summary>
        /// Gets all components from its interface type, searching through this GameObject and all children.
        /// </summary>
        /// <typeparam name='T'>
        /// The interface type of the component. Must be an IMonoBehaviour.
        /// </typeparam>
        /// <returns>An array of found objects, as an interface. Returns an empty array if no objects were found.</returns>
        public T[] GetComponentsInChildrenFromInterface<T>() where T : class, IMonoBehaviour
        {
            // Analysis disable InvokeAsExtensionMethod
            return WGBExtensions.GetComponentsInChildrenFromInterface<T>(this);
            // Analysis restore InvokeAsExtensionMethod
        }
        /// <summary>
        /// Logs a prefixed message.
        /// </summary>
        /// <param name="message">The message to log.</param>
        /// <param name="prefix">The prefix to log with the message.</param>
        /// <param name="type">An identifier formatted with the prefix.</param>
        public static void Log(object message, string prefix, string type)
        {
            Debug.Log(string.Format("[{0}] ({1}): {2}", prefix, type, message));
        }
        /// <summary>
        /// Logs a prefixed warning.
        /// </summary>
        /// <param name="message">The message to log.</param>
        /// <param name="prefix">The prefix to log with the message.</param>
        /// <param name="type">An identifier formatted with the prefix.</param>
        public static void LogWarning(object message, string prefix, string type)
        {
            Debug.LogWarning(string.Format("[{0}] ({1}): {2}", prefix, type, message));
        }
        /// <summary>
        /// Logs a prefixed erorr.
        /// </summary>
        /// <param name="message">The message to log.</param>
        /// <param name="prefix">The prefix to log with the message.</param>
        /// <param name="type">An identifier formatted with the prefix.</param>
        public static void LogError(object message, string prefix, string type)
        {
            Debug.LogError(string.Format("[{0}] ({1}): {2}", prefix, type, message));
        }
        /// <summary>
        /// Logs an exception.
        /// </summary>
        /// <param name="ex">The exception to log.</param>
        public static void LogException(System.Exception ex)
        {
            Debug.LogException(ex);
        }
        /// <summary>
        /// Logs a prefixed message, with context.
        /// </summary>
        /// <param name="message">The message to log.</param>
        /// <param name="prefix">The prefix to log with the message.</param>
        /// <param name="type">An identifier formatted with the prefix.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void Log(object message, string prefix, string type, Object context)
        {
            Debug.Log(string.Format("[{0}] ({1}): {2}", prefix, type, message), context);
        }
        /// <summary>
        /// Logs a prefixed warning, with context.
        /// </summary>
        /// <param name="message">The message to log.</param>
        /// <param name="prefix">The prefix to log with the message.</param>
        /// <param name="type">An identifier formatted with the prefix.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void LogWarning(object message, string prefix, string type, Object context)
        {
            Debug.LogWarning(string.Format("[{0}] ({1}): {2}", prefix, type, message), context);
        }
        /// <summary>
        /// Logs a prefixed exception, with context.
        /// </summary>
        /// <param name="message">The message to log.</param>
        /// <param name="prefix">The prefix to log with the message.</param>
        /// <param name="type">An identifier formatted with the prefix.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void LogError(object message, string prefix, string type, Object context)
        {
            Debug.LogError(string.Format("[{0}] ({1}): {2}", prefix, type, message), context);
        }
        /// <summary>
        /// Logs an exception, with context.
        /// </summary>
        /// <param name="ex">The exception to log.</param>
        /// <param name="context">Object to which the message applies.</param>
        public static void LogException(System.Exception ex, Object context)
        {
            Debug.LogError(string.Format("{0}\n{1}", ex.Message, ex.StackTrace), context);
        }
    }
}
