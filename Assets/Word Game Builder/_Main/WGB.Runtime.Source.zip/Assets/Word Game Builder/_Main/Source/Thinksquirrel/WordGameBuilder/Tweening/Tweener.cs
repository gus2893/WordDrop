﻿// Tweener.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEngine;
using Thinksquirrel.WordGameBuilder.Internal.Tweening;

//! This namespace contains a simple tweening engine (used by letter tiles).
namespace Thinksquirrel.WordGameBuilder.Tweening
{
    /// <summary>
    /// The main tweening class.
    /// </summary>
    /// <remarks>
    /// Provides tween support (with easing) for the following types:
    /// * float
    /// * Vector2
    /// * Vector3
    /// * Vector4
    /// * Color
    /// * Color32
    ///
    /// Tween updates are independent of the current time scale.
    /// </remarks>
    public sealed class Tweener<T> : System.IDisposable where T : struct
    {
        #region Public API
        /// <summary>
        /// Gets or sets the duration of the tween action.
        /// </summary>
        public float duration { get; set; }
        /// <summary>
        /// Gets or sets the delay before performing the tween action.
        /// </summary>
        public float delay { get; set; }
        /// <summary>
        /// Gets or sets the easing of the tween action.
        /// </summary>
        public Easing easing { get; set; }
        
        /// <summary>
        /// Occurs every frame while an object is tweening.
        /// </summary>
        public event System.Action onTween
        {
            add { m_OnTween += value; }
            // Analysis disable DelegateSubtraction
            remove { m_OnTween -= value; }
            // Analysis restore DelegateSubtraction
        }

        /// <summary>
        /// Gets or sets the initial tween value.
        /// </summary>
        public T start
        {
            get
            {
                return
                    typeof(T) == typeof(float) ?
                        (T)(object)m_StartFloat :
                    typeof(T) == typeof(Vector2) ?
                        (T)(object)m_StartVector2 :
                    typeof(T) == typeof(Vector3) ?
                        (T)(object)m_StartVector3 :
                    typeof(T) == typeof(Vector4) ?
                        (T)(object)m_StartVector4 :
                    (T)(object)m_StartColor;
            }
            set
            {
                if (typeof(T) == typeof(float))
                {
                    m_StartFloat = (float)(object)value;
                }
                if (typeof(T) == typeof(Vector2))
                {
                    m_StartVector2 = (Vector2)(object)value;
                }
                if (typeof(T) == typeof(Vector3))
                {
                    m_StartVector3 = (Vector3)(object)value;
                }
                if (typeof(T) == typeof(Vector4))
                {
                    m_StartVector4 = (Vector4)(object)value;
                }
                if (typeof(T) == typeof(Color) || typeof(T) == typeof(Color32))
                {
                    m_StartColor = (Color)(object)value;
                }
            }
        }
        /// <summary>
        /// Gets or sets the final tween value.
        /// </summary>
        public T end
        {
            get
            {
                return
                    typeof(T) == typeof(float) ?
                        (T)(object)m_EndFloat :
                    typeof(T) == typeof(Vector2) ?
                        (T)(object)m_EndVector2 :
                    typeof(T) == typeof(Vector3) ?
                        (T)(object)m_EndVector3 :
                    typeof(T) == typeof(Vector4) ?
                        (T)(object)m_EndVector4 :
                    (T)(object)m_EndColor;
            }
            set
            {
                if (typeof(T) == typeof(float))
                {
                    m_EndFloat = (float)(object)value;
                }
                if (typeof(T) == typeof(Vector2))
                {
                    m_EndVector2 = (Vector2)(object)value;
                }
                if (typeof(T) == typeof(Vector3))
                {
                    m_EndVector3 = (Vector3)(object)value;
                }
                if (typeof(T) == typeof(Vector4))
                {
                    m_EndVector4 = (Vector4)(object)value;
                }
                if (typeof(T) == typeof(Color) || typeof(T) == typeof(Color32))
                {
                    m_EndColor = (Color)(object)value;
                }
            }
        }
        /// <summary>
        /// Gets the current value.
        /// </summary>
        public T currentValue
        {
            get
            {
                return typeof(T) == typeof(float) ?
                        (T)(object)m_CurrentValueFloat :
                    typeof(T) == typeof(Vector2) ?
                        (T)(object)m_CurrentValueVector2 :
                    typeof(T) == typeof(Vector3) ?
                        (T)(object)m_CurrentValueVector3 :
                    typeof(T) == typeof(Vector4) ?
                        (T)(object)m_CurrentValueVector4 :
                    (T)(object)m_CurrentValueColor;
            }
           	set
            {
                if (typeof(T) == typeof(float))
                {
                    m_CurrentValueFloat = (float)(object)value;
                }
                if (typeof(T) == typeof(Vector2))
                {
                    m_CurrentValueVector2 = (Vector2)(object)value;
                }
                if (typeof(T) == typeof(Vector3))
                {
                    m_CurrentValueVector3 = (Vector3)(object)value;
                }
                if (typeof(T) == typeof(Vector4))
                {
                    m_CurrentValueVector4 = (Vector4)(object)value;
                }
                if (typeof(T) == typeof(Color) || typeof(T) == typeof(Color32))
                {
                    m_CurrentValueColor = (Color)(object)value;
                }
            }
        }

        /// <summary>
        /// Gets the start time for the tween action. Returns -1 when stopped.
        /// </summary>
        public float startTime { get; private set; }
        /// <summary>
        /// Gets a value indicating whether this tweener is enabled.
        /// </summary>
        public bool isEnabled { get; private set; }
        /// <summary>
        /// Gets a value indicating whether the current tween action has ended.
        /// </summary>
        public bool hasEnded { get; private set; }
        /// <summary>
        /// Gets a value indicating whether the current tween action has started.
        /// </summary>
        public bool hasStarted { get; private set; }
        /// <summary>
        /// Gets a value indicating whether this tweener has been disposed.
        /// </summary>
        public bool isDisposed { get; private set; }

        /// <summary>
        /// Start a tween action.
        /// </summary>
        /// <param name="tweenTo">The value to tween to.</param>
        public void Start(T tweenTo)
        {
            Start(tweenTo, duration, delay, easing);
        }

        /// <summary>
        /// Start a tween action.
        /// </summary>
        /// <param name="tweenTo">The value to tween to.</param>
        /// <param name="duration">The duration of the tween action.</param>
        public void Start(T tweenTo, float duration)
        {
            Start(tweenTo, duration, delay, easing);
        }
        /// <summary>
        /// Start a tween action.
        /// </summary>
        /// <param name="tweenTo">The value to tween to.</param>
        /// <param name="duration">The duration of the tween action.</param>
        /// <param name="delay">The delay before starting the tween action.</param>
        /// <param name="easing">The easing of the tween action.</param>
        public void Start(T tweenTo, float duration, float delay, Easing easing)
        {
            if (isDisposed)
                throw new System.ObjectDisposedException("Tweener");

            start = currentValue;
            end = tweenTo;
            this.duration = duration;
            this.delay = delay;
            this.easing = easing;
            startTime = Time.realtimeSinceStartup;
            if (!isEnabled)
            {
                TweenTimer.onTweenUpdate += UpdateTweener;
                isEnabled = true;
            }
            UpdateTweener(startTime);
        }
        /// <summary>
        /// Stop any currently running tween action.
        /// </summary>
        public void Stop()
        {
            if (isDisposed)
                throw new System.ObjectDisposedException("Tweener");

            isEnabled = false;
            startTime = -1;
            TweenTimer.onTweenUpdate -= UpdateTweener;
        }
        #endregion

        #region Private variables
        float m_StartFloat, m_EndFloat, m_CurrentValueFloat;
        Vector2 m_StartVector2, m_EndVector2, m_CurrentValueVector2;
        Vector3 m_StartVector3, m_EndVector3, m_CurrentValueVector3;
        Vector4 m_StartVector4, m_EndVector4, m_CurrentValueVector4;
        Color m_StartColor, m_EndColor, m_CurrentValueColor;
        System.Action m_OnTween;
        #endregion

        #region Constructor
        /// <summary>
        /// Creats a new tweener instance.
        /// </summary>
        public Tweener()
        {
            if (typeof(T) == typeof(float) ||
                typeof(T) == typeof(Vector2) ||
                typeof(T) == typeof(Vector3) ||
                typeof(T) == typeof(Vector4) ||
                typeof(T) == typeof(Color) ||
                typeof(T) == typeof(Color32))
            {
                start = default(T);
                end = default(T);
                duration = .15f;
                delay = 0f;
                easing = Easing.Linear;
                startTime = -1;
            }
            else
            {
                throw new System.InvalidOperationException(string.Format("{0} is not supported for tweening.", typeof(T)));
            }
        }
        #endregion

        #region Update callback
        void UpdateTweener(float currentTime)
        {
            var t = currentTime - (startTime + delay);

            bool wasRunning = hasStarted && !hasEnded;

            hasStarted = t >= 0;
            hasEnded = t > duration && hasStarted;

            bool isRunning = hasStarted && !hasEnded;

            if (typeof(T) == typeof(float))
            {
                var fDelta = m_EndFloat - m_StartFloat;
                m_CurrentValueFloat = isRunning ? TweenMath.ChangeFloat(t, m_StartFloat, fDelta, duration, easing) :
                                      hasEnded ? m_EndFloat : m_StartFloat;
            }
            else if (typeof(T) == typeof(Vector2))
            {
                var v2Delta = m_EndVector2 - m_StartVector2;
                m_CurrentValueVector2 = isRunning ? TweenMath.ChangeVector2(t, m_StartVector2, v2Delta, duration, easing) :
                                        hasEnded ? m_EndVector2 : m_StartVector2;
            }
            else if (typeof(T) == typeof(Vector3))
            {
                var v3Delta = m_EndVector3 - m_StartVector3;
                m_CurrentValueVector3 = isRunning ? TweenMath.ChangeVector3(t, m_StartVector3, v3Delta, duration, easing) :
                                        hasEnded ? m_EndVector3 : m_StartVector3;
            }
            else if (typeof(T) == typeof(Vector4))
            {
                var v4Delta = m_EndVector4 - m_StartVector4;
                m_CurrentValueVector4 = isRunning ? TweenMath.ChangeVector4(t, m_StartVector4, v4Delta, duration, easing) :
                                        hasEnded ? m_EndVector4 : m_StartVector4;
            }
            else
            {
                var cDelta = m_EndColor - m_StartColor;
                m_CurrentValueColor = isRunning ? TweenMath.ChangeColor(t, m_StartColor, cDelta, duration, easing) :
    			                      hasEnded ? m_EndColor : m_StartColor;
            }

            if ((wasRunning || isRunning) && m_OnTween != null)
            {
                m_OnTween();
            }
        }
        #endregion

        #region IDisposable implementation
        /// <summary>
        /// Disposes the tweener object.
        /// </summary>
        public void Dispose()
        {
            if (isDisposed)
                throw new System.ObjectDisposedException("Tweener");

            isEnabled = false;
            TweenTimer.onTweenUpdate -= UpdateTweener;
            isDisposed = true;
        }
        #endregion
    }

    /// <summary>
    /// Defines various easing equations used for tweening.
    /// </summary>
    public enum Easing
    {
        /// <summary>
        /// A simple linear tweening, with no easing.
        /// </summary>
        Linear = 0,
        /// <summary>
        /// A quadratic (t^2) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInQuad = 1,
        /// <summary>
        /// A quadratic (t^2) easing out: decelerating to zero velocity.
        /// </summary>
        EaseOutQuad = 2,
        /// <summary>
        /// A quadratic (t^2) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutQuad = 3,
        /// <summary>
        /// A quadratic (t^2) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInQuad = 4,
        /// <summary>
        /// A cubic (t^3) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInCubic = 5,
        /// <summary>
        /// A cubic (t^3) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutCubic = 6,
        /// <summary>
        /// A cubic (t^3) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutCubic = 7,
        /// <summary>
        /// A cubic (t^3) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInCubic = 8,
        /// <summary>
        /// A quartic (t^4) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInQuart = 9,
        /// <summary>
        /// A quartic (t^4) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutQuart = 10,
        /// <summary>
        /// A quartic (t^4) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutQuart = 11,
        /// <summary>
        /// A quartic (t^4) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInQuart = 12,
        /// <summary>
        /// A quintic (t^5) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInQuint = 13,
        /// <summary>
        /// A quintic (t^5) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutQuint = 14,
        /// <summary>
        /// A quintic (t^5) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutQuint = 15,
        /// <summary>
        /// A quintic (t^5) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInQuint = 16,
        /// <summary>
        /// A sinusoidal (sin(t)) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInSine = 17,
        /// <summary>
        /// A sinusoidal (sin(t)) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutSine = 18,
        /// <summary>
        /// A sinusoidal (sin(t)) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutSine = 19,
        /// <summary>
        /// A sinusoidal (sin(t)) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInSine = 20,
        /// <summary>
        /// An exponential (2^t) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInExpo = 21,
        /// <summary>
        /// An exponential (2^t) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutExpo = 22,
        /// <summary>
        /// An exponential (2^t) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutExpo = 23,
        /// <summary>
        /// An exponential (2^t) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInExpo = 24,
        /// <summary>
        /// A circular (sqrt(1-t^2)) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInCirc = 25,
        /// <summary>
        /// A circular (sqrt(1-t^2)) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutCirc = 26,
        /// <summary>
        /// A circular (sqrt(1-t^2)) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutCirc = 27,
        /// <summary>
        /// A circular (sqrt(1-t^2)) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInCirc = 28,
        /// <summary>
        /// An elastic (exponentially decaying sine wave) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInElastic = 29,
        /// <summary>
        /// An elastic (exponentially decaying sine wave) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutElastic = 30,
        /// <summary>
        /// An elastic (exponentially decaying sine wave) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutElastic = 31,
        /// <summary>
        /// An elastic (exponentially decaying sine wave) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInElastic = 32,
        /// <summary>
        /// A back (overshooting cubic easing: (s+1)*t^3 - s*t^2) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInBack = 33,
        /// <summary>
        /// A back (overshooting cubic easing: (s+1)*t^3 - s*t^2) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutBack = 34,
        /// <summary>
        /// A back (overshooting cubic easing: (s+1)*t^3 - s*t^2) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutBack = 35,
        /// <summary>
        /// A back (overshooting cubic easing: (s+1)*t^3 - s*t^2) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInBack = 36,
        /// <summary>
        /// A bounce (exponentially decaying parabolic bounce) easing in: accelerating from zero velocity.
        /// </summary>
        EaseInBounce = 37,
        /// <summary>
        /// A bounce (exponentially decaying parabolic bounce) easing out: decelerating from zero velocity.
        /// </summary>
        EaseOutBounce = 38,
        /// <summary>
        /// A bounce (exponentially decaying parabolic bounce) easing in/out: acceleration until halfway, then deceleration.
        /// </summary>
        EaseInOutBounce = 39,
        /// <summary>
        /// A bounce (exponentially decaying parabolic bounce) easing out/in: deceleration until halfway, then acceleration.
        /// </summary>
        EaseOutInBounce = 40
    }
}
