﻿// LetterTileLabelControl.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEngine;
using Thinksquirrel.WordGameBuilder.Internal;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using UnityEngine.UI;

namespace Thinksquirrel.WordGameBuilder.Tiles
{
    /// <summary>
    /// Automatically controls the text on objects based on a letter tile's state.
    /// </summary>
    /// <remarks>
    /// This component must be on the same object as a letter tile.
    /// </remarks>
    [RequireComponent(typeof(ILetterTileDisplay))]
    [AddComponentMenu("Word Game Builder/Tiles/Letter Tile Label Control")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.LetterTileLabelControl")]
    public sealed class LetterTileLabelControl : WGBBase
    {
        [SerializeField] Object m_LetterLabel;
        [SerializeField] Object m_ScoreLabel;

        /// <summary>
        /// The letter label.
        /// </summary>
        /// <remarks>
        /// Supported object types:
        /// * Text
        /// * TextMesh
        /// * GUIText
        /// * GameObject (will select the first component)
        /// </remarks>
        public Object letterLabel { get { return m_LetterLabel; } set { m_LetterLabel = value; } }
        /// <summary>
        /// The score label.
        /// </summary>
        /// <remarks>
        /// Supported object types:
        /// * Text
        /// * TextMesh
        /// * GUIText
        /// * GameObject (will select the first component)
        /// </remarks>
        public Object scoreLabel { get { return m_ScoreLabel; } set { m_ScoreLabel = value; } }

        ILetterTileDisplay m_LetterTile;

        void OnEnable()
        {
            m_LetterTile = GetComponentFromInterface<ILetterTileDisplay>();

            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange += UpdateTileLabel;
            }
            UpdateTileLabel();
        }

        void OnDisable()
        {
            if (m_LetterTile != null)
            {
                m_LetterTile.onTileChange -= UpdateTileLabel;
            }
        }

        void UpdateTileLabel()
        {
            // TODO
            if (!m_LetterTile.shouldChangeColor && !m_LetterTile.shouldChangeLabel)
                return;

            if (m_LetterLabel)
            {
                var letterGameObject = m_LetterLabel as GameObject;
                var text = letterGameObject != null ? letterGameObject.GetComponent<Text>() : m_LetterLabel as Text;
                var textMesh = letterGameObject != null ? letterGameObject.GetComponent<TextMesh>() : m_LetterLabel as TextMesh;
                var guiTxt = letterGameObject != null ? letterGameObject.GetComponent<GUIText>() : m_LetterLabel as GUIText;

                if (text)
                {
                    text.text = m_LetterTile.currentLetterLabel;
                }
                else if (textMesh)
                {
                    textMesh.text = m_LetterTile.currentLetterLabel;
                }
                else if (guiTxt)
                {
                    guiTxt.text = m_LetterTile.currentLetterLabel;
                }
            }
            if (m_ScoreLabel)
            {
                var scoreGameObject = m_ScoreLabel as GameObject;
                var text = scoreGameObject != null ? scoreGameObject.GetComponent<Text>() : m_ScoreLabel as Text;
                var textMesh = scoreGameObject != null ? scoreGameObject.GetComponent<TextMesh>() : m_ScoreLabel as TextMesh;
                var guiTxt = scoreGameObject != null ? scoreGameObject.GetComponent<GUIText>() : m_ScoreLabel as GUIText;

                if (text)
                {
                    text.text = m_LetterTile.currentScoreLabel;
                }
                else if (textMesh)
                {
                    textMesh.text = m_LetterTile.currentScoreLabel;
                }
                else if (guiTxt)
                {
                    guiTxt.text = m_LetterTile.currentScoreLabel;
                }
            }
        }
    }
}
