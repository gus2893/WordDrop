// IUnityEditorBinding.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
namespace Thinksquirrel.WordGameBuilder.Internal
{
    // !\ cond PRIVATE
    public interface IUnityEditorBinding
    {
        void LoadAssembly();
        object RunStatic(string method, params object[] arguments);
        object RunInstance(object instance, string method, params object[] arguments);
    }
    // !\endcond
}
