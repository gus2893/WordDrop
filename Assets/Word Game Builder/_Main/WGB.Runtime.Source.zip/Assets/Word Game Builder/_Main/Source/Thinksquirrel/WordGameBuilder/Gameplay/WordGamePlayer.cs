// WordGamePlayer.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilder.Internal;

//! This namespace contains all classes related to word game logic.
namespace Thinksquirrel.WordGameBuilder.Gameplay
{
    /// <summary>
    /// Represents a word game player. It tracks scores, holds tiles, and can be controlled by an AI agent.
    /// </summary>
    /// <remarks>
    /// This class contains many convenient methods for creating a word game.
    /// \note Loading and saving scores from disk are not implemented - in order to have persistent data, the player will need to be initialized on load.
    /// </remarks>
    [AddComponentMenu("Word Game Builder/Gameplay/Word Game Player")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Gameplay.WordGamePlayer")]
    public sealed class WordGamePlayer : WGBBase, IWordGamePlayer
    {
        /// <summary>
        /// The player ID. Use this for games with multiple players.
        /// </summary>
        [System.Obsolete("Player IDs are now based on GameObject name.")]
        public string playerID
        {
            get { return name; }
            set { name = value; }
        }
        /// <summary>
        /// Controls whether or not input has been enabled for this player.
        /// </summary>
        /// <remarks>
        /// It is the responsibilty of the letter tile to check for (or ignore) this value. This is handled automatically by the default LetterTile class.
        /// </remarks>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.inputEnabled">IWordGamePlayer</see>.
        /// </remarks>
        public bool inputEnabled { get { return m_InputEnabled; } set { m_InputEnabled = value; } }
        /// <summary>
        /// The maximum amount of tiles that a player should hold.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.maxTiles">IWordGamePlayer</see>.
        /// </remarks>
        public int maxTiles { get { return m_MaxTiles; } set { m_MaxTiles = value; } }
        /// <summary>
        /// Should word checks be ordered?
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.orderedWordCheck">IWordGamePlayer</see>.
        /// </remarks>
        public bool orderedWordCheck { get { return m_OrderedWordCheck; } set { m_OrderedWordCheck = value; } }
        /// <summary>
        /// If true, the score will be multiplied by the amount of permutations found.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.multiplyByPermutations">IWordGamePlayer</see>.
        /// </remarks>
        public bool multiplyByPermutations { get { return m_MultiplyByPermutations; } set { m_MultiplyByPermutations = value; } }
        /// <summary>
        /// The penalty for submitting the same word multiple times, multiplied by the number of pervious submissions.
        /// </summary>
        public int scorePenalty { get { return m_ScorePenalty; } set { m_ScorePenalty = value; } }
        /// <summary>
        /// The amount of previous words to track.
        /// </summary>
        public int previousWordsCapacity { get { return m_PreviousWordsCapacity; } set { m_PreviousWordsCapacity = value; } }
        /// <summary>
        /// The singular string for "word". Used for localization.
        /// </summary>
        public string wordStringSingular { get { return m_WordStringSingular; } set { m_WordStringSingular = value; } }
        /// <summary>
        /// The plural string for "word". Used for localization.
        /// </summary>
        public string wordStringPlural { get { return m_WordStringPlural; } set { m_WordStringPlural = value; } }
        /// <summary>
        /// This event fires whenever a word result is returned from a word check.
        /// </summary>
        /// <remarks>
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentPlayer
        ///
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.onWordResult">IWordGamePlayer</see>.
        /// </remarks>
        public WGBEvent onWordResult { get { return m_OnWordResult; } set { m_OnWordResult = value; } }

        /// <summary>
        /// Gets the last word result. This value is set before event callbacks.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.lastResult">IWordGamePlayer</see>.
        /// </remarks>
        public WordGameResult lastResult { get; private set; }

        /// <summary>
        /// Finds a player by name.
        /// </summary>
        /// <param name="name">The name to search for.</param>
        /// <returns>A player, or null if no matching player is found.</returns>
        public static IWordGamePlayer FindPlayer(string name)
        {
            GameObject go = GameObject.Find(name);

            return go ? go.GetComponentFromInterface<IWordGamePlayer>() : null;

        }

        /// <summary>
        /// Finds all active players in the scene.
        /// </summary>
        /// <returns>All active players.</returns>
        public static IWordGamePlayer[] GetAllPlayers()
        {
            return FindObjectsOfTypeFromInterface<IWordGamePlayer>();
        }

        // For Unity serialization
        [SerializeField] bool m_InputEnabled = true;
        [SerializeField] int m_MaxTiles = 7;
        [SerializeField] bool m_OrderedWordCheck = true;
        [SerializeField] bool m_MultiplyByPermutations;
        [SerializeField] int m_ScorePenalty;
        [SerializeField] int m_PreviousWordsCapacity = 100;
        [SerializeField] string m_WordStringSingular = "word";
        [SerializeField] string m_WordStringPlural = "words";
        [SerializeField] WGBEvent m_OnWordResult;

        int m_Score;
        int m_HighScore;
        string m_LastWord;
        int m_LastWordScore;
        string m_BestWord;
        int m_BestWordScore;
        int m_LastPenalty;

        IList<ILetterTile> m_HeldTiles = new List<ILetterTile>();
        IList<ILetterTile> m_SelectedTiles = new List<ILetterTile>();
        IList<string> m_PreviousWords = new List<string>();
        float m_Multiplier;

        readonly object m_TaskLock = new object();

        /// <summary>
        /// Gets or sets the player's current score.
        /// </summary>
        /// <remarks>
        /// Setting this value will automatically set a new high score, if it is higher than the previous high score.
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.score">IWordGamePlayer</see>.
        /// </remarks>
        public int score
        {
            get
            {
                return m_Score;
            }
            set
            {
                m_Score = value;
                if (m_Score > m_HighScore)
                {
                    m_HighScore = m_Score;
                }
            }
        }

        /// <summary>
        /// Gets the player's high score.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.highScore">IWordGamePlayer</see>.
        /// </remarks>
        public int highScore
        {
            get
            {
                return m_HighScore;
            }
        }

        /// <summary>
        /// Gets the player's last word.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.lastWord">IWordGamePlayer</see>.
        /// </remarks>
        public string lastWord
        {
            get
            {
                return m_LastWord;
            }
        }

        /// <summary>
        /// Gets the score of the player's last word.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.lastWordScore">IWordGamePlayer</see>.
        /// </remarks>
        public int lastWordScore
        {
            get
            {
                return m_LastWordScore;
            }
        }

        /// <summary>
        /// Gets the player's best word.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.bestWord">IWordGamePlayer</see>.
        /// </remarks>
        public string bestWord
        {
            get
            {
                return m_BestWord;
            }
        }

        /// <summary>
        /// Gets the score of the player's best word.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.bestWordScore">IWordGamePlayer</see>.
        /// </remarks>
        public int bestWordScore
        {
            get
            {
                return m_BestWordScore;
            }
        }

        /// <summary>
        /// Gets the list of the player's held tiles.
        /// </summary>
        /// <remarks>
        /// Held tiles are tiles that belong to the player, but will not be submitted.
        /// </remarks>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.heldTiles">IWordGamePlayer</see>.
        /// </remarks>
        public IList<ILetterTile> heldTiles
        {
            get
            {
                return m_HeldTiles;
            }
        }

        //! \cond PRIVATE
        [System.Obsolete("use WordGamePlayer.selectedTiles instead")]
        public IList<ILetterTile> playTiles
        {
            get
            {
                return m_SelectedTiles;
            }
        }
        //! \endcond
        /// <summary>
        /// Gets the list of the player's selected tiles.
        /// </summary>
        /// <remarks>
        /// Play tiles are tiles that will be submitted for checking.
        /// </remarks>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGamePlayer.selectedTiles">IWordGamePlayer</see>.
        /// </remarks>
        public IList<ILetterTile> selectedTiles
        {
            get
            {
                return m_SelectedTiles;
            }
        }

        /// <summary>
        /// Gets the list of previous words used by the player.
        /// </summary>
        public IList<string> previousWords
        {
            get
            {
                return m_PreviousWords;
            }
        }

        /// <summary>
        /// Gets the last penalty value applied to the player.
        /// </summary>
        public int lastPenalty
        {
            get
            {
                return m_LastPenalty;
            }
        }

        /// <summary>
        /// Initialize the player.
        /// </summary>
        /// <remarks>
        /// Used for loading saved data.
        /// </remarks>
        /// <param name="highScore">The player's high score.</param>
        /// <param name="bestWord">The player's best word.</param>
        /// <param name="bestWordScore">The score value of the player's best word.</param>
        /// <param name="lastWord">The player's last word.</param>
        /// <param name="lastWordScore">The score value of the player's last word.</param>
        /// <param name="previousWords">A list of the players' previous words.</param>
        /// <param name="lastPenalty">The last penalty value applied to the player.</param>
        public void Initialize(
            int highScore,
            string bestWord,
            int bestWordScore,
            string lastWord,
            int lastWordScore,
            IList<string> previousWords,
            int lastPenalty)
        {
            m_HighScore = highScore;
            m_BestWord = bestWord;
            m_BestWordScore = bestWordScore;
            m_LastWord = lastWord;
            m_LastWordScore = lastWordScore;
            m_PreviousWords = previousWords;
            m_LastPenalty = lastPenalty;
        }

        public void ResetAllData()
        {
            ResetAllScores();
            ClearSelection();
            heldTiles.Clear();
        }
        public void ResetAllScores()
        {
            ResetScore();
            ResetHighScore();
            ResetLastWord();
            ResetBestWord();
            m_PreviousWords.Clear();
            m_LastPenalty = 0;
        }
        public void ResetScore()
        {
            m_Score = 0;
        }
        public void ResetHighScore()
        {
            m_HighScore = 0;
        }
        public void ResetLastWord()
        {
            m_LastWord = null;
            m_LastWordScore = 0;
        }
        public void ResetBestWord()
        {
            m_BestWord = null;
            m_BestWordScore = 0;
        }

        /// <summary>
        /// Resets all previous words.
        /// </summary>
        public void ResetPreviousWords()
        {
            m_PreviousWords.Clear();
        }

        /// <summary>
        /// Resets the last penalty.
        /// </summary>
        public void ResetLastPenalty()
        {
            m_LastPenalty = 0;
        }

        public bool SelectTile(ILetterTile tile)
        {
            var selectableTile = tile as ISelectableLetterTile;

            if (selectableTile != null)
                return selectableTile.SelectTile(this);

            if (m_SelectedTiles.Contains(tile))
                return false;

            m_SelectedTiles.Add(tile);
            return true;
        }

        public bool DeselectTile(ILetterTile tile)
        {
            var selectableTile = tile as ISelectableLetterTile;

            return selectableTile != null ? selectableTile.DeselectTile(this) : m_SelectedTiles.Remove(tile);
        }
        
        public void ClearSelection()
        {
            for(int i = m_SelectedTiles.Count - 1; i >= 0; --i)
            {
                DeselectTile(m_SelectedTiles[i]);
            }
        }

        /// <summary>
        /// Submits the word for checking against the current langauge's word list.
        /// </summary>
        /// <remarks>
        /// This method is asynchronous.
        /// </remarks>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        public AsyncTask SubmitWord()
        {
            return SubmitWord(WordGameLanguage.current, 1);
        }
        /// <summary>
        /// Submits the word for checking against the current langauge's word list.
        /// </summary>
        /// <param name='wordMultiplier'>
        /// The score multiplier to apply to the entire submission.
        /// </param>
        /// <remarks>
        /// This method is asynchronous.
        /// </remarks>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        public AsyncTask SubmitWord(float wordMultiplier)
        {
            return SubmitWord(WordGameLanguage.current, wordMultiplier);
        }

        /// <summary>
        /// Submits the word for checking against the specified langauge's word list.
        /// </summary>
        /// <param name='language'>
        /// The language to check.
        /// </param>
        /// <param name='wordMultiplier'>
        /// The score multiplier to apply to the entire submission.
        /// </param>
        /// <remarks>
        /// This method is asynchronous.
        /// </remarks>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        public AsyncTask SubmitWord(WordGameLanguage language, float wordMultiplier = 1)
        {
            m_Multiplier = wordMultiplier;
            return WordChecker.CheckWordAsync(m_SelectedTiles, OnCheckWordPlayer, orderedWordCheck && !multiplyByPermutations, language);
        }

        void OnCheckWordPlayer(WordGameResult result)
        {
            lock (m_TaskLock)
            {
                bool valid = (result.wasOrdered && result.isValid) || (!result.wasOrdered && orderedWordCheck && result.allWords != null && result.allWords.Contains(result.input)) || (!result.wasOrdered && !orderedWordCheck);

                if (valid)
                {
                    int subtractBy = 0;
                   
                    if (scorePenalty != 0)
                    {
                        // Calculate penalty
                        for (int i = 0; i < m_PreviousWords.Count; i++)
                        {
                            var word = m_PreviousWords [i];
                            for (int j = 0; j < result.allWords.Count; j++)
                            {
                                var wrd = result.allWords [j];
                                if (wrd == word)
                                {
                                    subtractBy += scorePenalty;
                                }
                            }
                        }
                        
                        m_LastPenalty = -subtractBy;
                    }
                    
                    for (int i = 0; i < result.allWords.Count; i++)
                    {
                        var wrd = result.allWords [i];
                        m_PreviousWords.Add(wrd);
                    }
                    
                    if (m_PreviousWords.Count > previousWordsCapacity)
                    {
                        for (int i = 0; i < m_PreviousWords.Count - previousWordsCapacity; i++)
                        {
                            m_PreviousWords.RemoveAt(i);
                        }
                    }
                    
                    // Remove the letter tiles from held tiles and play tiles.
                    // Deselect ISelectableLetterTiles and reset wildcards.
                    for (int i = 0; i < result.letterTiles.Count; i++)
                    {
                        var tile = result.letterTiles [i];
                        
                        DeselectTile(tile);

                        if (m_HeldTiles.Contains(tile))
                        {
                            m_HeldTiles.Remove(tile);
                        }
                    }

                    m_SelectedTiles.Clear();

                    int s =
                        (multiplyByPermutations && !result.wasOrdered)
                            ? Mathf.RoundToInt(result.score * result.allWords.Count * m_Multiplier) - subtractBy
                            : Mathf.RoundToInt(result.score * m_Multiplier) - subtractBy;
                    
                    m_Score += s;
                    
                    // Last word
                    if (orderedWordCheck)
                    {
                        m_LastWord = result.word;
                    }
                    else
                    {
                        int c = result.allWords.Count;
                        m_LastWord =
                            (c > 1)
                                ? string.Format("{0} {1}", c, wordStringPlural)
                                : string.Format("{0} {1}", c, wordStringSingular);
                    }
                    
                    m_LastWordScore = s;
                    
                    // High score
                    if (m_Score > m_HighScore)
                    {
                        m_HighScore = m_Score;
                    }
                    
                    // Best score
                    if (s > m_BestWordScore)
                    {
                        m_BestWordScore = s;
                        m_BestWord = result.word;
                    }
                }

                result._isValid = valid;
                lastResult = result;

                WGBEvent.Invoke(m_OnWordResult, null, null, null, null, this, null);
            }
        }
    }
}
