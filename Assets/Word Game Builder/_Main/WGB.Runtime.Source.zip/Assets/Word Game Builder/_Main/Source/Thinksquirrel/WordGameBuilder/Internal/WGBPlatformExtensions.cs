using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace Thinksquirrel.WordGameBuilder.Internal
{
    //! \cond PRIVATE
    public interface IWGBPlatformExtensions
    {
        PropertyInfo ExtGetProperty(Type type, string propertyName);
        EventInfo ExtGetEvent(Type type, string eventName);
        MethodInfo ExtGetMethod(Type type, string methodName);
        IEnumerable<MethodInfo> ExtGetMethods(Type type, string methodName);
        FieldInfo ExtGetField(Type type, string fieldName);
        Type ExtGetNestedType(Type type, string typeName);
        Delegate ExtCreateDelegate(MethodInfo methodInfo, Type delegateType, object target);
    }
    
    public static class WGBPlatformExtensions
    {
        static void CreatePlatformExtObj()
        {
            if (s_PlatformExtensions == null)
            {
                var platformExtensionsType =
                    Type.GetType("Thinksquirrel.WordGameBuilder.Internal.WGBPlatformExtensionsImpl") ??
                    Type.GetType("Thinksquirrel.WordGameBuilder.Internal.WGBPlatformExtensionsImpl, Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null") ??
                    Type.GetType("Thinksquirrel.WordGameBuilder.Internal.WGBPlatformExtensionsImpl, Assembly-CSharp-firstpass, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
                
                if (platformExtensionsType != null)
                {
                    s_PlatformExtensions =
                        (IWGBPlatformExtensions)Activator.CreateInstance(platformExtensionsType, true);
                }
            }
        }

        static IWGBPlatformExtensions s_PlatformExtensions;
        public static PropertyInfo ExtGetProperty(this Type type, string propertyName)
        {
            CreatePlatformExtObj();
            return s_PlatformExtensions != null ? s_PlatformExtensions.ExtGetProperty(type, propertyName) : null;
        }
        public static EventInfo ExtGetEvent(this Type type, string eventName)
        {
            CreatePlatformExtObj();
            return s_PlatformExtensions != null ? s_PlatformExtensions.ExtGetEvent(type, eventName) : null;
        }
        public static MethodInfo ExtGetMethod(this Type type, string methodName)
        {
            CreatePlatformExtObj();
            return s_PlatformExtensions != null ? s_PlatformExtensions.ExtGetMethod(type, methodName) : null;
        }
        public static IEnumerable<MethodInfo> ExtGetMethods(this Type type, string methodName)
        {
            CreatePlatformExtObj();
            return s_PlatformExtensions != null ? s_PlatformExtensions.ExtGetMethods(type, methodName) : null;
        }
        public static FieldInfo ExtGetField(this Type type, string fieldName)
        {
            CreatePlatformExtObj();
            return s_PlatformExtensions != null ? s_PlatformExtensions.ExtGetField(type, fieldName) : null;
        }
        public static Type ExtGetNestedType(this Type type, string typeName)
        {
            CreatePlatformExtObj();
            return s_PlatformExtensions != null ? s_PlatformExtensions.ExtGetNestedType(type, typeName) : null;
        }
        public static Delegate ExtCreateDelegate(this MethodInfo methodInfo, Type delegateType, object target)
        {
            CreatePlatformExtObj();
            return s_PlatformExtensions != null ? s_PlatformExtensions.ExtCreateDelegate(methodInfo, delegateType, target) : null;
        }
    }
    //! \endcond
}