// WordGameAgent.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilder.Internal;
using System.Collections;

namespace Thinksquirrel.WordGameBuilder.Gameplay
{
    /// <summary>
    /// Represents a word game AI agent. The agent is multithreaded and supports automatic selection/submission.
    /// </summary>
    /// <remarks>
    /// This component requires a WordGamePlayer to be present. Letter tile implementations that use ISelectableLetterTile will obey selection rules.
    /// </remarks>
    [RequireComponent(typeof(IWordGamePlayer))]
    [AddComponentMenu("Word Game Builder/Gameplay/Word Game Agent")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Gameplay.WordGameAgent")]
    public sealed class WordGameAgent : WGBBase, IWordGameAgent
    {
        /// <summary>
        /// If true, ignore the player's inputEnabled property.
        /// </summary>
        public bool ignorePlayerInputState { get { return m_IgnorePlayerInputState; } set { m_IgnorePlayerInputState = value; } }
        /// <summary>
        /// Controls how many candidate words are kept when sorted by score.
        /// </summary>
        public int threshold { get { return m_Threshold; } set { m_Threshold = value; } }
        /// <summary>
        /// A value between 0 and 1 that controls how aggressive or "intelligent" the agent is at getting words.
        /// </summary>
        /// <remarks>
        /// A value of 0 will pick a random word from the top candidates. A value of 1 will always find the highest-scoring word from the top candidates.
        /// </remarks>
        public float bias { get { return m_Bias; } set { m_Bias = value; } }
        /// <summary>
        /// The minimum amount of letters for a candidate word.
        /// </summary>
        public int minWordLength { get { return m_MinWordLength; } set { m_MinWordLength = value; } }
        /// <summary>
        /// The maximum amount of letters for a candidate word.
        /// </summary>
        public int maxWordLength { get { return m_MaxWordLength; } set { m_MaxWordLength = value; } }
        /// <summary>
        /// For long words (over a word set's max prefix length), a prefix check is performed to speed up the algorithm.
        /// This value controls the maximum number of iterations to perform with the prefix check.
        /// </summary>
        /// <remarks>
        /// Higher iteration counts take more processing and memory power, but produce more accurate results.
        /// </remarks>
        public int maxPrefixIterations { get { return m_MaxPrefixIterations; } set { m_MaxPrefixIterations = value; } }
        /// <summary>
        /// The maximum amount of words to find before selecting a candidate.
        /// </summary>
        public int maxWords { get { return m_MaxWords; } set { m_MaxWords = value; } }
        /// <summary>
        /// The maximum amount of time (in seconds) to look for words before selecting a candidate or retrying/giving up.
        /// </summary>
        public float maxTime { get { return m_MaxTime; } set { m_MaxTime = value; } }
        /// <summary>
        /// The maximum amount of times to retry a search, if a root has not yet been searched.
        /// </summary>
        /// <remarks>
        /// Retries will only happen if a root hasn't been searched (All words starting with a specific tile).
        /// </remarks>
        public int retryCount { get { return m_RetryCount; } set { m_RetryCount = value; } }
        /// <summary>
        /// If true, blank tiles will be processed as wildcard tiles.
        /// </summary>
        public bool processWildcards { get { return m_ProcessWildcards; } set { m_ProcessWildcards = value; } }
        /// <summary>
        /// If true, selecting wildcard tiles will be calculated using a custom point value.
        /// </summary>
        public bool customWildcardScoring { get { return m_CustomWildcardScoring; } set { m_CustomWildcardScoring = value; } }
        /// <summary>
        /// If customWildcardScoring = true, the custom point value to assign to wildcard tiles.
        /// </summary>
        public int customWildcardScore { get { return m_CustomWildcardScore; } set { m_CustomWildcardScore = value; } }
        /// <summary>
        /// A dictionary that can be modified to have more fine grained control over the scoring for wildcard tiles.
        /// </summary>
        public Dictionary<Letter, int> customWildcardScores { get { return m_CustomWildcardScores; } }
        /// <summary>
        /// If enabled, automatically select the best found word.
        /// </summary>
        public bool autoSelectWord { get { return m_AutoSelectWord; } set { m_AutoSelectWord = value; } }
        /// <summary>
        /// If autoSelectWord is enabled, the amount of time to wait between selecting tiles.
        /// </summary>
        public float autoSelectTime { get { return m_AutoSelectTime; } set { m_AutoSelectTime = value; } }
        /// <summary>
        /// If enabled, automatically submit the best found word. This has no effect if autoSelectWord is disabled.
        /// </summary>
        public bool autoSubmitWord { get { return m_AutoSubmitWord; } set { m_AutoSubmitWord = value; } }
        /// <summary>
        /// If autoSubmitWord is enabled, the amount of time to wait before submitting tiles. This has no effect if autoSelectWord is disabled.
        /// </summary>
        public float autoSubmitTime { get { return m_AutoSubmitTime; } set { m_AutoSubmitTime = value; } }
        /// <summary>
        /// This event fires whenever the agent has found a set of words.
        /// </summary>
        /// <remarks>
        /// Note that this will fire immediately after a set of words has been found, even if words are being automatically selected.
        ///
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentPlayer
        /// * WGBEvent.currentAgent
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGameAgent.onFindWords">IWordGameAgent</see>.
        /// </remarks>
        public WGBEvent onFindWords { get { return m_OnFindWords; } set { m_OnFindWords = value; } }
        /// <summary>
        /// Gets information about the last agent search. This is set right before event callbacks.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWordGameAgent.lastSearchInfo">IWordGameAgent</see>.
        /// </remarks>
        public AgentSearchInfo lastSearchInfo { get { return m_LastSearchInfo; } }

        IWordGamePlayer m_Player;
        Graph<int> m_Graph;

        System.Random m_Random = new System.Random();

        List<Letter> m_Letters = new List<Letter>();
        List<int> m_CurrentCandidate = new List<int>();
        List<int> m_LetterLengths = new List<int>();
        List<List<int>> m_Candidates = new List<List<int>>();
        int m_CandidateCount;
        List<string> m_CandidateWords = new List<string>();
        List<string> m_CandidateChars = new List<string>();
        List<int> m_CandidateScores = new List<int>();
        List<int> m_ToVisit = new List<int>();
        HashSet<int> m_WordSoFar = new HashSet<int>();
        HashSet<int> m_Roots = new HashSet<int>();
        StringBuilder m_StringBuilder = new StringBuilder();
        StringBuilder m_StringBuilderText = new StringBuilder();
        List<string> m_MaxPrefixList = new List<string>();
        ILetterTile[] m_TempArray = new ILetterTile[1];
        List<int> m_IndicesShuffle = new List<int>();
        List<string> m_CandidateWordsCached = new List<string>();
        List<ILetterTile> m_BestTilesCached = new List<ILetterTile>();
        Dictionary<Letter, int> m_CustomWildcardScores = new Dictionary<Letter, int>();

        AgentSearchInfo m_LastSearchInfo;

        AsyncTask m_Task;
        bool m_SelectingWord;
        bool m_SubmittingWord;
        readonly object m_TaskLock = new object();

        // For Unity serialization
        [SerializeField] bool m_IgnorePlayerInputState;
        [SerializeField] int m_Threshold = 25;
        [Range(0.0f, 1.0f), SerializeField] float m_Bias = .75f;
        [SerializeField] int m_MinWordLength = 1;
        [SerializeField] int m_MaxWordLength = 6;
        [SerializeField] int m_MaxPrefixIterations = 1000;
        [SerializeField] int m_MaxWords = 500;
        [SerializeField] float m_MaxTime = 5f;
        [SerializeField] int m_RetryCount = 4;
        [SerializeField] bool m_ProcessWildcards = true;
        [SerializeField] bool m_CustomWildcardScoring;
        [SerializeField] int m_CustomWildcardScore;
        [SerializeField] bool m_AutoSelectWord = true;
        [SerializeField] float m_AutoSelectTime = .3f;
        [SerializeField] bool m_AutoSubmitWord = true;
        [SerializeField] float m_AutoSubmitTime = .25f;

        [SerializeField] WGBEvent m_OnFindWords;

        void OnEnable()
        {
            m_Player = GetComponentFromInterface<IWordGamePlayer>();
            m_Player.onWordResult += OnWordResultAgent;
            m_LastSearchInfo = new AgentSearchInfo();
        }

        void OnDisable()
        {
            if (m_Player != null)
                m_Player.onWordResult -= OnWordResultAgent;
        }

        void GenerateGraph(IList<ILetterTile> list)
        {
            m_Graph = m_Graph ?? new Graph<int>();

            for (int i = 0; i < list.Count; ++i)
                m_Graph.Add(i);

            for(int i = m_Graph.nodeCount - 1; i >= list.Count; --i)
                m_Graph.RemoveAt(i);

            for (int i = 0; i < m_Graph.nodeCount; ++i)
            {
                var nodeA = m_Graph [i];

                if (nodeA == null)
                    continue;

                var indexA = nodeA.value;
                var tileA = GetTile(indexA, list) as ISelectableLetterTile;

                for (int j = 0; j < m_Graph.nodeCount; ++j)
                {
                    var nodeB = m_Graph [j];

                    if (nodeB == null)
                        continue;

                    var indexB = nodeB.value;
                    var tileB = GetTile(indexB, list) as ISelectableLetterTile;

                    if (tileA != null && tileB != null)
                    {
                        m_TempArray [0] = tileA;

                        bool deselect;

                        if (tileB.CanSelectTile(m_TempArray, out deselect) && !deselect)
                            m_Graph.AddDirectedEdge(nodeA, nodeB, 0);

                        m_TempArray [0] = tileB;

                        if (tileA.CanSelectTile(m_TempArray, out deselect) && !deselect)
                            m_Graph.AddDirectedEdge(nodeB, nodeA, 0);
                    }
                }
            }
        }

        static ILetterTile GetTile(int index, IList<ILetterTile> list)
        {
            return index < list.Count ? list[index] : null;
        }

        void AddCandidate(IList<ILetterTile> list, WordResult result, IList<int> word, string wordString, string wordChars, int currentCandidateCount, bool multiplyByPermutations)
        {
            var candidateScore = 0;
            var candidateCount = Mathf.Min(currentCandidateCount, m_Candidates.Count);

            for (int i = 0; i < word.Count; ++i)
            {
                var index = word [i];
                var letterTile = GetTile(index, list);

                candidateScore += letterTile.currentPointValue;
            }

            if (multiplyByPermutations)
            {
                candidateScore *= result.allWords == null ? 1 : result.allWords.Count;
            }

            if (candidateCount < m_Candidates.Count)
            {
                m_Candidates[currentCandidateCount].Clear();
                m_Candidates[currentCandidateCount].AddRange(word);
                m_CandidateWords[currentCandidateCount] = wordString;
                m_CandidateChars[currentCandidateCount] = wordChars;
                m_CandidateScores[currentCandidateCount] = candidateScore;
            }
            else
            {
                int lowestScore = int.MaxValue;
                int lowestIndex = -1;

                for (int i = 0; i < candidateCount; ++i)
                {
                    var score = m_CandidateScores [i];

                    if (score < lowestScore)
                    {
                        lowestScore = score;
                        lowestIndex = i;
                    }
                }

                if (lowestIndex >= 0)
                {
                    m_Candidates[lowestIndex].Clear();
                    m_Candidates[lowestIndex].AddRange(word);
                    m_CandidateWords[lowestIndex] = wordString;
                    m_CandidateChars[lowestIndex] = wordChars;
                    m_CandidateScores[lowestIndex] = candidateScore;
                }
            }

        }

        int GetBestCandidateIndex(float bias)
        {
            // A range between 1 and 2
            bias = Mathf.Clamp01(bias) + 1f;

            int totalWeight = 0;
            int len = Mathf.Min(m_CandidateScores.Count, m_CandidateCount);

            if (len == 0) return -1;

            int selected = 0;

            // Special case, bias is min - we get a totally random choice
            if (bias <= 1)
            {
                return m_Random.Next(0, len);
            }

            // Special case, bias is max - we get the best choice
            if (bias >= 2)
            {
                int w = int.MinValue;
                for(int i = 0; i < len; ++i)
                {
                    int weight = m_CandidateScores[i];
                    if (weight > w)
                    {
                        w = weight;
                        selected = i;
                    }
                }

                return selected;
            }

            // Weighted candidate choice
            for(int i = 0; i < len; ++i)
            {
                // Skew the weights based on bias
                totalWeight += (int)(Mathf.Pow(m_CandidateScores[i], bias));
            }

            // Special case, total weight is 0 - we get a totally random choice
            if (totalWeight <= 0)
            {
                return m_Random.Next(0, len);
            }

            int randomNumber = m_Random.Next(0, totalWeight);

            for(int i = 0; i < len; ++i)
            {
                int weight = m_CandidateScores[i];
                if (randomNumber < weight)
                {
                    selected = i;
                    break;
                }

                randomNumber = randomNumber - weight;
            }

            return selected;
        }

        void ClearData(int randomIteratorCount)
        {
            m_IndicesShuffle.Clear();

            for(int i = 0; i < randomIteratorCount; ++i)
            {
                m_IndicesShuffle.Add(i);
            }

            m_IndicesShuffle.Shuffle(m_Random);

            m_CurrentCandidate.Clear();
            m_LetterLengths.Clear();
            for (int i = 0; i < m_Threshold; ++i)
            {
                if (i >= m_Candidates.Count)
                {
                    m_Candidates.Add(new List<int>());
                    m_CandidateWords.Add(string.Empty);
                    m_CandidateChars.Add(string.Empty);
                    m_CandidateScores.Add(int.MaxValue);
                }
                else
                {
                    m_Candidates[i].Clear();
                    m_CandidateWords[i] = string.Empty;
                    m_CandidateChars[i] = string.Empty;
                    m_CandidateScores[i] = int.MaxValue;
                }
            }
            for (int i = m_Candidates.Count - 1; i >= m_Threshold; --i)
            {
                m_Candidates.RemoveAt(i);
                m_CandidateWords.RemoveAt(i);
                m_CandidateChars.RemoveAt(i);
                m_CandidateScores.RemoveAt(i);
            }
        }

        bool CheckPrefix(WordGameLanguage language, string word)
        {
            if (word.Length > WordSet.k_MaxPrefixLength * 10)
            {
                return language.wordSet.Contains(word, maxWordLength, m_MaxPrefixIterations, m_MaxPrefixList) > 0;
            }

            return true;
        }

        static int PeekOrDefault(IList<int> stack)
        {
            return stack.Count == 0 ? -1 : stack.Peek();
        }

        static void PushReverse(ICollection<int> stack, IList<Node<int>> neighbors, ICollection<int> collection)
        {
            for (int i = neighbors.Count - 1; i >= 0; --i)
            {
                int ind = neighbors[i].value;

                if (!collection.Contains(ind))
                {
                    stack.Push(ind);
                }
            }
        }

        ulong Factorial(ulong i)
        {
            if (i <= 1)
                return 1;
            return i * Factorial(i - 1);
        }

        ulong Factorial(int n)
        {
            return Factorial((ulong)n);
        }

        static bool CheckMaxWords(int candidateCount, int maxWords)
        {
            if (candidateCount >= maxWords)
            {
                WGBBase.Log("Agent search hit maximum word count", "Word Game Builder", "WordGameAgent");
                return true;
            }

            return false;
        }
        static bool CheckMaxQueries(ulong q, ulong maxQueries)
        {
            if (q >= maxQueries)
            {
                WGBBase.Log("Agent search hit maximum query count", "Word Game Builder", "WordGameAgent");
                return true;
            }

            return false;
        }
        static bool CheckTask(AsyncTask task, bool log = true)
        {
            if ((task != null && task.shouldAbort))
            {
                if (log) WGBBase.Log("Agent search was aborted", "Word Game Builder", "WordGameAgent");
                return true;
            }

            return false;
        }
        static bool CheckTime(System.DateTime startTime, double maxTime)
        {
            var ms = (System.DateTime.UtcNow - startTime).TotalMilliseconds;
            if (ms > maxTime)
            {
                WGBBase.Log(string.Format("Agent search timed out ({0}ms)", ms), "Word Game Builder", "WordGameAgent");
                return true;
            }

            return false;
        }
        int Search(WordGameLanguage language, IList<ILetterTile> list, Graph<int> graph, bool ordered, bool multiplyByPermutations, System.DateTime startTime, double maxTime, AsyncTask task)
        {
            if (list == null || graph == null || list.Count < Mathf.Max(1, m_MinWordLength))
                return 0;

            int count = list.Count;

            ClearData(count);

            ulong q = 0;
            int candidateCount = 0;
            ulong max = System.Math.Min((ulong)Mathf.Pow(count, language.letters.Count), ulong.MaxValue);

            // A flag to end the main loop
            bool breakMainLoop = false;

            // For each root
            for (int ind = 0; ind < count; ++ind)
            {
                // Iterate randomly
                int i = m_IndicesShuffle[ind];

                // Check for max words, queries, time, and task
                if (CheckMaxWords(candidateCount, maxWords)) break;
                if (CheckMaxQueries(q, max)) break;
                if (CheckTime(startTime, maxTime)) break;
                if (CheckTask(task)) break;

                // Skip if we're retrying and already tried this root
                if (m_Roots.Contains(i))
                {
                    continue;
                }

                // Add this root so that it is not repeated later.
                m_Roots.Add(i);

                // Clear the word so far
                m_StringBuilder.Remove(0, m_StringBuilder.Length);
                m_StringBuilderText.Remove(0, m_StringBuilderText.Length);
                m_CurrentCandidate.Clear();
                m_LetterLengths.Clear();
                m_WordSoFar.Clear();

                // Clear the nodes we want to visit, and the ancestor nodes that have already been visited
                m_ToVisit.Clear();

                // Push the root node onto the stack
                m_ToVisit.Push(i);

                // Continue this loop until the stack is empty
                while (m_ToVisit.Count > 0)
                {
                    // Check for max words, queries, time, and task
                    if (CheckMaxWords(candidateCount, maxWords)) { breakMainLoop = true; break; }
                    if (CheckMaxQueries(q, max)) { breakMainLoop = true; break; }
                    if (CheckTime(startTime, maxTime)) { breakMainLoop = true; break; }
                    if (CheckTask(task)) { breakMainLoop = true; break; }

                    // Get the current letter tile
                    var index = m_ToVisit.Peek();
                    var item = GetTile(index, list);

                    // Ignore null items entirely
                    if (item == null)
                        continue;

                    // Ignore blank tiles if we aren't processing wildcards
                    if (!item.currentLetter.hasValue && !processWildcards)
                        continue;

                    // We entirely skip tiles that are already a part of our current word
                    // We also entirely skip tiles if we're over the max word length
                    if (m_WordSoFar.Count < maxWordLength && !m_WordSoFar.Contains(index))
                    {
                        // Add the current node to the word so far
                        m_WordSoFar.Add(index);

                        // Check for a letter value
                        // Blank tiles are handled differently below.
                        if (item.currentLetter.hasValue)
                        {
                            // Get the letter representation of our node
                            var letterChar = item.currentLetter.character;
                            var letterText = item.currentLetter.text;

                            // Append the current node to the string builders and candidate list
                            m_StringBuilder.Append(letterChar);
                            m_StringBuilderText.Append(letterText);
                            m_CurrentCandidate.Add(index);
                            m_LetterLengths.Add(letterText.Length);

                            // Get the current machine word for checking
                            string machineWord = m_StringBuilder.ToString();

                            // Check the prefix to speed up the algorithm a bit
                            if (CheckPrefix(language, machineWord))
                            {
                                // Check time and task
                                if (CheckTime(startTime, maxTime)) { breakMainLoop = true; break; }
                                if (CheckTask(task)) { breakMainLoop = true; break; }

                                // If we are not up to minimum letters yet, don't bother checking for a candidate
                                if (m_StringBuilder.Length >= m_MinWordLength)
                                {
                                    // Check word
                                    var result = language.wordSet.FindWord(machineWord, ordered && !multiplyByPermutations);
                                    bool valid = (result.wasOrdered && result.isValid) || (!result.wasOrdered && ordered && result.allWords != null && result.allWords.Contains(result.input)) || (!result.wasOrdered && !ordered);

                                    // Add query count
                                    q++;

                                    // We found a valid word!
                                    if (valid)
                                    {
                                        // Get the actual word
                                        string word = m_StringBuilderText.ToString();

                                        // Add word as a candidate
                                        AddCandidate(list, result, m_CurrentCandidate, word, machineWord, candidateCount, multiplyByPermutations);
                                        candidateCount++;

                                        // Check time and task
                                        if (CheckTime(startTime, maxTime)) { breakMainLoop = true; break; }
                                        if (CheckTask(task)) { breakMainLoop = true; break; }
                                    }
                                }

                                // We at least found a prefix, so we keep going
                                // Find the graph representation of this node
                                var node = graph.Find(index);

                                if (node != null && node.neighbors.Count > 0)
                                {
                                    // Push, in reverse order, this node's neighbors.
                                    // Don't push any of the current letters onto the stack.
                                    PushReverse(m_ToVisit, node.neighbors, m_WordSoFar);
                                    continue;
                               }
                            }
                        }
                        // Wildcard tiles - we process these as every letter, as "sub-roots"
                        else
                        {
                            // Shuffle the letter list to eliminate bias
                            m_Letters.Shuffle(m_Random);

                            for(int j = 0; j < m_Letters.Count; ++j)
                            {
                                // Get the current wildcard letter
                                var letter = m_Letters[j];

                                // Get the letter representation of our node
                                var letterChar = letter.character;
                                var letterText = letter.text;

                                // Append the current node to the string builders and candidate list
                                m_StringBuilder.Append(letterChar);
                                m_StringBuilderText.Append(letterText);
                                m_CurrentCandidate.Add(index);
                                m_LetterLengths.Add(letterText.Length);

                                // Get the current machine word for checking
                                string machineWord = m_StringBuilder.ToString();

                                // Check the prefix to speed up the algorithm a bit
                                if (CheckPrefix(language, machineWord))
                                {
                                    // Check time and task
                                    if (CheckTime(startTime, maxTime)) { breakMainLoop = true; break; }
                                    if (CheckTask(task)) { breakMainLoop = true; break; }

                                    // If we are not up to minimum letters yet, don't bother checking for a candidate
                                    if (m_StringBuilder.Length >= m_MinWordLength)
                                    {
                                        // Check word
                                        var result = language.wordSet.FindWord(machineWord, ordered && !multiplyByPermutations);
                                        bool valid = (result.wasOrdered && result.isValid) || (!result.wasOrdered && ordered && result.allWords != null && result.allWords.Contains(result.input)) || (!result.wasOrdered && !ordered);

                                        // Add query count
                                        q++;

                                        // We found a valid word!
                                        if (valid)
                                        {
                                            // Get the actual word
                                            string word = m_StringBuilderText.ToString();

                                            // Add word as a candidate
                                            AddCandidate(list, result, m_CurrentCandidate, word, machineWord, candidateCount, multiplyByPermutations);
                                            candidateCount++;

                                            // Check time and task
                                            if (CheckTime(startTime, maxTime)) { breakMainLoop = true; break; }
                                            if (CheckTask(task)) { breakMainLoop = true; break; }
                                        }
                                    }

                                    // We at least found a prefix, so we keep going
                                    // Find the graph representation of this node
                                    var node = graph.Find(index);

                                    if (node != null && node.neighbors.Count > 0)
                                    {
                                        // Push, in reverse order, this node's neighbors.
                                        // Don't push any of the current letters onto the stack.
                                        PushReverse(m_ToVisit, node.neighbors, m_WordSoFar);
                                        break;
                                    }
                                }

                                // If we're here, we've hit an end node. We remove this letter from our word so far, pop this letter from the stack,
                                // And continue with another wildcard letter.
                                var addedLetterLength = letterText.Length;
                                m_StringBuilder.Remove(m_StringBuilder.Length - 1, 1);
                                m_StringBuilderText.Remove(m_StringBuilderText.Length - addedLetterLength, addedLetterLength);
                                m_CurrentCandidate.RemoveAt(m_CurrentCandidate.Count - 1);
                                m_LetterLengths.RemoveAt(m_LetterLengths.Count - 1);
                            }

                            // We need to break out of the loop entirely if tha main break flag was set
                            if (breakMainLoop) break;

                            // Pop this node from the visited stack
                            m_ToVisit.Pop();
                        }

                        // We don't need to remove a letter if we're past this point
                        continue;
                    }

                    // If we're here, we've hit an end node. We remove this letter from our word so far and pop this letter from the stack.
                    if (m_WordSoFar.Contains(index))
                    {
                        var addedLetterLength = m_LetterLengths[m_LetterLengths.Count - 1];
                        m_StringBuilder.Remove(m_StringBuilder.Length - 1, 1);
                        m_StringBuilderText.Remove(m_StringBuilderText.Length - addedLetterLength, addedLetterLength);
                        m_CurrentCandidate.RemoveAt(m_CurrentCandidate.Count - 1);
                        m_LetterLengths.RemoveAt(m_LetterLengths.Count - 1);

                        m_WordSoFar.Remove(index);
                    }

                    // Pop this node from the visited stack
                    m_ToVisit.Pop();
                }

                // We need to break out of the loop entirely if tha main break flag was set
                if (breakMainLoop) break;
            }

            return Mathf.Min(candidateCount, m_Candidates.Count);
        }

        public AsyncTask FindWords()
        {
            return m_Player == null ? AsyncTask.Empty() :
                FindWords(m_Player.heldTiles, m_AutoSelectWord, m_AutoSelectTime, m_AutoSubmitWord, m_AutoSubmitTime);
        }

        public AsyncTask FindWords(IList<ILetterTile> tiles)
        {
            return FindWords(tiles, m_AutoSelectWord, m_AutoSelectTime, m_AutoSubmitWord, m_AutoSubmitTime);
        }

        /// <summary>
        /// Finds a set of words, based on a list of letter tiles.
        /// </summary>
        /// <param name="tiles">A list of letter tiles to use when searching for words.</param>
        /// <param name="selectWord">If true, automatically select a word after finding it.</param>
        /// <param name="selectionTime">The amount of time to spend between selecting each letter if selectWord is true.</param>
        /// <param name="submitWord">If true, automatically submit a word after finding it. This has no effect if selectWord is false.</param>
        /// <param name="submissionTime">The amount of time to wait before submitting a word if submitWord is true.</param>
        /// <returns>
        /// A task object representing the asynchronous task. If a task is already running, the previous task will be aborted.
        /// If a player has not been selected, an empty task is returned and no callbacks are run.
        /// </returns>
        public AsyncTask FindWords(IList<ILetterTile> tiles, bool selectWord, float selectionTime, bool submitWord, float submissionTime)
        {
            if (m_Player == null)
                return AsyncTask.Empty();

            Stop();
            var language = WordGameLanguage.current;
            m_Letters.Clear();
            m_Letters.AddRange(WordGameLanguage.current.letters);

            var ordered = m_Player.orderedWordCheck;
            var multiplyByPermutations = m_Player.multiplyByPermutations;
            var mTime = m_MaxTime * 1000.0;
            var tries = m_RetryCount + 1;

            GenerateGraph(tiles);
            var graph = m_Graph;

            Action<AsyncTask> action = task =>
            {
                try
                {
                    if (CheckTask(task))
                    {
                        m_SubmittingWord = false;
                        m_SelectingWord = false;
                        return;
                    }

                    lock (m_TaskLock)
                    {
                        var candidateCount = 0;
                        m_Roots.Clear();

                        for(var i = 0; i < tries; ++i)
                        {
                            var time = DateTime.UtcNow;
                            candidateCount = Search(language, tiles, graph, ordered, multiplyByPermutations, time, mTime, task);

                            if (candidateCount > 0)
                                break;

                            if (m_Roots.Count >= tiles.Count)
                                break;

                            if (CheckTask(task, false))
                            {
                                m_SubmittingWord = false;
                                m_SelectingWord = false;
                                return;
                            }
                        }

                        m_CandidateCount = candidateCount;
                    }
                }
                catch (Exception e)
                {
                    WGBBase.LogWarning(e, "Word Game Builder", "WordGameAgent");
                    task.Abort();
                    return;
                }

                if (CheckTask(task, false))
                {
                    m_SubmittingWord = false;
                    m_SelectingWord = false;
                    return;
                }

                AsyncTask.Dispatch(callbackTask =>
                {
                    try
                    {
                        if (CheckTask(task))
                        {
                            m_SubmittingWord = false;
                            m_SelectingWord = false;
                            return;
                        }

                        var bestIndex = GetSearchInfo(tiles);

                        WGBEvent.Invoke(m_OnFindWords, null, null, null, null, m_Player, this);

                        if (CheckTask(task))
                        {
                            m_SubmittingWord = false;
                            m_SelectingWord = false;
                            return;
                        }

                        if (selectWord)
                        {
                            if (!m_OnFindWords) bestIndex = GetBestCandidateIndex(m_Bias);
                            SelectWord(tiles, callbackTask, language, selectionTime, submitWord, submissionTime, bestIndex);
                        }
                    }
                    catch (Exception e)
                    {
                        callbackTask.Abort();
                        LogWarning(e, "Word Game Builder", "WordGameAgent");
                        task.Abort();
                        return;
                    }
                });
            };
            
            m_Task = AsyncTask.Create(action);
            return m_Task;
        }


        public void Stop()
        {
            Stop(m_Task);
        }

        void Stop(AsyncTask task)
        {
            StopAllCoroutines();

            if (task != null)
            {
                task.AbortWaitForSeconds(1);
            }

            m_SubmittingWord = false;
            m_SelectingWord = false;
        }

        int GetSearchInfo(IList<ILetterTile> list)
        {
            m_CandidateWordsCached.Clear();
            m_BestTilesCached.Clear();

            int bestIndex = GetBestCandidateIndex(m_Bias);

            if (bestIndex < 0)
            {
                m_LastSearchInfo.candidateWords = null;
                m_LastSearchInfo.bestWordTiles = null;
                m_LastSearchInfo.bestWord = null;
                m_LastSearchInfo.wasSuccessful = false;
                m_LastSearchInfo.wordCount = 0;
                return bestIndex;
            }

            m_LastSearchInfo.candidateWords = m_CandidateWordsCached;
            m_LastSearchInfo.bestWordTiles = m_BestTilesCached;

            for(int i = 0; i < m_CandidateCount; ++i)
                m_CandidateWordsCached.Add(m_CandidateWords[i]);

            m_LastSearchInfo.bestWord = m_CandidateWordsCached[bestIndex];

            var candidate = m_Candidates[bestIndex];

            for(int i = 0; i < candidate.Count; ++i)
                m_BestTilesCached.Add(GetTile(candidate[i], list));

            m_LastSearchInfo.wordCount = m_CandidateCount;
            m_LastSearchInfo.wasSuccessful = true;
            return bestIndex;
        }

        void SelectWord(IList<ILetterTile> tiles, AsyncTask callbackTask, WordGameLanguage language, float selectionTime, bool submitWord, float submissionTime, int bestIndex)
        {
            if (m_CandidateCount <= 0)
                return;

            if (CheckTask(callbackTask)) return;

            if (!m_SelectingWord && !m_SubmittingWord && m_Player != null && (m_Player.inputEnabled || m_IgnorePlayerInputState))
            {
                YieldInstruction selectionWait = new WaitForSeconds(selectionTime);
                YieldInstruction submissionWait = submitWord ? new WaitForSeconds(submissionTime) : null;
                StartCoroutine(DoSelectWord(tiles, callbackTask, language, selectionWait, submissionWait, submitWord, bestIndex));
                StartCoroutine(BlockPlayerInput());
            }
        }

        IEnumerator BlockPlayerInput()
        {
            var enableAfterFinished = false;
            while (m_SelectingWord || m_SubmittingWord)
            {
                if (m_Player.inputEnabled)
                {
                    enableAfterFinished = true;
                }
                m_Player.inputEnabled = false;
                yield return null;
            }

            if (enableAfterFinished)
            {
                m_Player.inputEnabled = true;
            }
        }

        IEnumerator DoSelectWord(IList<ILetterTile> tiles, AsyncTask task, WordGameLanguage language, object selectionWait, object submissionWait, bool submitWord, int bestIndex)
        {
            m_SelectingWord = true;

            yield return null;

            if (CheckTask(task))
            {
                m_SubmittingWord = false;
                m_SelectingWord = false;
                yield break;
            }

            m_Player.ClearSelection();

            if (bestIndex < 0 || bestIndex >= m_Candidates.Count)
            {
                m_SubmittingWord = false;
                m_SelectingWord = false;
                yield break;
            }

            int letterCount = m_Candidates[bestIndex].Count;

            if (letterCount <= 0)
            {
                m_SubmittingWord = false;
                m_SelectingWord = false;
                yield break;
            }

            for (int j = 0; j < letterCount; ++j)
            {
                if (bestIndex < 0 || bestIndex >= m_Candidates.Count || letterCount != m_Candidates[bestIndex].Count)
                {
                    m_SubmittingWord = false;
                    m_SelectingWord = false;
                    yield break;
                }
                int index = m_Candidates[bestIndex][j];

                // Language or letters have changed and result is no longer valid
                if (index < 0 || index >= tiles.Count)
                {
                    m_SubmittingWord = false;
                    m_SelectingWord = false;
                    yield break;
                }

                var tile = tiles[index];

                if (!tile.currentLetter.hasValue)
                {
                    var letter = language.GetLetter(m_CandidateChars[bestIndex][j]);
                    int score = letter.score;

                    if (m_CustomWildcardScoring)
                    {
                        if (!m_CustomWildcardScores.TryGetValue(letter, out score))
                            score = m_CustomWildcardScore;
                    }
                    tile.SetWildcard(letter, score);
                }

                m_Player.SelectTile(tile);

                yield return selectionWait;

                if (CheckTask(task))
                {
                    m_SubmittingWord = false;
                    m_SelectingWord = false;
                    yield break;
                }
            }

            if (submitWord)
            {
                m_SubmittingWord = true;

                yield return submissionWait;

                m_Player.SubmitWord();
            }
            else
            {
                m_SubmittingWord = false;
            }

            m_SelectingWord = false;
        }
        void OnWordResultAgent()
        {
            var result = WGBEvent.currentPlayer.lastResult;

            if (!result.isValid)
            {
                m_Player.ClearSelection();
            }

            m_SubmittingWord = false;
        }

    }

    /// <summary>
    /// Represents search information from a Word Game Agent.
    /// </summary>
    public sealed class AgentSearchInfo
    {
        /// <summary>
        /// The amount of words that were found.
        /// </summary>
        public int wordCount { get; internal set; }
        /// <summary>
        /// All candidate words that were found.
        /// </summary>
        public IList<string> candidateWords { get; internal set; }
        /// <summary>
        /// The "best" word, selected by the agent from the list of candidate words.
        /// </summary>
        public string bestWord { get; internal set; }
        /// <summary>
        /// The tiles that represent the best word.
        /// </summary>
        public IList<ILetterTile> bestWordTiles { get; internal set; }
        /// <summary>
        /// If true, the last search was successful.
        /// </summary>
        public bool wasSuccessful { get; internal set; }
    }

    //! \cond PRIVATE
    static class AgentListExtensions
    {
        internal static T Pop<T>(this IList<T> theList)
        {
            var local = theList [theList.Count - 1];
            theList.RemoveAt(theList.Count - 1);
            return local;
        }

        internal static void Push<T>(this ICollection<T> theList, T item)
        {
            theList.Add(item);
        }

        internal static T Peek<T>(this IList<T> theList)
        {
            var local = theList [theList.Count - 1];
            return local;
        }
    }
    //! \endcond
}
