// WordResult.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Represents a result from a word lookup operation.
    /// </summary>
    /// <remarks>
    /// Note that this type is passed by value for performance reasons.
    /// </remarks>
    public struct WordResult
    {
        readonly string m_Input;
        readonly string m_Word;
        readonly IList<string> m_AllWords;
        readonly bool m_IsValid;
        readonly bool m_WasOrdered;
        readonly bool m_HasValue;

        /// <summary>
        /// All words returned from the lookup operation.
        /// </summary>
        public IList<string> allWords
        {
            get
            {
                return m_AllWords;
            }
        }

        /// <summary>
        /// Whether or not the result is empty.
        /// </summary>
        /// <remarks>
        /// This only returns false as a result of an invalid word lookup operation.
        /// </remarks>
        public bool hasValue
        {
            get
            {
                return m_HasValue;
            }
        }

        /// <summary>
        /// The input string for the lookup operation.
        /// </summary>
        public string input
        {
            get
            {
                return m_Input;
            }
        }

        /// <summary>
        /// Whether or not the result is valid (at least one word was found).
        /// </summary>
        public bool isValid
        {
            get
            {
                return m_IsValid;
            }
        }

        /// <summary>
        /// Whether or not the word lookup was an ordered search.
        /// </summary>
        public bool wasOrdered
        {
            get
            {
                return m_WasOrdered;
            }
        }

        /// <summary>
        /// The first word found in the lookup operation. Included for convenience.
        /// </summary>
        public string word
        {
            get
            {
                return m_Word;
            }
        }

        /// <summary>
        /// Represents an empty WordResult.
        /// </summary>
        /// <remarks>
        /// This is only created as a result of an invalid word lookup operation. Assigning a WordResult to this value is useful to invalidate previous results.
        /// </remarks>
        public static WordResult empty
        {
            get
            {
                return new WordResult();
            }
        }
        //! \cond PRIVATE
        internal WordResult(string input, string word, IList<string> allWords, bool isValid, bool wasOrdered)
        {
            m_Input = input;
            m_Word = word;
            m_AllWords = allWords;
            m_IsValid = isValid;
            m_WasOrdered = wasOrdered;
            m_HasValue = true;
        }
        //\endcond
    }
}