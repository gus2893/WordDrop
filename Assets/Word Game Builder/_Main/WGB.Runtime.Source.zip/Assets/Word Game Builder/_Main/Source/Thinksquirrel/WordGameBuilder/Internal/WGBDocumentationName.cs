// WGBDocumentationName.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
namespace Thinksquirrel.WordGameBuilder.Internal
{
    //! \cond PRIVATE
    [System.AttributeUsage(System.AttributeTargets.Class | System.AttributeTargets.Struct)]
    public sealed class WGBDocumentationName : System.Attribute
    {
        string m_Name;

        public string name { get { return m_Name; } }

        public WGBDocumentationName(string name)
        {
            this.m_Name = name;
        }
    }
    //! \endcond
}
