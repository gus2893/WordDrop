// WordChecker.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilder.Internal;

namespace Thinksquirrel.WordGameBuilder.Gameplay
{
    /// <summary>
    /// Helper methods to check for a word in a language, using letter tiles as input.
    /// </summary>
    public static class WordChecker
    {
        static int s_MaxWordLength = 16;
        static int s_MaxIterations = 10000;
        static StringBuilder s_GetWordStringBuilder = new StringBuilder(s_MaxWordLength);
        static ObjectPool<StringBuilder> s_StringBuilderPool;
        static string s_CachedGetWordString;

        static WordChecker()
        {
            s_StringBuilderPool = new ObjectPool<StringBuilder>(
                () => new StringBuilder(),
                stringBuilder =>
                {
                    if (stringBuilder.Length > 0)
                        stringBuilder.Remove(0, stringBuilder.Length - 1);
                } );
        }
        /// <summary>
        /// The maximum word length for any word checks.
        /// </summary>
        /// <remarks>
        /// Inputs above this value will be truncated.
        /// </remarks>
        public static int maxWordLength
        {
            get
            {
                return s_MaxWordLength;
            }
            set
            {
                s_MaxWordLength = Mathf.Clamp(value, 1, int.MaxValue);
            }
        }

        /// <summary>
        /// The maximum amount of iterations for any permutation checks.
        /// </summary>
        public static int maxIterations
        {
            get
            {
                return s_MaxIterations;
            }
            set
            {
                s_MaxIterations = Mathf.Clamp(value, 1, int.MaxValue);
            }
        }

        static List<AsyncTask> s_Tasks = new List<AsyncTask>();

        /// <summary>
        /// Gets the amount of currently running asynchronous tasks.
        /// </summary>
        public static int taskCount
        {
            get
            {
                RemoveFinished();
                return s_Tasks.Count;
            }
        }

        /// <summary>
        /// Aborts all asynchronous tasks.
        /// </summary>
        public static void AbortAllTasks()
        {
            for (var i = 0; i < s_Tasks.Count; i++)
            {
                var task = s_Tasks[i];
                task.AbortWaitForSeconds(.01f);
            }
            s_Tasks.Clear();
        }

        //! \cond PRIVATE
        [System.Obsolete("Use WordChecker.taskCount instead")]
        public static int threadCount { get { return taskCount; } }

        [System.Obsolete("Use WordChecker.AbortAllTasks instead")]
        public static void AbortAllThreads()
        {
            AbortAllTasks();
        }
        //! \endcond

        /// <summary>
        /// Gets the word from a list of a letter tiles.
        /// </summary>
        /// <remarks>
        /// Does not perform any dictionary checks.
        /// </remarks>
        /// <param name='letterTiles'>The list of letter tiles to turn into a word.</param>
        /// <returns>A word from the list of letter tiles.</returns>
        public static string GetWord(IList<ILetterTile> letterTiles)
        {
            if (letterTiles == null)
                return null;

            s_GetWordStringBuilder.Remove(0, s_GetWordStringBuilder.Length);

            var tileCount = letterTiles.Count;

            if (tileCount == 0)
                return null;

            for (int i = 0, l = Mathf.Min(tileCount, s_MaxWordLength); i < l; i++)
            {
                var letterString = letterTiles[i].defaultLetter.hasValue
                    ? letterTiles[i].defaultLetter.text
                    : (letterTiles[i].wildcardLetter.hasValue ? letterTiles[i].wildcardLetter.text : string.Empty);

                s_GetWordStringBuilder.Append(letterString);
            }

            if (StringToStringBuilderCompare(s_CachedGetWordString, s_GetWordStringBuilder) != 0)
            {
                s_CachedGetWordString = s_GetWordStringBuilder.ToString();
            }
            return s_CachedGetWordString;
        }

        static int StringToStringBuilderCompare(string s, StringBuilder sb)
        {
            if (s == null) return (sb == null) ? 0 : -1;
            if (sb == null) return (s == null) ? 0 : +1;

            int len = Mathf.Min(sb.Length, s.Length);
            for (int i = 0; i < len; i++) {
                if (s[i] < sb[i]) return -1;
                if (s[i] > sb[i]) return +1;
            }
            return s.Length.CompareTo(sb.Length);
        }

        /// <summary>
        /// Checks the input word against a language dictionary.
        /// </summary>
        /// <returns>
        /// A WordGameResult representing the results of the lookup operation.
        /// </returns>
        /// <param name='letterTiles'>
        /// The letter tile input for the lookup operation.
        /// </param>
        /// <param name='ordered'>
        /// If true, performs a check on the tiles, in order. If false, performs a permutation check on every combination of the letter tiles. Defaults to true.
        /// </param>
        /// <param name='language'>
        /// The language to check the word against. Defaults to the current language.
        /// </param>
        /// <param name='maxWordLength'>
        /// The maximum word length for the lookup operation. Defaults to WordChecker.maxWordLength.
        /// </param>
        /// <param name='maxIterations'>
        /// The maximum amount of iterations for any permutation checks. Defaults to WordChecker.maxWordLength.
        /// </param>
        public static WordGameResult CheckWord(IList<ILetterTile> letterTiles, bool ordered = true, WordGameLanguage language = null, int maxWordLength = 0, int maxIterations = 0)
        {
            if (language == null)
                language = WordGameLanguage.current;

            if (maxWordLength < 0)
                maxWordLength = s_MaxWordLength;

            if (maxIterations < 0)
                maxIterations = s_MaxIterations;

            return CheckWord_INTERNAL(letterTiles, ordered, language, maxWordLength, maxIterations, null);
        }

        //! \cond PRIVATE
        [System.Obsolete("The order of arguments for CheckWordAsync has changed - check the API reference for more information")]
        public static AsyncTask CheckWordAsync(IList<ILetterTile> letterTiles, bool ordered, System.Action<WordGameResult> callback)
        {
            return CheckWordAsync(letterTiles, callback, ordered);
        }

        [System.Obsolete("The order of arguments for CheckWordAsync has changed - check the API reference for more information")]
        public static AsyncTask CheckWordAsync(IList<ILetterTile> letterTiles, bool ordered, WordGameLanguage language, System.Action<WordGameResult> callback)
        {
            return CheckWordAsync(letterTiles, callback, ordered, language);
        }

        [System.Obsolete("The order of arguments for CheckWordAsync has changed - check the API reference for more information")]
        public static AsyncTask CheckWordAsync(IList<ILetterTile> letterTiles, bool ordered, WordGameLanguage language, int maxWordLength, int maxIterations, System.Action<WordGameResult> callback, bool forceAsync)
        {
            return CheckWordAsync(letterTiles, callback, ordered, language, maxWordLength, maxIterations, forceAsync);
        }
        //! \endcond

        /// <summary>
        /// Checks the input word against the dictionary, asynchronously on another thread.
        /// </summary>
        /// <returns>
        /// An Task representing the asynchronous task.
        /// </returns>
        /// <param name='letterTiles'>
        /// The letter tile input for the lookup operation.
        /// </param>
        /// <param name='callback'>
        /// The method to call upon completion. This method must take a WordGameResult as the only argument.
        /// </param>
        /// <param name='ordered'>
        /// If true, performs a check on the tiles, in order. If false, performs a permutation check on every combination of the letter tiles.
        /// </param>
        /// <param name='language'>
        /// The language to check the word against.
        /// </param>
        /// <param name='maxWordLength'>
        /// The maximum word length for the lookup operation. Overrides WordChecker.maxWordLength.
        /// </param>
        /// <param name='maxIterations'>
        /// The maximum amount of iterations for any permutation checks. Overrides WordChecker.maxWordLength.
        /// </param>
        /// <param name='forceAsync'>
        /// If true, this method will always execute on another thread.
        /// </param>
        /// <remarks>
        /// If less than 4 tiles are specified and forceAsync = false, this method is run on the same thread that it is called and returns an empty task.
        /// </remarks>
        public static AsyncTask CheckWordAsync(IList<ILetterTile> letterTiles, System.Action<WordGameResult> callback = null, bool ordered = true, WordGameLanguage language = null, int maxWordLength = -1, int maxIterations = -1, bool forceAsync = false)
        {
            if (language == null)
                language = WordGameLanguage.current;

            if (maxWordLength < 0)
                maxWordLength = s_MaxWordLength;

            if (maxIterations < 0)
                maxIterations = s_MaxIterations;

            // Run on another thread only if we have more than 4 tiles or if asynchronous word check is forced.
            WordGameResult result;

            if (letterTiles.Count > 4 || forceAsync)
            {
                var t = AsyncTask.Create(task =>
                {
                    result = CheckWord_INTERNAL(letterTiles, ordered, language, maxWordLength, maxIterations, task);

                    // Run the callback on the main thread
                    if (callback != null) AsyncTask.Dispatch(() => callback(result));
                });
                s_Tasks.Add(t);
                return t;
            }

            result = CheckWord_INTERNAL(letterTiles, ordered, language, maxWordLength, maxIterations, null);
            if (callback != null) callback(result);
            return AsyncTask.Empty();
        }

        static WordGameResult CheckWord_INTERNAL(IList<ILetterTile> letterTiles, bool ordered, WordGameLanguage language, int maximumWordLength, int maximumIterations, AsyncTask task)
        {
            if (letterTiles == null)
                return WordGameResult.empty;
            if (letterTiles.Count < 1)
                return WordGameResult.empty;

            string ws = null;
            string ws2 = null;
            int s = 0;
            string newWord = null;
            int score = 0;

            for (int i = 0; i < letterTiles.Count; i++)
            {
                ws += letterTiles [i].defaultLetter.hasValue ? letterTiles [i].defaultLetter.character : letterTiles [i].wildcardLetter.character;
                ws2 += letterTiles [i].defaultLetter.hasValue ? letterTiles [i].defaultLetter.text : letterTiles [i].wildcardLetter.text;
            }

            for (int i = 0; i < Mathf.Min(maximumWordLength, letterTiles.Count); i++)
            {
                s += letterTiles [i].currentPointValue;
            }

            if (ws == null)
                return WordGameResult.empty;


            WordResult result = language.wordSet.FindWordInternal(ws, ordered, maximumWordLength, maximumIterations, task);

            // Convert characters back into tiles
            var newAllWords = new List<string>();

            if (result.isValid)
            {
                var newAllWord = s_StringBuilderPool.Pop();
                for (int i = 0; i < result.allWords.Count; i++)
                {
                    var word = result.allWords[i];
                    for (int j = 0; j < word.Length; j++)
                    {
                        var letter = word[j];
                        newAllWord.Append(language.GetLetter(letter).text);
                    }
                    newAllWords.Add(newAllWord.ToString());
                    newAllWord.Length = 0;
                }

                newWord = newAllWords [0];
                score = s;
                s_StringBuilderPool.Push(newAllWord);
            }

            return new WordGameResult(ws2, newWord, newAllWords, new List<ILetterTile>(letterTiles), score, result.isValid, result.wasOrdered);
        }

        static void RemoveFinished()
        {
            for (int i = 0; i < s_Tasks.Count; i++)
            {
                if (s_Tasks[i].hasEnded)
                {
                    s_Tasks.Remove(s_Tasks [i]);
                }
            }
        }
    }
}
