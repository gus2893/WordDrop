﻿// AsyncTask.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System;
using System.Collections.Generic;
using System.Threading;
using Thinksquirrel.WordGameBuilder.Internal.Threading;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Represents an asynchronous task.
    /// </summary>
    public sealed class AsyncTask : IDisposable
    {
        internal static readonly HashSet<AsyncTask> _activeTasks = new HashSet<AsyncTask>(); 
        static readonly AsyncTask s_EmptyTask = new AsyncTask(null, false);

        IEventWaitHandle m_AbortEvent;
        IEventWaitHandle m_EndedEvent;
        Action<AsyncTask> m_Action;
        bool m_HasStarted;

        AsyncTask(Action<AsyncTask> action, bool isBackground)
        {
            m_AbortEvent = Parallel.CreateEventWaitHandle();
            m_EndedEvent = Parallel.CreateEventWaitHandle();

            m_AbortEvent.Reset();
            m_EndedEvent.Reset();
            m_HasStarted = false;
            m_Action = action;
            
            if (m_Action == null)
            {
                m_HasStarted = true;
                m_EndedEvent.Set();
                return;
            }

            _activeTasks.Add(this);

            if (isBackground)
            {
                Parallel.RunInBackground(Do);
            }
            else
            {
                Parallel.RunOnMainThread(Do);
            }
        }

        internal static AsyncTask Empty()
        {
            return s_EmptyTask;
        }

        /// <summary>
        /// Creates a task on a background thread.
        /// </summary>
        /// <param name="action">The action to run on a background thread.</param>
        /// <returns>An object representing the asynchronous task.</returns>
        public static AsyncTask Create(Action<AsyncTask> action)
        {
            return new AsyncTask(action, true);
        }

        /// <summary>
        /// Dispatches an action onto the main thread.
        /// </summary>
        /// <param name="action">The action to run on the main thread.</param>
        /// <returns>An object representing the asynchronous task.</returns>
        public static AsyncTask Dispatch(Action<AsyncTask> action)
        {
            return new AsyncTask(action, false);
        }

        /// <summary>
        /// Creates a task on a background thread, without tracking task state.
        /// </summary>
        /// <param name="action">The action to run on a background thread.</param>
        public static void Create(Action action)
        {
            if (action != null) Parallel.RunInBackground(action);
        }

        /// <summary>
        /// Dispatches an action onto the main thread, without tracking task state.
        /// </summary>
        /// <param name="action">The action to run on the main thread.</param>
        public static void Dispatch(Action action)
        {
            if (action != null) Parallel.RunOnMainThread(action);
        }

        internal bool shouldAbort
        {
            get { return m_AbortEvent.WaitOne(0); }
        }
        
        /// <summary>
        /// Returns true if this task has ended, been skipped, or been aborted.
        /// </summary>
        public bool hasEnded
        {
            get { return m_EndedEvent.WaitOne(0); }
        }
        
        /// <summary>
        /// Returns true if this task was successful.
        /// </summary>
        public bool isSucceeded
        {
            get { return hasEnded && !shouldAbort; }
        }
        
        /// <summary>
        /// Returns true if this task has failed.
        /// </summary>
        public bool isFailed
        {
            get { return hasEnded && shouldAbort; }
        }
        
        /// <summary>
        /// Abort this task.
        /// </summary>
        public void Abort()
        {
            m_AbortEvent.Set();
        }
        
        /// <summary>
        /// Abort this task, and wait until it has ended.
        /// </summary>
        public void AbortWait()
        {
            Abort();
            Wait();
        }
        
        /// <summary>
        /// Abort this task, and wait until it has ended, or the specified amount of time (in seconds) has passed.
        /// </summary>
        /// <param name='seconds'>The maximum amount of seconds to wait.</param>
        public void AbortWaitForSeconds(float seconds)
        {
            Abort();
            WaitForSeconds(seconds);
        }
        
        /// <summary>
        /// Blocks the calling thread until the task has ended.
        /// </summary>
        public void Wait()
        {
            m_EndedEvent.WaitOne();
        }
        
        /// <summary>
        /// Blocks the calling thread until the task has ended, or the specified amount of time (in seconds) has passed.
        /// </summary>
		/// <param name='seconds'>The maximum amount of seconds to wait.</param>
        public void WaitForSeconds(float seconds)
        {
            m_EndedEvent.WaitOne(TimeSpan.FromSeconds(seconds));
        }

        //! \cond PRIVATE
        [Obsolete("SetReusable has been depreciated and can be removed.")]
        public void SetReusable()
        {
            
        }
        //! \endcond

        void Do()
        {
            m_HasStarted = true;
            m_Action(this);
            Dispatch(() => _activeTasks.Remove(this));
            m_EndedEvent.Set();
        }
        
        /// <summary>
        /// Disposes this task and waits for completion if it is still running.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void Dispose(bool isFinalizing)
        {
            if (m_HasStarted)
                Wait();

            m_EndedEvent.Close();
            m_AbortEvent.Close();
        }

        ~AsyncTask()
        {
            Dispose(false);
        }
    }
}
