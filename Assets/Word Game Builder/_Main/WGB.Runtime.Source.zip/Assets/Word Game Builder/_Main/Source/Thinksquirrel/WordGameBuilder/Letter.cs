// Letter.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using UnityEngine;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Represents a letter.
    /// </summary>
    /// <remarks>
    /// Note that this type is passed by value for performance reasons.
    /// </remarks>
	public struct Letter : System.IEquatable<Letter>, System.IComparable<Letter>
    {
        static readonly Letter m_Empty = new Letter(true);
        readonly string m_Text;
        readonly char m_Character;
        readonly int m_Score;
        readonly bool m_HasValue;

        /// <summary>
        /// Returns an empty letter.
        /// </summary>
        public static Letter empty
        {
            get
            {
                return m_Empty;
            }
        }

        /// <summary>
        /// Gets the character associated with the letter.
        /// </summary>
        /// <remarks>
        /// The character is used for lookups into the langauge dictionary.
        /// </remarks>
        public char character
        {
            get
            {
                return m_Character;
            }
        }

        /// <summary>
        /// Does the letter have a value?
        /// </summary>
        public bool hasValue
        {
            get
            {
                return m_HasValue;
            }
        }

        /// <summary>
        /// Gets the score associated with the letter.
        /// </summary>
        public int score
        {
            get
            {
                return m_Score;
            }
        }

        /// <summary>
        /// Gets the text associated with the letter.
        /// </summary>
        /// <remarks>
        /// This is the actual display text for the letter.
        /// </remarks>
        public string text
        {
            get
            {
                return m_Text;
            }
        }

        /// <summary>
        /// Creates a new letter.
        /// </summary>
		/// <param name="text">A human-readable string representing the letter.</param>
		/// <param name="charValue">A machine-character representing the letter.</param>
		/// <param name="score">The point value of the letter.</param>
        public Letter(string text, char charValue, int score)
        {
            m_Text = text;
            m_Character = charValue;
            m_Score = score;
            m_HasValue = charValue != char.MinValue;
        }

        //! \cond PRIVATE
        internal Letter(SerializableLetter serializedLetter)
        {
            m_Text = serializedLetter.text;
            m_Character = System.Convert.ToChar(serializedLetter.character);
            m_Score = serializedLetter.score;
            m_HasValue = serializedLetter.hasValue;
        }

        Letter(bool empty)
        {
            m_Text = string.Empty;
            m_Character = char.MinValue;
            m_Score = 0;
            m_HasValue = !empty;
        }
        //! \endcond

        /// <summary>
        /// Tests value-based equality between two letters.
        /// </summary>
        /// <remarks>
        /// Two letters are equal if they have the same text and character, or are both blank.
        /// </remarks>
        /// <param name="a">The first letter to compare.</param>
        /// <param name="b">The second letter to compare.</param>
        /// <returns><c>true</c> if the letters are equal, otherwise <c>false</c>.</returns>
        public static bool operator ==(Letter a, Letter b)
        {
            // If both are blank, return true.
            if (!a.hasValue && !b.hasValue)
            {
                return true;
            }
            
            // Return true if the fields match:
            return a.m_Text == b.m_Text && a.m_Character == b.m_Character;
        }

        /// <summary>
        /// Tests value-based non-equality between two letters.
        /// </summary>
        /// <remarks>
        /// Two letters are equal if they have the same text and character, or are both blank.
        /// </remarks>
        /// <param name="a">The first letter to compare.</param>
        /// <param name="b">The second letter to compare.</param>
        /// <returns><c>true</c> if the letters are NOT equal, otherwise <c>false</c>.</returns>
        public static bool operator !=(Letter a, Letter b)
        {
            return !(a == b);
        }

        /// <summary>
        /// Override for System.Object.Equals.
        /// </summary>
        /// <param name="obj">The object to compare this letter with.</param>
        /// <returns><c>true</c> if the letters are equal, otherwise <c>false</c>.</returns>
        public override bool Equals(object obj)
        {
            if (!(obj is Letter))
                return false;

            return Equals((Letter)obj);
        }

        /// <summary>
        /// Override for System.Object.GetHashCode.
        /// </summary>
        /// <returns>
        /// A hash code of the current letter.
        /// </returns>
        public override int GetHashCode()
        {
            const int seed = 0x51ed270b;
            const int factor = -1521134295;

            int hash = seed;
            hash = (hash * factor) + m_Text.GetHashCode();
            hash = (hash * factor) + m_Character.GetHashCode();
            return hash;
        }

        #region IEquatable implementation
        /// <summary>
        /// Tests value-based equality between two letters.
        /// </summary>
        /// <remarks>
        /// Two letters are equal if they have the same text and character, or are both blank.
        /// </remarks>
        /// <param name="other">The other letter to compare with this one.</param>
        /// <returns><c>true</c> if the letters are equal, otherwise <c>false</c>.</returns>
        /// <returns>A signed number indicating the relative values of this instance and <c>other</c>.</returns>
        public bool Equals(Letter other)
        {
            return this == other;
        }

        #endregion

        #region IComparable implementation
        /// <summary>
        /// Compares this letter to another one, by their human-readable string values and the current culture.
        /// </summary>
        /// <remarks>
        /// Two letters are equal if they have the same text and character, or are both blank.
        /// </remarks>
        /// <param name="other">The other letter to compare with this one.</param>
        /// <returns>A signed number indicating the relative values of this instance and <c>other</c>.</returns>
        public int CompareTo(Letter other)
        {
            return string.Compare(text, other.text, System.StringComparison.CurrentCulture);
        }
        
        /// <summary>
        /// Compares this letter to another one, by their human-readable string values and the specified culture.
        /// </summary>
        /// <remarks>
        /// Two letters are equal if they have the same text and character, or are both blank.
        /// </remarks>
        /// <param name="other">The other letter to compare with this one.</param>
        /// <param name="culture">The culture to use for the comparison.</param>
        /// <returns>A signed number indicating the relative values of this instance and <c>other</c>.</returns>
        public int CompareTo(Letter other, System.Globalization.CultureInfo culture)
        {
            return culture.CompareInfo.Compare(text, other.text);
        }
		#endregion
    }

    #region IEqualityComparer
    //! \cond PRIVATE
    class LetterComparer : IEqualityComparer<Letter>
    {
        public bool Equals(Letter x, Letter y)
        {
            return x.Equals(y);
        }

        public int GetHashCode(Letter letter)
        {
            return letter.GetHashCode();
        }
    }
    //! \endcond
    #endregion

    //! \cond PRIVATE
    /// <summary>
    /// A serialized representation of a letter. Used for Unity components.
    /// </summary>
	/// <seealso cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile"/>
    [System.Serializable]
    class SerializableLetter
    {
        [SerializeField] string m_Text;
        [SerializeField] int m_Character;
        [SerializeField] int m_Score;
        [SerializeField] bool m_HasValue;

        /// <summary>
        /// The text associated with the letter.
        /// </summary>
        /// <remarks>
        /// This is the actual display text for the letter.
        /// </remarks>
        public string text { get { return m_Text; } set { m_Text = value; } }
        /// <summary>
        /// The character associated with the letter.
        /// </summary>
        /// <remarks>
        /// The character is used for lookups into the langauge dictionary.
        /// </remarks>
        public int character { get { return m_Character; } set { m_Character = value; } }
        /// <summary>
        /// The score associated with the letter.
        /// </summary>
        public int score { get { return m_Score; } set { m_Score = value; } }
        /// <summary>
        /// Does the letter have a value?
        /// </summary>
        public bool hasValue { get { return m_HasValue; } set { m_HasValue = value; } }

        /// <summary>
        /// Creates an empty SerializedLetter.
        /// </summary>
        public SerializableLetter()
        {
            m_Text = "";
            m_Character = System.Convert.ToInt32(char.MinValue);
            m_Score = 0;
            m_HasValue = false;
        }

        /// <summary>
        /// Creates a SerializableLetter from a Letter struct.
        /// </summary>
        public SerializableLetter(Letter letter)
        {
            Update(letter);
        }

        /// <summary>
        /// Creates a SerializableLetter from another SerializableLetter.
        /// </summary>
        public SerializableLetter(SerializableLetter serializableLetter)
        {
            Update(serializableLetter);
        }

        [System.Obsolete("use SerializableLetter.Update instead")]
        public void Initialize(Letter letter)
        {
            Update(letter);
        }

        /// <summary>
        /// Updates the SerializableLetter from a Letter struct.
        /// </summary>
        public void Update(Letter letter)
        {
            m_Text = letter.text;
            m_Character = System.Convert.ToInt32(letter.character);
            m_Score = letter.score;
            m_HasValue = letter.hasValue;
        }

        /// <summary>
        /// Updates the SerializableLetter from another SerializableLetter.
        /// </summary>
        public void Update(SerializableLetter serializableLetter)
        {
           m_Text = serializableLetter.m_Text;
           m_Character = serializableLetter.m_Character;
           m_Score = serializableLetter.m_Score;
           m_HasValue = serializableLetter.m_HasValue;
		}
    }
    //! \endcond
}
