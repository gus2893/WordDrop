// LetterTile.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.Gameplay;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilder.Tweening;
using Thinksquirrel.WordGameBuilder.Internal;
using System.Linq;

//! This namespace contains the standard letter tile, and all letter tile helper classes.
namespace Thinksquirrel.WordGameBuilder.Tiles
{
    /// <summary>
    /// A standard letter tile. Includes support for selection, wildcard tiles, multiple colors, input, and state querying.
    /// </summary>
    /// <remarks>
    /// Actual display of the letter tiles are handled by other scripts.
    /// </remarks>
    [AddComponentMenu("Word Game Builder/Tiles/Letter Tile")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Tiles.LetterTile")]
    public sealed class LetterTile : WGBBase, ISelectableLetterTile, ILetterTileInput, ILetterTileDisplay
    {
        #region Private fields
        WordGameLanguage m_Language;
        Letter m_DefaultLetter;
        Letter m_WildcardLetter;
        bool m_IsActive;
        bool m_ShouldChangeColor;
        bool m_ShouldChangeLabel;
        bool m_ShouldAnimate;
        bool m_InSelectionEvent;
        readonly Tweener<Color> m_BackgroundTweener = new Tweener<Color>();
        readonly Tweener<Color> m_TextTweener = new Tweener<Color>();
        #endregion

        #region Unity serialization
        // Analysis disable FieldCanBeMadeReadOnly.Local
        [SerializeField] [HideInInspector] SerializableLetter m_SerializedLetter = new SerializableLetter();
        [SerializeField] [HideInInspector] int m_DefaultPointValue;
        [SerializeField] [HideInInspector] int m_CurrentPointValue;
        [SerializeField] [HideInInspector] TileStateFlags m_TileFlags = TileStateFlags.None;

        [SerializeField] ColorInfo m_ColorInfo = new ColorInfo();
        [SerializeField] ColorInfo m_WildcardColorInfo = new ColorInfo();
        [SerializeField] SelectionInfo m_SelectionInfo = new SelectionInfo();
        [SerializeField] DisplayInfo m_DisplayInfo = new DisplayInfo();
        [SerializeField] TweenInfo m_TweenInfo = new TweenInfo();
        [SerializeField] WGBEvent m_OnTileSpawn;
        [SerializeField] WGBEvent m_OnTileSelect;
        [SerializeField] WGBEvent m_OnTileChange;
        // Analysis restore FieldCanBeMadeReadOnly.Local
        #endregion

        #region ILetterTile implementation
        /// <summary>
        /// The current point value of the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.currentPointValue">ILetterTile</see>.
        /// </remarks>
        public int currentPointValue { get { return m_CurrentPointValue; } }
        /// <summary>
        /// The default point value of the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.defaultPointValue">ILetterTile</see>.
        /// </remarks>
        public int defaultPointValue { get { return m_DefaultPointValue; } }
        /// <summary>
        /// The letter represented by the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.defaultLetter">ILetterTile</see>.
        /// </remarks>
        public Letter defaultLetter { get { return m_DefaultLetter; } }
        //! \cond PRIVATE
        [System.Obsolete("Use LetterTile.defaultLetter instead")]
        public Letter letter { get { return m_DefaultLetter; } }
        //! \endcond
        /// <summary>
        /// The wildcard letter represented by the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.wildcardLetter">ILetterTile</see>.
        /// </remarks>
        public Letter wildcardLetter { get { return m_WildcardLetter; } }
        /// <summary>
        /// The current letter represented by the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.currentLetter">ILetterTile</see>.
        /// </remarks>
        public Letter currentLetter
        {
            get { return m_WildcardLetter.hasValue ? m_WildcardLetter : m_DefaultLetter; }
        }
        /// <summary>
        /// Is the tile currently active (spawned)?
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.isActive">ILetterTile</see>.
        /// </remarks>
        public bool isActive { get { return m_IsActive; } }
        /// <summary>
        /// This event fires when a tile is spawned or despawned.
        /// </summary>
        /// <remarks>
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentLetterTile
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.onTileSpawn">ILetterTile</see>.
        /// </remarks>
        public WGBEvent onTileSpawn { get { return m_OnTileSpawn; } set { m_OnTileSpawn = value; } }
        /// <summary>
        /// This event fires when a tile has changed.
        /// </summary>
        /// <remarks>
        /// This event will fire if any of the following changes:
        /// * Tile enabled/disabled
        /// * Tile selected/deselected
        /// * Tile hovered/unhovered
        /// * Tile letter or score changed
        /// * Tile wildcard letter or score changed
        /// * Each frame during any color tweening action
        ///
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentLetterTile
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTile.onTileChange">ILetterTile</see>.
        /// </remarks>
        public WGBEvent onTileChange { get { return m_OnTileChange; } set { m_OnTileChange = value; } }
        //! \cond PRIVATE
        [System.Obsolete("Use LetterTile.ChangeDefaultLetter instead")]
        public void ChangeLetter(Letter letter)
        {
            ChangeDefaultLetter(letter);
        }
        //! \endcond
        public void ChangeDefaultLetter(Letter letter)
        {
            m_DefaultLetter = letter;
            m_SerializedLetter.Update(m_DefaultLetter);
            SetPointValues(m_DefaultLetter.score, m_DefaultLetter.score);
            TileChangeEvent(false, LetterTileChange.LetterAndScoreChanged);
        }
        public void SetWildcard(Letter letter)
        {
            SetWildcard(letter, letter.score);
        }
        public void SetWildcard(Letter letter, int score)
        {
            m_WildcardLetter = letter;
            SetPointValues(score, score);
            TileChangeEvent(false, LetterTileChange.ScoreChanged);
        }
        public void RemoveWildcard()
        {
            m_WildcardLetter = Letter.empty;
            SetPointValues(m_DefaultLetter.score, m_DefaultLetter.score);
            TileChangeEvent(false, LetterTileChange.LetterAndScoreChanged);
        }
        public void SpawnTile()
        {
            if (!m_IsActive)
            {
                m_IsActive = true;
                TileSpawnEvent();
            }
        }
        public void DespawnTile()
        {
            RemoveWildcard();
            if (m_IsActive)
            {
                m_IsActive = false;
                m_TileFlags = TileStateFlags.None;
                TileSpawnEvent();
            }
        }
        #endregion

        #region ILetterTileDisplay implementation
        /// <summary>
        /// The current text color for the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTileDisplay.currentTextColor">ILetterTileDisplay</see>.
        /// </remarks>
        public Color currentTextColor
        {
            get { return m_TextTweener.currentValue; }
        }
        /// <summary>
        /// The current background color for the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTileDisplay.currentBackgroundColor">ILetterTileDisplay</see>.
        /// </remarks>
        public Color currentBackgroundColor
        {
            get { return m_BackgroundTweener.currentValue; }
        }
        /// <summary>
        /// The current letter label for the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTileDisplay.currentLetterLabel">ILetterTileDisplay</see>.
        /// </remarks>
        public string currentLetterLabel
        {
            get { return currentLetter.text; }
        }
        /// <summary>
        /// The current score label for the tile.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTileDisplay.currentScoreLabel">ILetterTileDisplay</see>.
        /// </remarks>
        public string currentScoreLabel
        {
            get { return !m_DisplayInfo.showZeroLabel && m_CurrentPointValue == 0 ? string.Empty : m_CurrentPointValue.ToString(); }
        }
        /// <summary>
        /// The current text color for the tile, in raw form (without tweening).
        /// </summary>
        public Color currentTextColorRaw
        {
            get { return m_WildcardLetter.hasValue ?
                    m_WildcardColorInfo.GetCurrentTextColor(isOver, isSelected, !enabled, isBonus, isPenalty) :
                    m_ColorInfo.GetCurrentTextColor(isOver, isSelected, !enabled, isBonus, isPenalty); }
        }
        /// <summary>
        /// The current background color for the tile, in raw form (without tweening).
        /// </summary>
        public Color currentBackgroundColorRaw
        {
            get { return m_WildcardLetter.hasValue ?
                    m_WildcardColorInfo.GetCurrentBackgroundColor(isOver, isSelected, !enabled, isBonus, isPenalty) :
                    m_ColorInfo.GetCurrentBackgroundColor(isOver, isSelected, !enabled, isBonus, isPenalty); }
        }
        /// <summary>
        /// Returns true if a tile should change color. This is only set during change events.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTileDisplay.shouldChangeColor">shouldChangeColor</see>.
        /// </remarks>
        bool ILetterTileDisplay.shouldChangeColor { get { return m_ShouldChangeColor; } }
        /// <summary>
        /// Returns true if a tile should change its label. This is only set during change events.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTileDisplay.shouldChangeLabel">shouldChangeLabel</see>.
        /// </remarks>
        bool ILetterTileDisplay.shouldChangeLabel { get { return m_ShouldChangeLabel; } }
        /// <summary>
        /// Returns true if a tile should animate. This is only set during change events.
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ILetterTileDisplay.shouldAnimate">shouldAnimate</see>.
        /// </remarks>
        bool ILetterTileDisplay.shouldAnimate { get { return m_ShouldAnimate; } }
        #endregion

        #region ISelectableLetterTile implementation
        /// <summary>
        /// Is the current tile selected?
        /// </summary>
        /// <remarks>
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ISelectableLetterTile.isSelected">ISelectableLetterTile</see>.
        /// </remarks>
        public bool isSelected { get { return (m_TileFlags & TileStateFlags.Selected) != 0; } }
        /// <summary>
        /// This event fires when a tile has been selected or deselected, and can be used to override selection.
        /// </summary>
        /// <remarks>
        /// This event is fired before onTileChange. Overriding a selection will cancel the change event.
        ///
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentLetterTile
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.ISelectableLetterTile.onTileSelect">ISelectableLetterTile</see>.
        /// </remarks>
        public WGBEvent onTileSelect { get { return m_OnTileSelect; } set { m_OnTileSelect = value; } }

        public bool CanSelectTile(IList<ILetterTile> tiles, out bool shouldDeselect)
        {
            return CheckTileSelection(tiles, out shouldDeselect, false);
        }
        public bool CanSelectTile(IWordGamePlayer player, out bool shouldDeselect)
        {
            if (!selectionInfo.ContainsPlayer(player))
            {
                shouldDeselect = false;
                return false;
            }
            return CheckTileSelection(player.selectedTiles, out shouldDeselect, false);
        }

        public void ModifyTileSelection(IList<ILetterTile> tiles)
        {
            bool shouldDeselect;
            CheckTileSelection(tiles, out shouldDeselect, true);
        }
        public bool SelectTile(IList<ILetterTile> tiles)
        {
            bool shouldDeselect;
            if (CheckTileSelection(tiles, out shouldDeselect, false) && !shouldDeselect)
            {
                ModifyTileSelection(tiles);
                return true;
            }
            return false;
        }
        public bool DeselectTile(IList<ILetterTile> tiles)
        {
            bool shouldDeselect;
            if (CheckTileSelection(tiles, out shouldDeselect, false) && shouldDeselect)
            {
                ModifyTileSelection(tiles);
                return true;
            }
            return false;
        }
        public bool SelectTile(IWordGamePlayer player)
        {
            return selectionInfo.ContainsPlayer(player) && SelectTile(player.selectedTiles);
        }
        public bool DeselectTile(IWordGamePlayer player)
        {
            return selectionInfo.ContainsPlayer(player) && DeselectTile(player.selectedTiles);
        }
        public void ForceSelectTile()
        {
            m_TileFlags |= TileStateFlags.Selected;
            TileSelectionEvent();
            if (isSelected)
                TileChangeEvent(true, LetterTileChange.Selected);
        }
        public void ForceDeselectTile()
        {
            m_TileFlags &= ~TileStateFlags.Selected;
            TileSelectionEvent();
            if (!isSelected)
                TileChangeEvent(true, LetterTileChange.Deselected);
        }
        #endregion

        #region ILetterTileInput implementation
        public void SimulatePressInput(bool isPressed)
        {
            if (isPressed && m_SelectionInfo.selectionMode == SelectionMode.SelectOnPress)
            {
                SimulateInput();
            }
        }
        public void SimulateClickInput()
        {
            if (m_SelectionInfo.selectionMode == SelectionMode.SelectOnClick)
            {
                SimulateInput();
            }
        }
        public void SimulateHoverInput(bool isOver)
        {
            m_Language = m_Language ?? WordGameLanguage.current;

            var players = m_SelectionInfo.GetPlayersInternal();

            var enumerator = players.GetEnumerator();

            while(enumerator.MoveNext())
            {
                var player = enumerator.Current;

                // If input is blocked, skip the player
                if (!player.inputEnabled)
                    continue;

                // If any player's input is enabled, we can hover
                if (isOver && !this.isOver)
                {
                    m_TileFlags |= TileStateFlags.Hover;
                    TileChangeEvent(true, LetterTileChange.Hovered);
                }
                else if (!isOver && this.isOver)
                {
                    m_TileFlags &= ~TileStateFlags.Hover;
                    TileChangeEvent(true, LetterTileChange.Unhovered);
                }
                return;
            }
        }
        #endregion

        #region Public API
        /// <summary>
        /// Is the current tile being hovered over?
        /// </summary>
        public bool isOver { get { return (m_TileFlags & TileStateFlags.Hover) != 0; } }
        /// <summary>
        /// Is the current tile in a bonus state (currentPointValue &gt; defaultPointValue)?
        /// </summary>
        public bool isBonus { get { return (m_TileFlags & TileStateFlags.Bonus) != 0; } }
        /// <summary>
        /// Is the current tile in a penalty state (currentPointValue &lt; defaultPointValue)?
        /// </summary>
        public bool isPenalty { get { return (m_TileFlags & TileStateFlags.Penalty) != 0; } }
        /// <summary>
        /// Is the current tile a wildcard (wildcardLetter.hasValue)?
        /// </summary>
        public bool isWildcard { get { return m_WildcardLetter.hasValue; } }
        /// <summary>
        /// Is the current tile blank !(letter.hasValue || wildcardLetter.hasValue)?
        /// </summary>
        public bool isBlank { get { return !(m_DefaultLetter.hasValue || m_WildcardLetter.hasValue); } }
        /// <summary>
        /// Gets or sets the color information.
        /// </summary>
        public ColorInfo colorInfo { get { return m_ColorInfo; } set { m_ColorInfo = value; } }
        /// <summary>
        /// Gets or sets the wildcard color information.
        /// </summary>
        public ColorInfo wildcardColorInfo { get { return m_WildcardColorInfo; } set { m_WildcardColorInfo = value; } }
        /// <summary>
        /// Gets or sets the selection information.
        /// </summary>
        public SelectionInfo selectionInfo { get { return m_SelectionInfo; } set { m_SelectionInfo = value; } }
        /// <summary>
        /// Gets or sets additional display information.
        /// </summary>
        public DisplayInfo displayInfo { get { return m_DisplayInfo; } set { m_DisplayInfo = value; } }
        /// <summary>
        /// Gets or sets tweening information.
        /// </summary>
        public TweenInfo tweenInfo { get { return m_TweenInfo; } set { m_TweenInfo = value; } }
        /// <summary>
        /// Gets the current change state. This is only set during onTileChange.
        /// </summary>
        public LetterTileChange currentChange { get; set; }
        //! \cond PRIVATE
        [System.Obsolete("Use LetterTile.ChangeDefaultLetter instead")]
        public void ChangeLetter(string letterString)
        {
            ChangeDefaultLetter(letterString);
        }
        //! \endcond
        /// <summary>
        /// Changes the letter on a tile, using the specified language.
        /// </summary>
        /// <param name='letterString'>
        /// The display text of the letter to change to.
        /// </param>
        public void ChangeDefaultLetter(string letterString)
        {
            ChangeDefaultLetter(letterString, null);
        }
        //! \cond PRIVATE
        [System.Obsolete("Use LetterTile.ChangeDefaultLetter instead")]
        public void ChangeLetter(string letterString, WordGameLanguage language)
        {
            ChangeDefaultLetter(letterString, language);
        }
        //! \endcond
        /// <summary>
        /// Changes the letter on a tile, using the specified language.
        /// </summary>
        /// <param name='letterString'>
        /// The display text of the letter to change to.
        /// </param>
        /// <param name='language'>
        /// The language to use.
        /// </param>
        public void ChangeDefaultLetter(string letterString, WordGameLanguage language)
        {
            m_Language = (bool)language ? language : ((bool)m_Language ? m_Language : WordGameLanguage.current);
            m_DefaultLetter = m_Language.GetLetter(letterString);
            m_SerializedLetter.Update(m_DefaultLetter);
            SetPointValues(m_DefaultLetter.score, m_DefaultLetter.score);
            TileChangeEvent(false, LetterTileChange.LetterAndScoreChanged);
        }
        /// <summary>
        /// Sets the point multiplier of a letter tile.
        /// </summary>
        /// <param name='multiplier'>
        /// The multiplier to apply.
        /// </param>
        /// <remarks>
        /// Changes the currentPointValue.
        /// </remarks>
        public void SetPointMultiplier(float multiplier)
        {
            SetPointValues(m_DefaultPointValue, Mathf.RoundToInt(m_DefaultPointValue * multiplier));
            TileChangeEvent(false, LetterTileChange.ScoreChanged);
        }
        /// <summary>
        /// Resets the point value of the tile to the default.
        /// </summary>
        public void ResetPointValue()
        {
            SetPointValues(m_DefaultPointValue, m_DefaultPointValue);
            TileChangeEvent(false, LetterTileChange.ScoreChanged);
        }
        /// <summary>
        /// Simulates tile selection/deselection event from user input (either a press or a click).
        /// </summary>
        public void SimulateInput()
        {
            if (!m_DefaultLetter.hasValue && m_SelectionInfo.processWildcards) { ProcessWildcardTileManager(); } else { ProcessTileSelection(); }
        }
        #endregion

        #region Private methods
        void OnEnable()
        {
            TileChangeEvent(true, LetterTileChange.Enabled);
        }
        void Awake()
        {
            // Add all players by default
            if (m_SelectionInfo != null)
                m_SelectionInfo.AddAllPlayers();

            // Predict and cache the wildcard tile manager if it will likely be needed
            if (m_SelectionInfo != null && m_SelectionInfo.processWildcards)
                m_SelectionInfo.FindWildcardTileManager();

            m_DefaultLetter = m_SerializedLetter.hasValue ? new Letter(m_SerializedLetter) : Letter.empty;

            m_TextTweener.start = currentTextColorRaw;
            m_BackgroundTweener.start = currentBackgroundColorRaw;
            m_TextTweener.onTween += OnTween;
            m_BackgroundTweener.onTween += OnTween;

            TileChangeEvent(false, LetterTileChange.LetterAndScoreChanged);
        }
        void OnDisable()
        {
            TileChangeEvent(true, LetterTileChange.Disabled);
        }
        void OnDestroy()
        {
            m_BackgroundTweener.Dispose();
            m_TextTweener.Dispose();
        }
        void OnTween()
        {
            WGBEvent.Invoke(m_OnTileChange, m_Language, this, null, null, null, null, () => SetDisplayState(true, false, false), () => SetDisplayState(false, false, false));
        }
        void TileSelectionEvent()
        {
            // This event is not recursive
            if (m_InSelectionEvent)
                return;

            m_InSelectionEvent = true;

            // Get last selection state
            bool lastSelectionState = isSelected;

            // Invoke onTileSelect
            WGBEvent.Invoke(m_OnTileSelect, m_Language, this, null, null, null, null, null, null);

            // If selection was NOT overridden, fire a change event
            if (lastSelectionState == isSelected)
                TileChangeEvent(true, isSelected ? LetterTileChange.Selected : LetterTileChange.Deselected);

            m_InSelectionEvent = false;
        }
        void TileChangeEvent(bool shouldChangeColor, LetterTileChange changeType)
        {
            if (isActive)
            {
                m_TextTweener.Start(currentTextColorRaw, m_TweenInfo.duration, m_TweenInfo.delay, m_TweenInfo.easing);
                m_BackgroundTweener.Start(currentBackgroundColorRaw, m_TweenInfo.duration, m_TweenInfo.delay, m_TweenInfo.easing);
            }
            else
            {
                m_TextTweener.Stop();
                m_BackgroundTweener.Stop();
            }
            currentChange = changeType;
            var shouldChangeLabel = changeType != LetterTileChange.ColorTweenOnly;
            WGBEvent.Invoke(m_OnTileChange, m_Language, this, null, null, null, null, () => SetDisplayState(shouldChangeColor, shouldChangeLabel, true), () => SetDisplayState(false, false, false));
            currentChange = LetterTileChange.NoChange;
        }
        void SetDisplayState(bool shouldChangeColor, bool shouldChangeLabel, bool shouldAnimate)
        {
            m_ShouldChangeColor = shouldChangeColor;
            m_ShouldChangeLabel = shouldChangeLabel;
            m_ShouldAnimate = shouldAnimate;
        }
        void TileSpawnEvent()
        {
            if (isActive)
            {
                m_TextTweener.currentValue = currentTextColorRaw;
                m_BackgroundTweener.currentValue = currentBackgroundColorRaw;
                m_TextTweener.Start(currentTextColorRaw, m_TweenInfo.duration, m_TweenInfo.delay, m_TweenInfo.easing);
                m_BackgroundTweener.Start(currentBackgroundColorRaw, m_TweenInfo.duration, m_TweenInfo.delay, m_TweenInfo.easing);
            }
            else
            {
                m_TextTweener.Stop();
                m_BackgroundTweener.Stop();
            }
            WGBEvent.Invoke(m_OnTileSpawn, m_Language, this, null, null, null, null);
        }
        void SetPointValues(int defaultPointVal, int currentPointVal)
        {
            m_DefaultPointValue = defaultPointVal;
            m_CurrentPointValue = currentPointVal;

            m_TileFlags &= ~TileStateFlags.Bonus;
            m_TileFlags &= ~TileStateFlags.Penalty;

            if (m_CurrentPointValue <= 0)
            {
                if (m_DisplayInfo.wildcardPenalty || (!m_WildcardLetter.hasValue && m_DefaultLetter.hasValue))
                    m_TileFlags |= TileStateFlags.Penalty;
            }
            else if (m_CurrentPointValue > m_DefaultPointValue)
            {
                if (m_DisplayInfo.wildcardBonus || (!m_WildcardLetter.hasValue && m_DefaultLetter.hasValue))
                    m_TileFlags |= TileStateFlags.Bonus;
            }
        }
        void ProcessWildcardTileManager()
        {
            m_Language = m_Language ?? WordGameLanguage.current;

            var players = m_SelectionInfo.GetPlayersInternal();

            var enumerator = players.GetEnumerator();

            while(enumerator.MoveNext())
            {
                var player = enumerator.Current;

                // If input is blocked, skip the player
                if (!player.inputEnabled)
                    continue;

                if (m_SelectionInfo.wildcardTileManager != null)
                    m_SelectionInfo.wildcardTileManager.SelectWildcardTile(this, m_Language, player);
                else
                    WGBBase.LogWarning("Attempting to process a wildcard tile, but no wildcard tile manager found!", "Word Game Builder", "LetterTile", this);
            }
        }
        bool CheckTileSelection(IList<ILetterTile> tiles, out bool shouldDeselect, bool modifyTileList)
        {
            shouldDeselect = false;

            ILetterTile thisTile = this;

            // If no tiles, add this tile to the player's list
            if (tiles == null || tiles.Count < 1)
            {
                if (modifyTileList && tiles != null)
                {
                    tiles.Add(thisTile);
                    ((ISelectableLetterTile)this).ForceSelectTile();
                }
                return true;
            }
            // If selectAnyTile and this tile isn't in the list
            // Also check max word length
            if (m_SelectionInfo.selectAnyTile)
            {
                if (!tiles.Contains(thisTile))
                {
                    if (tiles.Count < WordChecker.maxWordLength)
                    {
                        if (modifyTileList)
                        {
                            tiles.Add(thisTile);
                            ((ISelectableLetterTile)this).ForceSelectTile();
                        }
                        return true;
                    }
                    // Already at max word length
                    return false;
                }
                else
                {
                    shouldDeselect = true;
                    if (modifyTileList)
                    {
                        tiles.Remove(thisTile);
                        ((ISelectableLetterTile)this).ForceDeselectTile();
                    }
                    return true;
                }
            }
            if (tiles.Contains(thisTile))
            {
                if (modifyTileList)
                {
                    for (int j = tiles.Count - 1; j >= 0; --j)
                    {
                        var tile = tiles[j];
                        var selectableTile = tile as ISelectableLetterTile;

                        if (tile == null)
                            continue;

                        if (tiles[j] == thisTile)
                        {
                            tiles.RemoveAt(j);
                            if (selectableTile != null) selectableTile.ForceDeselectTile();
                            break;
                        }
                        tiles.RemoveAt(j);
                        if (selectableTile != null) selectableTile.ForceDeselectTile();
                    }
                }
                shouldDeselect = true;
                return true;
            }

            // Get the last selected tile
            var lastTile = tiles[tiles.Count - 1];
            // If the tile is within the max distance of the last tile, and the selection is less than the maximum word length, add it
            var dist = m_SelectionInfo.GetDistance(transform, lastTile.transform);
            if (dist <= m_SelectionInfo.maxDistance && tiles.Count < WordChecker.maxWordLength)
            {
                if (modifyTileList)
                {
                    tiles.Add(thisTile);
                    ((ISelectableLetterTile)this).ForceSelectTile();
                }
                return true;
            }

            return false;
        }
        void ProcessTileSelection()
        {
            var players = m_SelectionInfo.GetPlayersInternal();

            var enumerator = players.GetEnumerator();

            while(enumerator.MoveNext())
            {
                var player = enumerator.Current;

                // If input is blocked, skip the player
                if (!player.inputEnabled)
                    continue;

                // Modify the current player's tile selection
                ModifyTileSelection(player.selectedTiles);
            }
        }
        #endregion

        #region Serialized classes
        /// <summary>
        /// Represents a set of colors for a tile. Tiles have both a foreground and background color.
        /// </summary>
        [System.Serializable]
        public sealed class TileColor
        {
            [SerializeField] Color m_Text = Color.white;
            [SerializeField] Color m_Background = Color.white;

            /// <summary>
            /// Gets or sets the text color of the tile.
            /// </summary>
            public Color text { get { return m_Text; } set { m_Text = value; } }
            /// <summary>
            /// Gets or sets the background color of the tile.
            /// </summary>
            public Color background { get { return m_Background; } set { m_Background = value; } }
        }

        /// <summary>
        /// Represents a group of colors for different tile states.
        /// </summary>
        [System.Serializable]
        public sealed class TileStateColorGroup
        {
            [SerializeField] TileColor m_Normal;
            [SerializeField] TileColor m_Hover;
            [SerializeField] TileColor m_Selected;
            [SerializeField] TileColor m_Disabled;
            [SerializeField] TileColor m_SelectedAndDisabled;

            /// <summary>
            /// The colors to display when a tile is in a normal state.
            /// </summary>
            public TileColor normal { get { return m_Normal; } set { m_Normal = value; } }
            /// <summary>
            /// The colors to display when a tile is hovered.
            /// </summary>
            public TileColor hover { get { return m_Hover; } set { m_Hover = value; } }
            /// <summary>
            /// The colors to display when a tile is selected.
            /// </summary>
            public TileColor selected { get { return m_Selected; } set { m_Selected = value; } }
            /// <summary>
            /// The colors to display when a tile is disabled.
            /// </summary>
            public TileColor disabled { get { return m_Disabled; } set { m_Disabled = value; } }
            /// <summary>
            /// The colors to display when a tile is both selected and disabled.
            /// </summary>
            public TileColor selectedAndDisabled { get { return m_SelectedAndDisabled; } set { m_SelectedAndDisabled = value; } }
        }

        /// <summary>
        /// Represents color information for a letter tile.
        /// </summary>
        [System.Serializable]
        public sealed class ColorInfo
        {
            // Normal
            [SerializeField]
            TileStateColorGroup m_Standard;

            // Bonus
            [SerializeField]
            TileStateColorGroup m_Bonus;

            // Penalty
            [SerializeField]
            TileStateColorGroup m_Penalty;

            /// <summary>
            /// Controls how the tile should display colors normally.
            /// </summary>
            public TileStateColorGroup standard { get { return m_Standard; } set { m_Standard = value; } }
            /// <summary>
            /// Controls how the tile should display colors when in bonus mode.
            /// </summary>
            public TileStateColorGroup bonus { get { return m_Bonus; } set { m_Bonus = value; } }
            /// <summary>
            /// Controls how the tile should display colors when in penalty mode.
            /// </summary>
            public TileStateColorGroup penalty { get { return m_Penalty; } set { m_Penalty = value; } }

            /// <summary>
            /// Creates a set of color information with the default tile colors.
            /// </summary>
            public ColorInfo()
            {
                // Default colors
                m_Standard = new TileStateColorGroup();
                m_Bonus = new TileStateColorGroup();
                m_Penalty = new TileStateColorGroup();

                m_Standard.normal = new TileColor { text = new Color32(51, 37, 37, 255), background = Color.white };
                m_Standard.hover = new TileColor { text = new Color32(51, 37, 37, 255), background = new Color32(255, 115, 64, 255) };
                m_Standard.selected = new TileColor { text = Color.white, background = new Color32(137, 61, 34, 255) };
                m_Standard.disabled = new TileColor { text = Color.black * .75f, background = Color.white * .75f };
                m_Standard.selectedAndDisabled = new TileColor { text = Color.white * .75f, background = (Color)(new Color32(137, 61, 34, 255)) * .75f };

                m_Bonus.normal = new TileColor { text = new Color32(51, 37, 37, 255) * Color.green, background = Color.green };
                m_Bonus.hover = new TileColor { text = new Color32(51, 37, 37, 255) * Color.green, background = new Color32(255, 115, 64, 255) * Color.green};
                m_Bonus.selected = new TileColor { text = Color.green, background = new Color32(137, 61, 34, 255) * Color.green};
                m_Bonus.disabled = new TileColor { text = Color.black * .75f, background = Color.green * .75f };
                m_Bonus.selectedAndDisabled = new TileColor { text = Color.green * .75f, background = (Color)(new Color32(137, 61, 34, 255)) * Color.green * .75f };

                m_Penalty.normal = new TileColor { text = new Color32(51, 37, 37, 255) * Color.red, background = Color.red };
                m_Penalty.hover = new TileColor { text = new Color32(51, 37, 37, 255) * Color.red, background = new Color32(255, 115, 64, 255) * Color.red};
                m_Penalty.selected = new TileColor { text = Color.red, background = new Color32(137, 61, 34, 255) * Color.red};
                m_Penalty.disabled = new TileColor { text = Color.black * .75f, background = Color.red * .75f };
                m_Penalty.selectedAndDisabled = new TileColor { text = Color.green * .75f, background = (Color)(new Color32(137, 61, 34, 255)) * Color.green * .75f };
            }

            internal Color GetCurrentTextColor(bool isOver, bool isSelected, bool isDisabled, bool isBonus, bool isPenalty)
            {
                if (isSelected && isDisabled)
                    return isBonus ? bonus.selectedAndDisabled.text : isPenalty ? penalty.selectedAndDisabled.text : standard.selectedAndDisabled.text;

                if (isSelected)
                    return isBonus ? bonus.selected.text : isPenalty ? penalty.selected.text : standard.selected.text;

                if (isDisabled)
                    return isBonus ? bonus.disabled.text : isPenalty ? penalty.disabled.text : standard.disabled.text;

                if (isOver)
                    return isBonus ? bonus.hover.text : isPenalty ? penalty.hover.text : standard.hover.text;

                return isBonus ? bonus.normal.text : isPenalty ? penalty.normal.text : standard.normal.text;

            }

            internal Color GetCurrentBackgroundColor(bool isOver, bool isSelected, bool isDisabled, bool isBonus, bool isPenalty)
            {
                if (isSelected && isDisabled)
                    return isBonus ? bonus.selectedAndDisabled.background : isPenalty ? penalty.selectedAndDisabled.background : standard.selectedAndDisabled.background;

                if (isSelected)
                    return isBonus ? bonus.selected.background : isPenalty ? penalty.selected.background : standard.selected.background;

                if (isDisabled)
                    return isBonus ? bonus.disabled.background : isPenalty ? penalty.disabled.background : standard.disabled.background;

                if (isOver)
                    return isBonus ? bonus.hover.background : isPenalty ? penalty.hover.background : standard.hover.background;

                return isBonus ? bonus.normal.background : isPenalty ? penalty.normal.background : standard.normal.background;
            }
        }

        /// <summary>
        /// Represents selection information for a letter tile.
        /// </summary>
        [System.Serializable]
        public sealed class SelectionInfo
        {
            HashSet<IWordGamePlayer> m_Players = new HashSet<IWordGamePlayer>();
            IWildcardTileManager m_WildcardTileManager;

            [SerializeField] SelectionMode m_SelectionMode = SelectionMode.SelectOnPress;
            [SerializeField] bool m_SelectAnyTile;
            [SerializeField] float m_MaxDistance = 300;
            [SerializeField] DistanceSpace m_DistanceSpace = DistanceSpace.Pixel;
            [SerializeField] Camera m_ReferenceCamera;
            [SerializeField] bool m_ProcessWildcards = true;

            /// <summary>
            /// Gets or sets the current wildcard tile manager, used for selecting wildcard tiles.
            /// </summary>
            /// <remarks>
            /// If there is only one wildcard tile manager in the scene, this value does not have to be set.
            /// </remarks>
            public IWildcardTileManager wildcardTileManager
            {
                get
                {
                    FindWildcardTileManager();
                    return m_WildcardTileManager;
                }
                set
                {
                    m_WildcardTileManager = value;
                }
            }

            internal void FindWildcardTileManager()
            {
                if (m_WildcardTileManager == null)
                    m_WildcardTileManager = WGBBase.FindObjectOfTypeFromInterface<IWildcardTileManager>();
            }

            /// <summary>
            /// Adds a player that can select this tile, and that will be affected by a tile's selection.
            /// </summary>
            /// <param name='player'>The player to add.</param>
            /// <remarks>
            /// Letter tiles initialize with all active players by default.
            /// </remarks>
            /// <param name='player'>The player to add.</param>
            /// <returns><c>true</c> if the operation was successful, otherwise <c>false</c>.</returns>
            public bool AddPlayer(IWordGamePlayer player)
            {
                return m_Players.Add(player);
            }

            /// <summary>
            /// Removes a player that can select this tile, and that is currently affected by a tile's selection.
            /// </summary>
            /// <param name='player'>The player to remove.</param>
            /// <returns><c>true</c> if the operation was successful, otherwise <c>false</c>.</returns>
            public bool RemovePlayer(IWordGamePlayer player)
            {
                return m_Players.Remove(player);
            }

            /// <summary>
            /// Clears all players that can select this tile, and that are currently affected by a tile's selection.
            /// </summary>
            public void ClearPlayers()
            {
                m_Players.Clear();
            }

            /// <summary>
            /// Adds a player that can select this tile, and that will be affected by a tile's selection (by name).
            /// </summary>
            /// <param name='name'>The player name to add.</param>
            /// <returns><c>true</c> if the operation was successful, otherwise <c>false</c>.</returns>
            public bool AddPlayer(string name)
            {
                return AddPlayer(WordGamePlayer.FindPlayer(name));
            }

            /// <summary>
            /// Checks to see if a player can select this tile, and will affect a tile's selection.
            /// </summary>
            /// <param name='player'>The player to check.</param>
            /// <returns><c>true</c> if the player will affect a tile's selection, otherwise <c>false</c>.</returns>
            public bool ContainsPlayer(IWordGamePlayer player)
            {
                return m_Players.Contains(player);
            }

            /// <summary>
            /// Checks to see if a player can select this tile, and will affect a tile's selection (by name).
            /// </summary>
            /// <param name='name'>The player name to check.</param>
            /// <returns><c>true</c> if the player will affect a tile's selection, otherwise <c>false</c>.</returns>
            public bool ContainsPlayer(string name)
            {
                var enumerator = m_Players.GetEnumerator();

                while(enumerator.MoveNext())
                {
                    var player = enumerator.Current;

                    if (player != null && player.name == name)
                        return true;
                }

                return false;
            }

            /// <summary>
            /// Gets all players that can select this tile, and that will be affected by a tile's selection.
            /// </summary>
            /// <remarks>
            /// This allocates a new array.
            /// </remarks>
            /// <returns>An array containing all players affected by tile selection.</returns>
            public IWordGamePlayer[] GetPlayers()
            {
                var collection = GetPlayersInternal();

                return collection.ToArray();
            }

            internal ICollection<IWordGamePlayer> GetPlayersInternal()
            {
                return m_Players;
            }

            /// <summary>
            /// Adds all active players in the scene to this tile.
            /// </summary>
            public void AddAllPlayers()
            {
                var players = WordGamePlayer.GetAllPlayers();

                for (int i = 0; i < players.Length; ++i)
                {
                    AddPlayer(players[i]);
                }
            }

            /// <summary>
            /// Controls how the tile is selected.
            /// </summary>
            public SelectionMode selectionMode { get { return m_SelectionMode; } set { m_SelectionMode = value; } }
            /// <summary>
            /// If true, any tile can be selected in any order. If false, only tiles within maxDistance of the last tile can be selected.
            /// </summary>
            public bool selectAnyTile { get { return m_SelectAnyTile; } set { m_SelectAnyTile = value; } }
            /// <summary>
            /// The maximum distance between tiles for selection.
            /// </summary>
            /// <remarks>
            /// If selectAnyTile = false, only tiles within maxDistance of the last tile can be selected.
            /// </remarks>
            public float maxDistance { get { return m_MaxDistance; } set { m_MaxDistance = value; } }
            /// <summary>
            /// Controls how distance is calculated (pixel, local, or world space).
            /// </summary>
            public DistanceSpace distanceSpace { get { return m_DistanceSpace; } set { m_DistanceSpace = value; } }
            /// <summary>
            /// The reference camera for calculating tile distances in pixels. If not set, this defaults to the main camera.
            /// </summary>
            /// <remarks>
            /// This value is ignored if distances are calculated in world space.
            /// </remarks>
            public Camera referenceCamera { get { return m_ReferenceCamera; } set { m_ReferenceCamera = value; } }
            /// <summary>
            /// Whether or not the wildcard tile manager should be ignored when selecting a blank tile.
            /// </summary>
            /// <remarks>
            /// If true, then blank tiles will be selected normally.
            /// </remarks>
            public bool processWildcards { get { return m_ProcessWildcards; } set { m_ProcessWildcards = value; } }

            internal float GetDistance(Transform transform, Transform target)
            {
                if (transform == target)
                    return 0;

                Vector3 targetPosition = target.position;

                if (m_DistanceSpace == DistanceSpace.Local)
                    return Vector3.Distance(Vector3.zero, transform.InverseTransformPoint(targetPosition));

                Vector3 position = transform.position;
                float dist = Vector3.Distance(position, targetPosition);

                if (m_DistanceSpace == DistanceSpace.World)
                    return dist;

                Camera camera = m_ReferenceCamera ? m_ReferenceCamera : Camera.main;

                if (!camera)
                    return 0;

                // Get the screen coordinate of halfway point
                Vector3 half = Vector3.Lerp(position, targetPosition, .5f);

                var screenPos = camera.WorldToScreenPoint(half);
                var cameraTransform = camera.transform;
                Vector3 offset = screenPos;
                Vector3 worldCoord;

                // Offset by 1 pixel w, h
                if (screenPos.x > 0)
                    offset -= Vector3.right;
                else
                    offset += Vector3.right;

                if (screenPos.y > 0)
                    offset -= Vector3.up;
                else
                    offset += Vector3.up;

                // Get the world coordinate once offset.
                worldCoord = camera.ScreenToWorldPoint(offset);

                float pixelSize = (cameraTransform.InverseTransformPoint(half) - cameraTransform.InverseTransformPoint(worldCoord)).magnitude;
                return dist * pixelSize;
            }
        }

        /// <summary>
        /// Controls additional display settings for a letter tile.
        /// </summary>
        [System.Serializable]
        public sealed class DisplayInfo
        {
            [SerializeField] bool m_ShowZeroLabel;
            [SerializeField] bool m_WildcardPenalty;
            [SerializeField] bool m_WildcardBonus;

            /// <summary>
            /// If true, show a label when a tile has a point value of zero.
            /// </summary>
            public bool showZeroLabel { get { return m_ShowZeroLabel; } set { m_ShowZeroLabel = value; } }
            /// <summary>
            /// If true, wildcard tiles can have a penalty state.
            /// </summary>
            public bool wildcardPenalty { get { return m_WildcardPenalty; } set { m_WildcardPenalty = value; } }
            /// <summary>
            /// If true, wildcard tiles can have a bonus state.
            /// </summary>
            public bool wildcardBonus { get { return m_WildcardBonus; } set { m_WildcardBonus = value; } }
        }

        /// <summary>
        /// Controls tween settings for a letter tile.
        /// </summary>
        [System.Serializable]
        public sealed class TweenInfo
        {
            [SerializeField] float m_Duration = .25f;
            [SerializeField] float m_Delay;
            [SerializeField] Easing m_Easing = Easing.Linear;

            /// <summary>
            /// Gets or sets the duration of the tween action.
            /// </summary>
            public float duration { get { return m_Duration; } set { m_Duration = value; } }
            /// <summary>
            /// Gets or sets the delay before performing the tween action.
            /// </summary>
            public float delay { get { return m_Delay; } set { m_Delay = value; } }
            /// <summary>
            /// Gets or sets the easing of the tween action.
            /// </summary>
            public Easing easing { get { return m_Easing; } set { m_Easing = value; } }
        }
        #endregion

        #region Enumerations
        /// <summary>
        /// Controls how a tile is selected.
        /// </summary>
        public enum SelectionMode
        {
            /// <summary>
            /// The tile should never be selected, unless SelectTile is called directly.
            /// </summary>
            None,
            /// <summary>
            /// The tile should be selected on press events.
            /// </summary>
            SelectOnPress,
            /// <summary>
            /// The tile should be selected on click events.
            /// </summary>
            SelectOnClick
        }
        /// <summary>
        /// Controls how a tile's distance is calculated for selection.
        /// </summary>
        /// <remarks>
        /// Distance can be calculated in either pixel, local, or world spcace.
        /// </remarks>
        public enum DistanceSpace
        {
            /// <summary>
            /// Calculate tile distances in pixel space, relative to a reference camera.
            /// </summary>
            Pixel,
            /// <summary>
            /// Calculate tile distances in local space.
            /// </summary>
            Local,
            /// <summary>
            /// Calculate tile distances in world space.
            /// </summary>
            World
        }

        /// <summary>
        /// The type of change that invoked a tile change event.
        /// </summary>
        public enum LetterTileChange
        {
            /// <summary>
            /// No change has happened. This will never be set during a tile change event.
            /// </summary>
            NoChange,
            /// <summary>
            /// The tile was enabled.
            /// </summary>
            Enabled,
            /// <summary>
            /// The tile was disabled.
            /// </summary>
            Disabled,
            /// <summary>
            /// The tile was selected.
            /// </summary>
            Selected,
            /// <summary>
            /// The tile was deselected.
            /// </summary>
            Deselected,
            /// <summary>
            /// The tile was hovered over.
            /// </summary>
            Hovered,
            /// <summary>
            /// The tile is no longer hovered over.
            /// </summary>
            Unhovered,
            /// <summary>
            /// Both the letter and score has changed.
            /// </summary>
            LetterAndScoreChanged,
            /// <summary>
            /// The score has changed.
            /// </summary>
            ScoreChanged,
            /// <summary>
            /// The tile is currently tweening a color and no other change has happened.
            /// </summary>
            ColorTweenOnly
        }

        [System.Flags]
        enum TileStateFlags
        {
            None = 0,
            Hover = 0x01,
            Selected = 0x02,
            Bonus = 0x04,
            Penalty = 0x08
        }
        #endregion
    }
}
