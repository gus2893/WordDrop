// IWordGamePlayer.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using Thinksquirrel.WordGameBuilder.Gameplay;

namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining a word game player. Implementations must derive from MonoBehaviour in some form.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. However, it is recommended to use the WordGamePlayer class instead.
    /// </remarks>
    public interface IWordGamePlayer : IMonoBehaviour
    {
        /// <summary>
        /// Controls whether or not input has been enabled for this player.
        /// </summary>
        /// <remarks>
        /// It is the responsibilty of the letter tile to check for (or ignore) this value. This is handled automatically by the default LetterTile class.
        /// </remarks>
        bool inputEnabled { get; set; }
        /// <summary>
        /// The maximum amount of tiles that a player should hold.
        /// </summary>
        int maxTiles { get; set; }
        /// <summary>
        /// Should word checks be ordered?
        /// </summary>
        bool orderedWordCheck { get; set; }
        /// <summary>
        /// If orderedWordCheck = false and multiplyByPermutations = true, the score will be multiplied by the amount of words found.
        /// </summary>
        bool multiplyByPermutations { get; set; }
        /// <summary>
        /// Gets or sets the player's current score.
        /// </summary>
        int score { get; set; }
        /// <summary>
        /// Gets the player's high score.
        /// </summary>
        /// <remarks>
        /// Setting this value should automatically set a new high score, if it is higher than the previous high score.
        /// </remarks>
        int highScore { get; }
        /// <summary>
        /// Gets the player's last word.
        /// </summary>
        string lastWord { get; }
        /// <summary>
        /// Gets the score of the player's last word.
        /// </summary>
        int lastWordScore { get; }
        /// <summary>
        /// Gets the player's best word.
        /// </summary>
        string bestWord { get; }
        /// <summary>
        /// Gets the score of the player's best word.
        /// </summary>
        int bestWordScore { get; }
        /// <summary>
        /// Gets the list of held tiles.
        /// </summary>
        /// <remarks>
        /// Held tiles are tiles that belong to the player, but will not be submitted.
        /// </remarks>
        IList<ILetterTile> heldTiles { get; }
        /// <summary>
        /// Gets a list of the player's play tiles.
        /// </summary>
        /// <remarks>
        /// Play tiles are tiles that will be submitted for checking.
        /// </remarks>
        IList<ILetterTile> selectedTiles { get; }
        /// <summary>
        /// This event should fire whenever a word result is returned from a word check.
        /// </summary>
        WGBEvent onWordResult { get; set; }
        /// <summary>
        /// Gets the last word result. This value should be set before event callbacks.
        /// </summary>
        WordGameResult lastResult { get; }
        /// <summary>
        /// Resets all player data, and clears both selected and held tiles.
        /// </summary>
        void ResetAllData();
        /// <summary>
        /// Resets all player scores.
        /// </summary>
        void ResetAllScores();
        /// <summary>
        /// Resets the current score.
        /// </summary>
        void ResetScore();
        /// <summary>
        /// Resets the high score.
        /// </summary>
        void ResetHighScore();
        /// <summary>
        /// Resets the last word.
        /// </summary>
        void ResetLastWord();
        /// <summary>
        /// Resets the best word.
        /// </summary>
        void ResetBestWord();
        /// <summary>
        /// Attempts to select a tile. If the tile implements ISelectableLetterTile, this follows selection rules.
        /// </summary>
        /// <param name="tile">The tile to select.</param>
        /// <returns>True if the tile was selected; otherwise, false.</returns>
        bool SelectTile(ILetterTile tile);
        /// <summary>
        /// Attempts to deselect a tile. If the tile implements ISelectableLetterTile, this follows selection rules.
        /// </summary>
        /// <param name="tile">The tile to select.</param>
        /// <returns>True if the tile was deselected; otherwise, false.</returns>
        bool DeselectTile(ILetterTile tile);
        /// <summary>
        /// Clears the player's selected tiles. Also deselected them if they implement ISelectableLetterTile.
        /// </summary>
        void ClearSelection();
        /// <summary>
        /// Submits the word for checking against the current langauge's word list.
        /// </summary>
        /// <remarks>
        /// This method should be asynchronous.
        /// </remarks>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        AsyncTask SubmitWord();
    }
}
