// WildcardTileManager.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEngine;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using Thinksquirrel.WordGameBuilder.Internal;

namespace Thinksquirrel.WordGameBuilder.Gameplay
{
    /// <summary>
    /// A manager class for selecting wildcard tiles.
    /// </summary>
    /// <remarks>
    /// This component does not have any implementation on if/how wildcard tiles should be selected.
    /// It only sends a message to a target game object, which provides the implementation.
    /// </remarks>
    [AddComponentMenu("Word Game Builder/Gameplay/Wildcard Tile Manager")]
    [WGBDocumentationName("Thinksquirrel.WordGameBuilder.Gameplay.WildcardTileManager")]
    public sealed class WildcardTileManager : WGBBase, IWildcardTileManager
    {
        [SerializeField] WGBEvent m_OnWildcardTileSelect;

        /// <summary>
        /// This event fires when a selection attempt occurs on a blank tile.
        /// </summary>
        /// <remarks>
        /// Variables set:
        /// * WGBEvent.currentLanguage
        /// * WGBEvent.currentLetterTile
        /// * WGBEvent.currentWildcardTileManager
        /// * WGBEvent.currentPlayer
        ///
        /// Implements <see cref="Thinksquirrel.WordGameBuilder.ObjectModel.IWildcardTileManager.onWildcardTileSelect">IWildcardTileManager</see>.
        /// </remarks>
        public WGBEvent onWildcardTileSelect { get { return m_OnWildcardTileSelect; } set { m_OnWildcardTileSelect = value; } }

        public void SelectWildcardTile(ILetterTile tile, WordGameLanguage lang, IWordGamePlayer player)
        {
            WGBEvent.Invoke(m_OnWildcardTileSelect, lang, tile, null, this, player, null);
        }
    }
}
