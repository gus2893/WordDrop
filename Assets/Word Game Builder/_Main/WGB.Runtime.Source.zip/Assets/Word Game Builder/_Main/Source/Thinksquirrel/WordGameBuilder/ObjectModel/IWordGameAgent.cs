﻿// IWordGameAgent.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using Thinksquirrel.WordGameBuilder.Gameplay;

namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining a word game agent. Implementations must derive from MonoBehaviour in some form.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. However, it is recommended to use the WordGameAgent class instead.
    /// </remarks>
    public interface IWordGameAgent : IMonoBehaviour
    {
        /// <summary>
        /// This event should fire whenever the agent has found a set of words.
        /// </summary>
        WGBEvent onFindWords { get; set; }
        /// <summary>
        /// Gets the most recent search information found from the agent.
        /// </summary>
        AgentSearchInfo lastSearchInfo { get; }
        /// <summary>
        /// Finds a set of words, based on the player's current held tiles.
        /// </summary>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        AsyncTask FindWords();
        /// <summary>
        /// Finds a set of words, based on a list of letter tiles.
        /// </summary>
        /// <param name="tiles">A list of letter tiles to use when searching for words.</param>
        /// <returns>
        /// An object representing an asynchronous task.
        /// </returns>
        AsyncTask FindWords(IList<ILetterTile> tiles);
        /// <summary>
        /// Stops all actions currently in progress by the agent.
        /// </summary>
        void Stop();
    }
}
