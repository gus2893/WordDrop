// Parallel.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System;

namespace Thinksquirrel.WordGameBuilder.Internal.Threading
{   
    //! \cond PRIVATE
    public static class Parallel
    {
        static IThreadPool s_ThreadPool;
        static Type s_EventWaitHandleType;

        public static bool supportsMultipleThreads { get { return s_ThreadPool != null; } }
        
        public static void InitializeThreadPool(IThreadPool threadPool, Type eventWaitHandleType)
        {
            s_ThreadPool = threadPool;
            s_EventWaitHandleType = eventWaitHandleType;
        }

        public static IEventWaitHandle CreateEventWaitHandle()
        {
            return Activator.CreateInstance(s_EventWaitHandleType) as IEventWaitHandle;
        }

        public static void SetPriority()
        {
            if (s_ThreadPool != null)
                s_ThreadPool.SetPriority();
        }

        public static int GetThreadCount()
        {
            return s_ThreadPool != null ? s_ThreadPool.GetThreadCount() : 0;
        }

        public static void Reset()
        {
            if (s_ThreadPool == null)
                return;
            
            s_ThreadPool.Dispose();
            s_ThreadPool = null;
        }

        public static void For(int iterations, ParallelAction action)
        {
            // No multithreaded support
            if (s_ThreadPool == null)
            {
                for (var i = 0; i < iterations; ++i) action(i);                
                return;
            }
            
            s_ThreadPool.For(iterations, action);
        }
        public static void RunInBackground(Action action)
        {
            // No multithreaded support
            if (s_ThreadPool == null)
            {
                action();
                return;
            }

            s_ThreadPool.RunInBackground(action);
        }
        public static void RunOnMainThread(Action action)
        {
            // No multithreaded support
            if (s_ThreadPool == null)
            {
                action();
                return;
            }

            s_ThreadPool.RunOnMainThread(action);
        }
    }
    //! \endcond
}
