// ILetterTile.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining a letter tile. Implementations must derive from MonoBehaviour in some form.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. However, it is recommended to use the LetterTile class instead.
    /// </remarks>
    public interface ILetterTile : IMonoBehaviour
    {
        /// <summary>
        /// The current point value of the tile.
        /// </summary>
        int currentPointValue { get; }
        /// <summary>
        /// The default point value of the tile.
        /// </summary>
        int defaultPointValue { get; }
        /// <summary>
        /// The current letter represented by the tile.
        /// </summary>
        /// <remarks>
        /// This will get either the default letter or wildcard letter, depending on which one is in use.
        /// </remarks>
        Letter currentLetter { get; }
        //! \cond PRIVATE
        [System.Obsolete("Use ILetterTile.defaultLetter instead")]
        Letter letter { get; }
        //! \endcond
        /// <summary>
        /// The default letter represented by the tile.
        /// </summary>
        Letter defaultLetter { get; }
        /// <summary>
        /// The wildcard letter represented by the tile.
        /// </summary>
        Letter wildcardLetter { get; }
        /// <summary>
        /// Is the tile currently active (spawned)?
        /// </summary>
        bool isActive { get; }
        /// <summary>
        /// This event should fire when a tile is spawned or despawned.
        /// </summary>
        WGBEvent onTileSpawn { get; set; }
        /// <summary>
        /// This event should fire when a tile's display should change in any way.
        /// </summary>
        WGBEvent onTileChange { get; set; }
        //! \cond PRIVATE
        [System.Obsolete("Use ILetterTile.ChangeDefaultLetter instead")]
        void ChangeLetter(Letter letter);
        //! \endcond
        /// <summary>
        /// Changes the default letter on a tile.
        /// </summary>
        /// <param name='letter'>The new default letter to assign to the tile.</param>
        /// <remarks>
        /// Changing the default letter will also reset the default score.
        /// </remarks>
        void ChangeDefaultLetter(Letter letter);
        /// <summary>
        /// Sets the wildcard letter on a tile.
        /// </summary>
        /// <param name='letter'>The letter to set as the wildcard letter.</param>
        void SetWildcard(Letter letter);
        /// <summary>
        /// Sets the wildcard letter on a tile, and changes its score to the specified score.
        /// </summary>
        /// <param name='letter'>The letter to set as the wildcard letter.</param>
        /// <param name='score'>The score to set for the wildcard tile.</param>
        void SetWildcard(Letter letter, int score);
        /// <summary>
        /// Remove the wildcard letter on a tile.
        /// </summary>
        void RemoveWildcard();
        /// <summary>
        /// This should control tile visibility, colliders, and triggers.
        /// </summary>
        void SpawnTile();
        /// <summary>
        /// This should control tile visibility, colliders, and triggers.
        /// </summary>
        void DespawnTile();
    }
}
