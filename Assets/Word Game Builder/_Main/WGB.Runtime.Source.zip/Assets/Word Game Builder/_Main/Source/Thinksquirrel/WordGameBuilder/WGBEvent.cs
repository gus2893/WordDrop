﻿// WGBEvent.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEngine;
using System.Collections.Generic;
using Thinksquirrel.WordGameBuilder.ObjectModel;
using System.Reflection;
using Thinksquirrel.WordGameBuilder.Internal;

namespace Thinksquirrel.WordGameBuilder
{
    /// <summary>
    /// Word game event delegate, for delegate-based events.
    /// </summary>
    public delegate void WGBEventDelegate();

    //! \cond PRIVATE
    [System.Serializable]
    sealed class WGBEventItem
    {
        [SerializeField] internal MonoBehaviour _target;
        [SerializeField] internal GameObject _targetGameObject;
        [SerializeField] internal string _methodName;

        [System.NonSerialized] internal WGBEventDelegate _cachedEvent;
        [System.NonSerialized] internal WGBEventDelegate _boundEvent;
        [System.NonSerialized] internal string _delegateName;
        [System.NonSerialized] internal bool _isDelegate;
    }
    //! \endcond

    /// <summary>
    /// A serializable class for event binding.
    /// </summary>
    /// <remarks>
    /// Events can be bound (public MonoBehaviour methods), use SendMessage (GameObject and method name), or use delegates.
    /// This class supports multicast events, and is safe (it will not throw exceptions for missing delegates or methods).
    /// </remarks>
    [System.Serializable]
    public sealed class WGBEvent
    {
        // Analysis disable FieldCanBeMadeReadOnly.Local
        [SerializeField] WGBEventItem m_Event = new WGBEventItem();
        [SerializeField] List<WGBEventItem> m_SerializedInvocationList = new List<WGBEventItem>();
        [System.NonSerialized] List<WGBEvent> m_InvocationList = new List<WGBEvent>();
        [System.NonSerialized] bool m_InitializedInvocationList;
        // Analysis restore FieldCanBeMadeReadOnly.Local

        /// <summary>
        /// The event target. In the case of multiple events, this is based on the first added value.
        /// </summary>
        /// <remarks>
        /// This value will be null for delegates not associated with a MonoBehaviour.
        /// </remarks>
        public MonoBehaviour target { get { return m_Event._target; } }
        /// <summary>
        /// The event target's GameObject. In the case of multiple events, this is based on the first added value.
        /// </summary>
        /// <remarks>
        /// This value will be null for delegates not associated with a Component.
        /// </remarks>
        public GameObject targetGameObject { get { return m_Event._targetGameObject; } }
        /// <summary>
        /// The event method name. In the case of multiple events, this is based on the first added value.
        /// </summary>
        /// <remarks>
        /// This value will be in the form of Type.Name or Type.{delegate} for delegates.
        /// </remarks>
        public string methodName { get { return m_Event._delegateName ?? m_Event._methodName; } }
        /// <summary>
        /// The event raw method name, without namespace or any other qualifiers. In the case of multiple events, this is based on the first added value.
        /// </summary>
        public string rawMethodName { get { return m_Event._methodName; } }

        internal List<WGBEvent> _invocationList
        {
            get
            {
                if (m_SerializedInvocationList == null)
                    m_SerializedInvocationList = new List<WGBEventItem>();

                if (m_InvocationList == null)
                {
                    m_InvocationList = new List<WGBEvent>();
                    m_InitializedInvocationList = false;
                }

                if (!m_InitializedInvocationList)
                {
                    for (int i = 0, l = m_SerializedInvocationList.Count; i < l; ++i)
                    {
                        m_InvocationList.Add(new WGBEvent(m_SerializedInvocationList [i]));
                    }

                    m_InitializedInvocationList = true;
                }

                return m_InvocationList;
            }
        }

        /// <summary>
        /// If true, this event is a delegate. In the case of multiple events, this is based on the first added value.
        /// </summary>
        public bool isDelegate
        {
            get { return m_Event._isDelegate; }
     	}

        bool m_IsChecked;

        #region Constructors
        /// <summary>
        /// Creates an event with a target MonoBehaviour and method name.
        /// </summary>
        /// <param name='target'>The MonoBehaviour with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        public WGBEvent(MonoBehaviour target, string methodName)
        {
            SetDelegate(target, methodName);
        }

        /// <summary>
        /// Creates an event with a target GameObject and method name (uses SendMessage).
        /// </summary>
        /// <param name='target'>The GameObject with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        public WGBEvent(GameObject target, string methodName)
        {
            SetDelegate(target, methodName);
        }

        /// <summary>
        /// Creates an event from a delegate.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        public WGBEvent(WGBEventDelegate del)
        {
            SetDelegate(del);
        }

        /// <summary>
        /// Creates an event from a delegate and an optional name.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        /// <param name='name'>The name of the delegate to search for.</param>
        public WGBEvent(WGBEventDelegate del, string name)
        {
            SetDelegate(del, name);
        }

        WGBEvent(WGBEventItem item)
        {
            m_Event._target = item._target;
            m_Event._targetGameObject = item._targetGameObject;
            m_Event._methodName = item._methodName;
            m_Event._cachedEvent = item._cachedEvent;
            m_Event._boundEvent = item._boundEvent;
            m_Event._delegateName = item._delegateName;
            m_Event._isDelegate = item._isDelegate;
        }
        #endregion

        #region Setting properties
        /// <summary>
        /// Sets the event with a MonoBehaviour and method name.
        /// </summary>
        /// <param name='target'>The MonoBehaviour with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        public void SetDelegate(MonoBehaviour target, string methodName)
        {
            m_Event._target = target;
            m_Event._targetGameObject = target ? target.gameObject : null;
            m_Event._methodName = methodName;
            m_Event._isDelegate = false;
            m_Event._cachedEvent = null;

            if (target)
            {
                BindDelegate(target, methodName);
            }
        }

        void BindDelegate(object target, string methodName)
        {
            var type = target.GetType();
            var methodInfo = type.ExtGetMethod(methodName);

            if (methodInfo != null)
            {
                m_Event._boundEvent = methodInfo.ExtCreateDelegate(typeof(WGBEventDelegate), target) as WGBEventDelegate;
                var typeString = type.ToString();
                var ns = type.Namespace;
                bool hasNs = !string.IsNullOrEmpty(ns);
                m_Event._delegateName = string.Format("{0}.{1}", hasNs ? typeString.Substring(ns.Length + 1) : typeString, methodName);
            }
        }

        /// <summary>
        /// Sets the event with a GameObject and method name (Uses SendMessage).
        /// </summary>
        /// <param name='target'>The GameObject with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        public void SetDelegate(GameObject target, string methodName)
        {
            m_Event._target = null;
            m_Event._targetGameObject = target;
            m_Event._methodName = methodName;
            m_Event._isDelegate = false;
            m_Event._delegateName = string.Format("{{SendMessage}}.{0}", methodName);
            m_Event._cachedEvent = null;
            m_Event._boundEvent = null;
        }

        /// <summary>
        /// Sets the event with a delegate.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        public void SetDelegate(WGBEventDelegate del)
        {
            SetDelegate(del, "{delegate}");
        }

        /// <summary>
        /// Sets the event with a delegate and an optional name.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        /// <param name='name'>The name of the delegate to search for.</param>
        public void SetDelegate(WGBEventDelegate del, string name)
        {
            if (del == null)
            {
                m_Event._target = null;
                m_Event._targetGameObject = null;
                m_Event._methodName = name;
                m_Event._isDelegate = true;
                m_Event._delegateName = null;
                m_Event._cachedEvent = null;
                m_Event._boundEvent = null;
                return;
            }

            var component = del.Target as Component;
            MonoBehaviour targ = null;
            string delegateName;

            if (component != null)
            {
                targ = component as MonoBehaviour;
                var type = component.GetType();
                var typeString = type.ToString();
                var ns = type.Namespace;
                bool hasNs = !string.IsNullOrEmpty(ns);
                delegateName = string.Format("{0}.{1}", hasNs ? typeString.Substring(ns.Length + 1) : typeString, name);
            }
            else
            {
                var type = del.Target != null ? del.Target.GetType() : del.GetType();
                var typeString = type.ToString();
                var ns = type.Namespace;
                bool hasNs = !string.IsNullOrEmpty(ns);
                delegateName = string.Format("{0}.{1}", hasNs ? typeString.Substring(ns.Length + 1) : typeString, name);
            }

            m_Event._target = targ;
            m_Event._targetGameObject = targ != null ? targ.gameObject : null;
            m_Event._methodName = name;
            m_Event._isDelegate = true;
            m_Event._delegateName = delegateName;
            m_Event._cachedEvent = del;
            m_Event._boundEvent = null;
        }

        /// <summary>
        /// Gets the raw delegate value.
        /// </summary>
        /// <returns>A .NET delegate for the event, or null if the delegate has not yet been bound, or SendMessage is being used.</returns>
        public WGBEventDelegate GetDelegate()
        {
            return m_Event._boundEvent ?? m_Event._cachedEvent;
        }
        #endregion

        #region Multicast
        /// <summary>
        /// Gets all individual events associated with this object.
        /// </summary>
        /// <remarks>
        /// Events are multicast - multiple events can be associated with a single object. This method gets all individual contained events.
        /// This allocates a new list.
        /// </remarks>
        /// <returns>A list of each event contained in this object.</returns>
        public IList<WGBEvent> GetInvocationList()
        {
            var result = new List<WGBEvent>();

            m_IsChecked = false;

            GetInvocationListRecursive(result);

            return result;
        }

        void GetInvocationListRecursive(List<WGBEvent> result)
        {
            if (m_IsChecked)
                return;

            m_IsChecked = true;

            result.Add(this);

            for(int i = 0; i < _invocationList.Count; ++i)
            {
                _invocationList[i].GetInvocationListRecursive(result);
            }

            m_IsChecked = false;
        }

        /// <summary>
        /// Adds a MonoBehaviour and method name to this event.
        /// </summary>
        /// <param name='target'>The MonoBehaviour with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        public void Add(MonoBehaviour target, string methodName)
        {
            if (m_Event._target == null && m_Event._targetGameObject == null && string.IsNullOrEmpty(m_Event._methodName) && m_Event._cachedEvent == null)
            {
                SetDelegate(target, methodName);
            }
            else
            {
                var evt = new WGBEvent(target, methodName);
                _invocationList.Add(evt);
                m_SerializedInvocationList.Add(evt.m_Event);
            }
        }

        /// <summary>
        /// Adds a GameObject and method name to this event (Uses SendMessage).
        /// </summary>
        /// <param name='target'>The GameObject with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        public void Add(GameObject target, string methodName)
        {
            if (m_Event._target == null && m_Event._targetGameObject == null && string.IsNullOrEmpty(m_Event._methodName) && m_Event._cachedEvent == null)
            {
                SetDelegate(target, methodName);
            }
            else
            {
                var evt = new WGBEvent(target, methodName);
                _invocationList.Add(evt);
                m_SerializedInvocationList.Add(evt.m_Event);
            }
        }

        /// <summary>
        /// Adds a delegate to this event.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        public void Add(WGBEventDelegate del)
        {
            if (m_Event._target == null && m_Event._targetGameObject == null && string.IsNullOrEmpty(m_Event._methodName) && m_Event._cachedEvent == null)
            {
                SetDelegate(del);
            }
            else
            {
                var evt = new WGBEvent(del);
                _invocationList.Add(evt);
                m_SerializedInvocationList.Add(evt.m_Event);
            }
        }

        /// <summary>
        /// Adds a delegate to the event with an optional name.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        /// <param name='name'>The name of the delegate to search for.</param>
        public void Add(WGBEventDelegate del, string name)
        {
            if (m_Event._target == null && m_Event._targetGameObject == null && string.IsNullOrEmpty(m_Event._methodName) && m_Event._cachedEvent == null)
            {
                SetDelegate(del, name);
            }
            else
            {
                var evt = new WGBEvent(del, name);
                _invocationList.Add(evt);
                m_SerializedInvocationList.Add(evt.m_Event);
            }
        }

        /// <summary>
        /// Remove the first instance of an event by MonoBehaviour and method name.
        /// </summary>
        /// <param name='target'>The MonoBehaviour with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        /// <returns><c>true</c> if the event was successfully removed, otherwise <c>false</c>.</returns>
        public bool Remove(MonoBehaviour target, string methodName)
        {
            m_IsChecked = false;
            bool found = false;

            RemoveRecursive(target, target ? target.gameObject : null, methodName, null, false, ref found, null, null);
            return found;
        }

        /// <summary>
        /// Remove the first instance of an event by GameObject and method name.
        /// </summary>
        /// <param name='target'>The GameObject with the method to search for.</param>
        /// <param name='methodName'>The name of the method to search for.</param>
        /// <returns><c>true</c> if the event was successfully removed, otherwise <c>false</c>.</returns>
        public bool Remove(GameObject target, string methodName)
        {
            m_IsChecked = false;
            bool found = false;

            RemoveRecursive(null, target, methodName, null, false, ref found, null, null);
            return found;
        }

        /// <summary>
        /// Remove the first instance of an event by a delegate.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        /// <returns><c>true</c> if the event was successfully removed, otherwise <c>false</c>.</returns>
        public bool Remove(WGBEventDelegate del)
        {
            m_IsChecked = false;
            bool found = false;

            RemoveRecursive(null, null, "{delegate}", del, true, ref found, null, null);
            return found;
        }

        /// <summary>
        /// Remove the first instance of an event by a delegate and name.
        /// </summary>
        /// <param name='del'>The delegate to search for.</param>
        /// <param name='name'>The name of the delegate to search for.</param>
        /// <returns><c>true</c> if the event was successfully removed, otherwise <c>false</c>.</returns>
        public bool Remove(WGBEventDelegate del, string name)
        {
            m_IsChecked = false;
            bool found = false;

            RemoveRecursive(null, null, name, del, true, ref found, null, null);
            return found;
        }

        /// <summary>
        /// Remove the first instance of an event.
        /// </summary>
        /// <param name='evt'>The event to remove.</param>
        /// <returns><c>true</c> if the event was successfully removed, otherwise <c>false</c>.</returns>
        public bool Remove(WGBEvent evt)
        {
            m_IsChecked = false;
            bool found = false;

            RemoveRecursive(evt, ref found, null, null);
            return found;
        }

        void RemoveRecursive(WGBEvent evt, ref bool found, ICollection<WGBEvent> list, ICollection<WGBEventItem> serializedList)
        {
            if (found)
            {
                m_IsChecked = false;
                return;
            }

            if (m_IsChecked)
                return;

            m_IsChecked = true;

            if (this == evt)
            {
                m_Event._target = null;
                m_Event._targetGameObject = null;
                m_Event._methodName = null;
                m_Event._isDelegate = false;
                m_Event._delegateName = null;
                m_Event._cachedEvent = null;

                if (list != null && serializedList != null)
                {
                    list.Remove(this);
                    serializedList.Remove(m_Event);
                }

                m_IsChecked = false;
                found = true;

                return;
            }

            for(int i = _invocationList.Count - 1; i >= 0; --i)
            {
                _invocationList[i].RemoveRecursive(evt, ref found, _invocationList, m_SerializedInvocationList);
            }

            m_IsChecked = false;
        }

        void RemoveRecursive(MonoBehaviour target, GameObject targetObj, string methodName, WGBEventDelegate del, bool isDelegate, ref bool found, ICollection<WGBEvent> list, ICollection<WGBEventItem> serializedList)
        {
            if (found)
            {
                m_IsChecked = false;
                return;
            }

            if (m_IsChecked)
                return;

            m_IsChecked = true;

            if (((target == m_Event._target && m_Event._targetGameObject == targetObj) || isDelegate) && (methodName == m_Event._methodName || (string.IsNullOrEmpty(methodName) && string.IsNullOrEmpty(m_Event._methodName))) && del == m_Event._cachedEvent)
            {
                m_Event._target = null;
                m_Event._targetGameObject = null;
                m_Event._methodName = null;
                m_Event._isDelegate = false;
                m_Event._delegateName = null;
                m_Event._cachedEvent = null;

                if (list != null && serializedList != null)
                {
                    list.Remove(this);
                    serializedList.Remove(m_Event);
                }

                m_IsChecked = false;
                found = true;

                return;
            }

            for(int i = _invocationList.Count - 1; i >= 0; --i)
            {
                _invocationList[i].RemoveRecursive(target, targetObj, methodName, del, isDelegate, ref found, _invocationList, m_SerializedInvocationList);
            }

            m_IsChecked = false;
        }
        #endregion

        #region Invocation
        /// <summary>
        /// Invokes the event directly. This will never run outside of play mode.
        /// </summary>
        /// <remarks>
        /// When an event is invoked directly, state variables are not set.
        /// </remarks>
        public void Invoke()
        {
            if (!Application.isPlaying)
                return;

            m_IsChecked = false;

            InvokeRecursive();
        }

        /// <summary>
        /// Invokes the event directly. This can run in the editor, and therefore corrupt state! Use carefully.
        /// </summary>
        /// <remarks>
        /// When an event is invoked directly, state variables are not set.
        /// </remarks>
        public void InvokeUnsafe()
        {
            m_IsChecked = false;

            InvokeRecursive();
        }

        void InvokeRecursive()
        {
            if (m_IsChecked)
                return;

            m_IsChecked = true;

            DoInvoke();

            for(int i = 0; i < _invocationList.Count; ++i)
            {
                _invocationList[i].InvokeRecursive();
            }

            m_IsChecked = false;
        }

        void DoInvoke()
        {
            if (m_Event._boundEvent != null)
            {
                m_Event._boundEvent();
            }
            else if (m_Event._target != null && !isDelegate)
            {
                BindDelegate(m_Event._target, m_Event._methodName);

                if (m_Event._boundEvent != null)
                {
                    m_Event._boundEvent();
                }
            }
            else if (isDelegate && m_Event._cachedEvent != null)
            {
                if (m_Event._delegateName == null)
                {
                    var type = m_Event._cachedEvent.Target != null ? m_Event._cachedEvent.Target.GetType() : m_Event._cachedEvent.GetType();
                    var typeString = type.ToString();
                    var ns = type.Namespace;
                    bool hasNs = !string.IsNullOrEmpty(ns);
                    m_Event._delegateName = string.Format("{0}.{1}", hasNs ? typeString.Substring(ns.Length + 1) : typeString, m_Event._methodName);
                }
                m_Event._cachedEvent();
            }
            else
            {
                if (m_Event._targetGameObject && !string.IsNullOrEmpty(m_Event._methodName))
                {
                    if (m_Event._delegateName == null) m_Event._delegateName = string.Format("{{SendMessage}}.{0}", m_Event._methodName);
                    m_Event._targetGameObject.SendMessage(m_Event._methodName, SendMessageOptions.DontRequireReceiver);
                }
            }
        }
        #endregion

        #region Operators
        bool IsValid()
        {
            return m_SerializedInvocationList.Count > 0 || (isDelegate && m_Event._cachedEvent != null) || (m_Event._target && !string.IsNullOrEmpty(m_Event._methodName));
        }

        /// <summary>
        /// Boolean operator. Returns true if the event is both not null and not empty.
        /// </summary>
        /// <param name='e'>The event to test.</param>
        /// <returns><c>true</c> if the event is both null and not empty, otherwise <c>false</c>.</returns>
        public static implicit operator bool (WGBEvent e)
        {
            return e != null && e.IsValid();
        }
        /// <summary>
        /// Add operator. Provides .NET-like syntax for adding delegates to an event (on____ += myDelegate).
        /// </summary>
        /// <param name='e'>The event to add to.</param>
        /// <param name='del'>The delegate to add to the event.</param>
        /// <returns>The event that was added to. This is the same object passed on the left hand side of the expression.</returns>
        public static WGBEvent operator +(WGBEvent e, WGBEventDelegate del)
        {
            e.Add(del);
            return e;
        }
        /// <summary>
        /// Subtract operator. Provides .NET-like syntax for removing delegates from an event (on___ -= myDelegate).
        /// </summary>
        /// <param name='e'>The event to remove from..</param>
        /// <param name='del'>The delegate to remove from the event.</param>
        /// <returns>The event that was removed from. This is the same object passed on the left hand side of the expression.</returns>
        public static WGBEvent operator -(WGBEvent e, WGBEventDelegate del)
        {
            e.Remove(del);
            return e;
        }
        #endregion

        #region State
        static bool s_IsInvoking;
        static readonly Queue<WGBEventState> s_EventQueue = new Queue<WGBEventState>();
        /// <summary>
        /// Gets the current language. This can only be used during event callbacks, for events invoked with the static Invoke method.
        /// </summary>
        public static WordGameLanguage currentLanguage { get; private set; }
        /// <summary>
        /// Gets the current letter tile. This can only be used during event callbacks, for events invoked with the static Invoke method.
        /// </summary>
        public static ILetterTile currentLetterTile { get; private set; }
        /// <summary>
        /// Gets the current tile pool. This can only be used during event callbacks, for events invoked with the static Invoke method.
        /// </summary>
        public static ITilePool currentTilePool { get; private set; }
        /// <summary>
        /// Gets the current wildcard tile manager. This can only be used during event callbacks, for events invoked with the static Invoke method.
        /// </summary>
        public static IWildcardTileManager currentWildcardTileManager { get; private set; }
        /// <summary>
        /// Gets the current player. This can only be used during event callbacks, for events invoked with the static Invoke method.
        /// </summary>
        public static IWordGamePlayer currentPlayer { get; private set; }
        /// <summary>
        /// Gets the current agent. This can only be used during event callbacks, for events invoked with the static Invoke method.
        /// </summary>
        public static IWordGameAgent currentAgent { get; private set; }
        /// <summary>
        /// Invoke an event with the current event state.
        /// </summary>
        /// <remarks>
        /// Events that are invoked during other event callbacks are deferred into a queue until the current event is finished.
        /// </remarks>
        /// <param name='evt'>The event to invoke.</param>
        /// <param name='currentLanguage'>The current language (defaults to Language.current).</param>
        /// <param name='currentLetterTile'>The current letter tile, if any.</param>
        /// <param name='currentTilePool'>The current tile pool, if any.</param>
        /// <param name='currentWildcardTileManager'>The current wildcard tile manager, if any.</param>
        /// <param name='currentPlayer'>The current player, if any.</param>
        /// <param name='currentAgent'>The current agent, if any.</param>
        /// <param name='additionalPreCallback'>An additional action that is run just before the event actually occurs.</param>
        /// <param name='additionalPostCallback'>An additional action that is run just after the event actually occurs.</param>
        public static void Invoke(WGBEvent evt,
                                  WordGameLanguage currentLanguage,
                                  ILetterTile currentLetterTile,
                                  ITilePool currentTilePool,
                                  IWildcardTileManager currentWildcardTileManager,
                                  IWordGamePlayer currentPlayer,
                                  IWordGameAgent currentAgent,
                                  System.Action additionalPreCallback = null,
                                  System.Action additionalPostCallback = null)
        {
            if (s_IsInvoking)
            {
                s_EventQueue.Enqueue(new WGBEventState
                 {
                    evt = evt,
                    currentLanguage = currentLanguage,
                    currentLetterTile = currentLetterTile,
                    currentTilePool = currentTilePool,
                    currentWildcardTileManager = currentWildcardTileManager,
                    currentPlayer = currentPlayer,
                    currentAgent = currentAgent
                });
                return;
            }
            s_IsInvoking = true;
            if (evt)
            {
                WGBEvent.currentLanguage = (bool)currentLanguage ? currentLanguage : WordGameLanguage.current;
                WGBEvent.currentLetterTile = currentLetterTile;
                WGBEvent.currentTilePool = currentTilePool;
                WGBEvent.currentWildcardTileManager = currentWildcardTileManager;
                WGBEvent.currentPlayer = currentPlayer;
                WGBEvent.currentAgent = currentAgent;
                if (additionalPreCallback != null)
                    additionalPreCallback();
                evt.Invoke();
                if (additionalPostCallback != null)
                    additionalPostCallback();
                WGBEvent.currentLanguage = null;
                WGBEvent.currentLetterTile = null;
                WGBEvent.currentTilePool = null;
                WGBEvent.currentWildcardTileManager = null;
                WGBEvent.currentPlayer = null;
                WGBEvent.currentAgent = null;
            }
            while(s_EventQueue.Count > 0)
            {
                var eventState = s_EventQueue.Dequeue();

                if (eventState.evt)
                {
                    WGBEvent.currentLanguage = (bool)eventState.currentLanguage ? eventState.currentLanguage : WordGameLanguage.current;
                    WGBEvent.currentLetterTile = eventState.currentLetterTile;
                    WGBEvent.currentTilePool = eventState.currentTilePool;
                    WGBEvent.currentWildcardTileManager = eventState.currentWildcardTileManager;
                    WGBEvent.currentPlayer = eventState.currentPlayer;
                    WGBEvent.currentAgent = eventState.currentAgent;
                    if (additionalPreCallback != null)
                        additionalPreCallback();
                    eventState.evt.Invoke();
                    if (additionalPostCallback != null)
                        additionalPostCallback();
                    WGBEvent.currentLanguage = null;
                    WGBEvent.currentLetterTile = null;
                    WGBEvent.currentTilePool = null;
                    WGBEvent.currentWildcardTileManager = null;
                    WGBEvent.currentPlayer = null;
                    WGBEvent.currentAgent = null;
                }
            }
            s_IsInvoking = false;
        }
        #endregion
    }

    //! \cond PRIVATE
    struct WGBEventState
    {
        public WGBEvent evt;
        public WordGameLanguage currentLanguage;
        public ILetterTile currentLetterTile;
        public ITilePool currentTilePool;
        public IWildcardTileManager currentWildcardTileManager;
        public IWordGamePlayer currentPlayer;
        public IWordGameAgent currentAgent;
    }
    //! \endcond
}
