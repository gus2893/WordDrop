// WordGameResult.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;
using Thinksquirrel.WordGameBuilder.ObjectModel;

namespace Thinksquirrel.WordGameBuilder.Gameplay
{
    /// <summary>
    /// Represents a result from a word game lookup operation (WordChecker methods).
    /// </summary>
    /// <remarks>
    /// Note that this type is passed by value for performance reasons.
    /// </remarks>
    public struct WordGameResult
    {
        readonly string m_Input;
        readonly string m_Word;
        readonly IList<string> m_AllWords;
        readonly IList<ILetterTile> m_LetterTiles;
        readonly int m_Score;
        internal bool _isValid;
        readonly bool m_WasOrdered;
        readonly bool m_HasValue;

        /// <summary>
        /// All words returned from the lookup operation.
        /// </summary>
        public IList<string> allWords
        {
            get
            {
                return m_AllWords;
            }
        }

        /// <summary>
        /// Whether or not the result is empty.
        /// </summary>
        /// <remarks>
        /// This only returns false as a result of an invalid word lookup operation.
        /// </remarks>
        public bool hasValue
        {
            get
            {
                return m_HasValue;
            }
        }

        /// <summary>
        /// The input string for the lookup operation.
        /// </summary>
        /// <remarks>
        /// If the input is truncated, this still ruturns the full input string.
        /// </remarks>
        public string input
        {
            get
            {
                return m_Input;
            }
        }

        /// <summary>
        /// Whether or not the result is valid (at least one word was found).
        /// </summary>
        public bool isValid
        {
            get
            {
                return _isValid;
            }
        }

        /// <summary>
        /// A list of the input letter tiles for the lookup operation.
        /// </summary>
        /// <remarks>
        /// If the input is truncated, this still returns all input letter tiles.
        /// </remarks>
        public IList<ILetterTile> letterTiles
        {
            get
            {
                return m_LetterTiles;
            }
        }

        /// <summary>
        /// Gets the score total of the result.
        /// </summary>
        public int score
        {
            get
            {
                return m_Score;
            }
        }

        /// <summary>
        /// Whether or not the word lookup was an ordered search.
        /// </summary>
        public bool wasOrdered
        {
            get
            {
                return m_WasOrdered;
            }
        }

        /// <summary>
        /// The first word found in the lookup operation. Included for convenience.
        /// </summary>
        public string word
        {
            get
            {
                return m_Word;
            }
        }

        /// <summary>
        /// Represents an empty WordGameResult.
        /// </summary>
        /// <remarks>
        /// This is only created as a result of an invalid word lookup operation. Assigning a WordGameResult to this value is useful to invalidate previous results.
        /// </remarks>
        public static WordGameResult empty
        {
            get
            {
                return new WordGameResult();
            }
        }
        //! \cond PRIVATE
        internal WordGameResult(string input, string word, IList<string> allWords, IList<ILetterTile> letterTiles, int score, bool isValid, bool wasOrdered)
        {
            m_Input = input;
            m_Word = word;
            m_AllWords = allWords;
            m_LetterTiles = letterTiles;
            m_Score = score;
            _isValid = isValid;
            m_WasOrdered = wasOrdered;
            m_HasValue = true;
        }
        //\endcond
    }
}
