// ISelectableLetterTile.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Collections.Generic;

namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining a letter tile that can be selected and deselected. Implementations must derive from MonoBehaviour in some form.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. It is recommended to use the LetterTile class instead.
    /// </remarks>
    public interface ISelectableLetterTile : ILetterTile
    {
        /// <summary>
        /// Is this tile currently selected?
        /// </summary>
        bool isSelected { get; }
        /// <summary>
        /// This event should fire when a tile is selected or deselected and can be used to override a selection.
        /// </summary>
        WGBEvent onTileSelect { get; set; }
        /// <summary>
        /// Returns true if this tile can be selected based on a list of currently selected tiles.
        /// </summary>
        /// <param name='tiles'>A list representing currently selected tiles.</param>
        /// <param name='shouldDeselect'>If true, this tile should be deselected.</param>
        /// <returns><c>true</c> if the tile can be selected, otherwise <c>false</c></returns>
        bool CanSelectTile(IList<ILetterTile> tiles, out bool shouldDeselect);
        /// <summary>
        /// Returns true if the specified player can select this tile.
        /// </summary>
        /// <param name='player'>The player to check, to see if this tile can be selected.</param>
        /// <param name='shouldDeselect'>If true, this tile should be deselected.</param>
        /// <returns><c>true</c> if the tile can be selected, otherwise <c>false</c></returns>
        bool CanSelectTile(IWordGamePlayer player, out bool shouldDeselect);
        /// <summary>
        /// Modifies a list of selected tiles to include/remove the current tile, based on tile selection rules.
        /// </summary>
        /// <param name='tiles'>A list of tiles to modify.</param>
        /// <remarks>
        /// Selecting a tile would add to the list, while deselecting a tile would remove the tile from the list.
        /// Other tiles may also be modified.
        /// </remarks>
        void ModifyTileSelection(IList<ILetterTile> tiles);
        /// <summary>
        /// Selects the tile from a list of currently selected tiles, obeying rules for tile selection.
        /// </summary>
        /// <param name='tiles'>A list of tiles to modify.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        bool SelectTile(IList<ILetterTile> tiles);
        /// <summary>
        /// Deselects the tile from a list of currently selected tiles, obeying rules for tile selection.
        /// </summary>
        /// <param name='tiles'>A list of tiles to modify.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        bool DeselectTile(IList<ILetterTile> tiles);
        /// <summary>
        /// Selects the tile for a player, obeying rules for tile selection.
        /// </summary>
        /// <param name='player'>The player to check, to see if this tile can be selected.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        bool SelectTile(IWordGamePlayer player);
        /// <summary>
        /// Deselects the tile for a player, obeying rules for tile selection.
        /// </summary>
        /// <param name='player'>The player to check, to see if this tile can be deselected.</param>
        /// <returns><c>true</c> if the operation was successful; otherwise <c>false</c>.</returns>
        bool DeselectTile(IWordGamePlayer player);
        /// <summary>
        /// Selects the tile, ignoring tile selection rules.
        /// </summary>
        void ForceSelectTile();
        /// <summary>
        /// Deselects the tile, ignoring tile selection rules.
        /// </summary>
        void ForceDeselectTile();
    }
}
