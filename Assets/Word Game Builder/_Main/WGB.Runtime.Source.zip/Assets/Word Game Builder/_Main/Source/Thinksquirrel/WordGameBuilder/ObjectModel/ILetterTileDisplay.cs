﻿// ILetterTileDisplay.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEngine;

namespace Thinksquirrel.WordGameBuilder.ObjectModel
{
    /// <summary>
    /// An interface defining letter tile colors and labels.
    /// </summary>
    /// <remarks>
    /// Any implementation of this interface will work with other Word Game Builder classes. It is recommended to use the LetterTile class instead.
    /// </remarks>
    public interface ILetterTileDisplay : ILetterTile
    {
        /// <summary>
        /// The current text color for the tile.
        /// </summary>
        Color currentTextColor { get; }
        /// <summary>
        /// The current background color for the tile.
        /// </summary>
        Color currentBackgroundColor { get; }
        /// <summary>
        /// The current letter label for the tile.
        /// </summary>
        string currentLetterLabel { get; }
        /// <summary>
        /// The current score label for the tile.
        /// </summary>
        string currentScoreLabel { get; }
        /// <summary>
        /// Returns true if a tile should change color. This should only be set during change events.
        /// </summary>
        bool shouldChangeColor { get; }
        /// <summary>
        /// Returns true if a tile should change any label text. This should only be set during change events.
        /// </summary>
        bool shouldChangeLabel { get; }
        /// <summary>
        /// Returns true if a tile should animate. This should only be set during change events.
        /// </summary>
        bool shouldAnimate { get; }
    }
}
