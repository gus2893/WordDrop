﻿// ObjectPool.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.

using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;

namespace Thinksquirrel.WordGameBuilder.Internal
{
    sealed class ObjectPool<T> : IDisposable where T : class
    {       
        readonly Func<T> createFunction;
        readonly HashSet<T> pool;
        readonly Action<T> resetFunction;

        int m_Capacity;
        bool m_IsDisposed;

        public ObjectPool(Func<T> createFunction) : this(createFunction, null, 0) { }
        public ObjectPool(Func<T> create, Action<T> resetFunction) : this(create, resetFunction, 0) { }
        public ObjectPool(Func<T> create, int initialCapacity) : this(create, null, initialCapacity) { }
        public ObjectPool(Func<T> createFunction, Action<T> resetFunction, int initialCapacity)
        {
            this.createFunction = createFunction;
            this.resetFunction = resetFunction;
            pool = new HashSet<T>();
            AddItems(initialCapacity);
        }

        // Analysis disable InconsistentNaming
        public int Count
        {
            get
            {
                return pool.Count;
            }
        }

        public int Capacity
        {
            get
            {
                return m_Capacity;
            }
            set
            {
                lock(pool)
                {
                    m_Capacity = Math.Min(pool.Count, value);
                }
            }
        }

        public bool IsDisposed
        {
            get { return m_IsDisposed; }
        }
        // Analysis restore InconsistentNaming

        void Grow()
        {
            if (m_Capacity < 4)
            {
                AddItems(4 - m_Capacity);
            }
            else
            {
                AddItems(m_Capacity);
            }
        }

        void AddItems(int numItems)
        {
            for (var i = 0; i < numItems; i++)
            {
                var item = createFunction();
                pool.Add(item);
                m_Capacity++;
            }
        }
        
        public void Push(T item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            if (resetFunction != null)
            {
                resetFunction(item);
            }
            lock (pool)
            {
                pool.Add(item);
            }
        }
        
        public T Pop()
        {
            T item;
            lock (pool)
            {
                if (pool.Count == 0)
                {
                    Grow();
                }
                item = pool.First();
                pool.Remove(item);
            }
            return item;
        }
    
        #region IDisposable implementation
        public void Dispose()
        {
            if (m_IsDisposed)
                return;

            m_IsDisposed = true;
            var enumerator = pool.GetEnumerator();

            while (enumerator.MoveNext())
            {
                var item = enumerator.Current;

                var disposable = item as IDisposable;
                if (disposable != null) disposable.Dispose();
            }
        }
        #endregion
    }
}
