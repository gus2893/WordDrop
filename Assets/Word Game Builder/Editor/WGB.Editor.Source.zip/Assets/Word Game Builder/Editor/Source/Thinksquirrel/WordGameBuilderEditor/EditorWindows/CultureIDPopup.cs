﻿// CultureIDPopup.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using System.Globalization;
using Thinksquirrel.WordGameBuilder;
using UnityEditor;
using UnityEngine;
#pragma warning disable 618

namespace Thinksquirrel.WordGameBuilderEditor.EditorWindows
{
    /// <summary>
    /// A popup window for picking a culture ID in the language editor.
    /// </summary>
    public sealed class CultureIDPopup : EditorWindow
    {
        Vector2 m_ScrollPosition;
        CultureInfo[] m_CultureInfo;

        static CultureIDPopup s_Window;

        internal static bool popupEnabled { get { return s_Window; } }

        internal static void OpenPopup()
        {
            s_Window = ScriptableObject.CreateInstance<CultureIDPopup>();
            s_Window.title = "Pick a Culture ID";
            var mousePos = GUIUtility.GUIToScreenPoint(Event.current.mousePosition);
            s_Window.position = new Rect(mousePos.x, mousePos.y, 250, 400);
            s_Window.ShowPopup();
        }

        internal static void ClosePopup()
        {
            if (s_Window)
            {
                s_Window.Close();
                s_Window = null;
            }
        }

        void OnEnable()
        {
            m_CultureInfo = CultureInfo.GetCultures(CultureTypes.AllCultures);
            System.Array.Sort<CultureInfo>(m_CultureInfo, (c1, c2) => string.Compare(c1.NativeName, c2.NativeName, System.StringComparison.CurrentCulture));
        }

        void OnGUI()
        {
            minSize = new Vector2(300, 300);

            GUI.enabled = WordGameLanguage.current;

            GUILayout.Label("Select a culture:");

            GUILayout.BeginVertical(GUI.skin.box);
            m_ScrollPosition = GUILayout.BeginScrollView(
                m_ScrollPosition,
                false,
                false);

            for (int i = 0, l = m_CultureInfo.Length; i < l; ++i)
            {
                var culture = m_CultureInfo [i];
                if (GUILayout.Button(string.Format("{0}{1}", culture.NativeName, string.IsNullOrEmpty(culture.Name) ? string.Empty : string.Format( " [{0}]", culture.Name))))
                {
                    WordGameLanguage.current.SetCulture(culture.Name);
                    LanguageEditor.SaveLanguage(WordGameLanguage.current);
                    Close();
                }
            }
            GUILayout.EndScrollView();
            GUILayout.EndVertical();

            GUILayout.Space(10);

            GUI.enabled = true;

            if (GUILayout.Button("Cancel"))
                Close();
        }
    }
}