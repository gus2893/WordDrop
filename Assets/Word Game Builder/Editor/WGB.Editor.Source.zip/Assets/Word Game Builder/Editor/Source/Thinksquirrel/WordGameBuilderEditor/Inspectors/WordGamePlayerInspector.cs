// WordGamePlayerInspector.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEditor;
using Thinksquirrel.WordGameBuilder.Gameplay;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilderEditor.Inspectors
{
    [CustomEditor(typeof(WordGamePlayer))]
    [CanEditMultipleObjects]
    sealed class WordGamePlayerInspector : WGBInspectorBase
    {
        WordGamePlayer m_Player;
        
        void OnEnable()
        {
            m_Player = target as WordGamePlayer;
        }
        
        public override void OnInspectorGUI()
        {
            bool multipleSelection = targets.Length > 1;

            EditorGUILayout.LabelField("Score", multipleSelection ? "(Multiple objects selected)" : m_Player.score.ToString());
            EditorGUILayout.LabelField("High Score", multipleSelection ? "(Multiple objects selected)" : m_Player.highScore.ToString());
            if (!multipleSelection && m_Player.lastWordScore > 0)
            {
                EditorGUILayout.LabelField("Last Word", multipleSelection ? "(Multiple objects selected)" : string.Format("{0} ({1})", m_Player.lastWord, m_Player.lastWordScore));
            }
            else
            {
                EditorGUILayout.LabelField("Last Word", "");
            }
            if (!multipleSelection && m_Player.bestWordScore > 0)
            {
                EditorGUILayout.LabelField("Best Word", multipleSelection ? "(Multiple objects selected)" : string.Format("{0} ({1})", m_Player.bestWord, m_Player.bestWordScore));
            }
            else
            {
                EditorGUILayout.LabelField("Best Word", "");
            }

            DrawDefaultInspector();
        }
    }    
}
//! \endcond