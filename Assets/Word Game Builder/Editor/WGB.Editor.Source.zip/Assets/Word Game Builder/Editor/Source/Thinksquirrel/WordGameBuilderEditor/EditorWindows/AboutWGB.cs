// AboutWGB.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using Thinksquirrel.WordGameBuilder.Internal;
using UnityEditor;
using UnityEngine;

namespace Thinksquirrel.WordGameBuilderEditor.EditorWindows
{
    //! \cond PRIVATE
    sealed class AboutWGB : EditorWindow
    {
        Vector2 m_MinSize = new Vector2(350, 280);
        Vector2 m_MaxSize = new Vector2(350, 280);
        
        GUIContent m_Logo;
        
        [MenuItem(WGBMenuItems.menuWindowLocation + "/Word Game Builder/About Word Game Builder", false, 1202)]
        public static void Open()
        {
            GetWindow<AboutWGB>(true, "About Word Game Builder");
        }

        void OnGUI()
        {
            if (m_Logo == null)
            {
                m_Logo = new GUIContent(WGBEditorResources.wgb_logo);
            }
            GUILayout.BeginHorizontal(GUILayout.Height(128));
            GUILayout.Label(m_Logo);
            GUILayout.FlexibleSpace();
            GUILayout.BeginVertical();
            GUILayout.FlexibleSpace();
            GUILayout.Label("Version " + VersionInfo.version, EditorStyles.largeLabel);
            if (VersionInfo.isPreRelease)
            {
                GUILayout.Label(VersionInfo.version.Contains("a") ? "Alpha" : "Beta" + " Release",
                                EditorStyles.miniLabel);
            }
            GUILayout.FlexibleSpace();
            GUILayout.EndVertical();
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
            
            GUILayout.FlexibleSpace();
            var contentLink = WGBEditorHelpers.ContentLink();
            if (!VersionInfo.isPreRelease && !string.IsNullOrEmpty(contentLink))
            {
                if (GUILayout.Button("Subscribe to updates"))
                {
                    WGBMenuItems.RegisterWGB();
                }
                if (GUILayout.Button("Rate this package!"))
                {
                    Application.OpenURL("com.unity3d.kharma:" + contentLink);
                }
            }
            GUILayout.FlexibleSpace();
            GUI.color = new Color(0, .5f, .75f, 1);
            if (GUILayout.Button("Open source acknowledgments", EditorStyles.whiteLabel))
            {
                Application.OpenURL("https://support.thinksquirrel.com/hc/articles/202494100");
            }
            if (GUILayout.Button("Visit Thinksquirrel", EditorStyles.whiteLabel))
            {
                Application.OpenURL("https://assets.thinksquirrel.com");
            }
            GUILayout.FlexibleSpace();
            GUI.color = Color.white;
            GUILayout.Label("License: " + VersionInfo.license);
            GUILayout.Label(VersionInfo.copyright, EditorStyles.miniLabel);

            GUILayout.Space(14);

            minSize = m_MinSize;
            maxSize = m_MaxSize;
        }
    }
    //! \endcond
}
