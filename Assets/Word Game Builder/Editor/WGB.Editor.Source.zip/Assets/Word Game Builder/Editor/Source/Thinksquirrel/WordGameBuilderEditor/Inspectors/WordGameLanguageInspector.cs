﻿// WordGameLanguageInspector.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using Thinksquirrel.WordGameBuilder;
using Thinksquirrel.WordGameBuilderEditor.EditorWindows;
using UnityEditor;
using UnityEngine;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilderEditor.Inspectors
{
    [CustomEditor(typeof(WordGameLanguage))]
    sealed class WordGameLanguageInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            var language = (WordGameLanguage)target;
            GUILayout.Label(language.languageName);
            if (GUILayout.Button("Open Language Editor...", EditorStyles.miniButtonMid))
            {
                LanguageEditor._startLanguage = language;
                WGBMenuItems.OpenLanguageEditor();
            }
        }
    }
}
//! \endcond