// LetterTileColorControlInspector.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEditor;
using Thinksquirrel.WordGameBuilder.Tiles;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilderEditor.Inspectors
{
    [CustomEditor(typeof(LetterTileColorControl))]
    [CanEditMultipleObjects]
    sealed class LetterTileColorControlInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
        }
    }    
}
//! \endcond