// WordGameAgentInspector.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEditor;
using Thinksquirrel.WordGameBuilder.Gameplay;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilderEditor.Inspectors
{
    [CustomEditor(typeof(WordGameAgent))]
    [CanEditMultipleObjects]
    sealed class WordGameAgentInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
        }
    }    
}
//! \endcond