// LetterTileInspector.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using Thinksquirrel.WordGameBuilder;
using UnityEditor;
using UnityEngine;
using Thinksquirrel.WordGameBuilder.Tiles;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilderEditor.Inspectors
{
    [CustomEditor(typeof(LetterTile))]
    [CanEditMultipleObjects]
    sealed class LetterTileInspector : WGBInspectorBase
    {
        string m_NewLetter = "";

        LetterTile m_LetterTile;

        void OnEnable()
        {
            m_LetterTile = target as LetterTile;
        }

        public override void OnInspectorGUI()
        {
            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            GUILayout.Label("Letter Tile");
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();

            EditorGUILayout.Separator();

            if (targets.Length > 1)
            {
                EditorGUILayout.LabelField("Letter:", "Multiple objects selected");
            }
            else
            if (m_LetterTile.defaultLetter.hasValue)
            {
                EditorGUILayout.LabelField("Letter:", m_LetterTile.defaultLetter.text);
                EditorGUILayout.LabelField("Character:", m_LetterTile.defaultLetter.character.ToString());
                EditorGUILayout.LabelField("Default Point Value:", m_LetterTile.defaultPointValue.ToString());
                EditorGUILayout.LabelField("Current Point Value:", m_LetterTile.currentPointValue.ToString());
            }
            else
            {
                EditorGUILayout.LabelField("Letter:", "Blank");
            }

            if (GUILayout.Button("Randomize (Using Current Language)"))
            {
                try
                {
                    WGBEditorHelpers.LoadLanguageWithProgressBar(null, OnLanguageLoadRandomizeLetter, OnLanguageLoadCancel);
                }
                catch (System.Exception e)
                {
                    WGBBase.LogException(e, target);
                }
            }

            GUILayout.BeginHorizontal();
            m_NewLetter = EditorGUILayout.TextField("Change Letter", m_NewLetter);
            if (GUILayout.Button("Set", GUILayout.Width(80)))
            {
                try
                {
                    WGBEditorHelpers.LoadLanguageWithProgressBar(null, OnLanguageLoadChangeDefaultLetter, OnLanguageLoadCancel);
                }
                catch (System.Exception e)
                {
                    WGBBase.LogException(e, target);
                }
            }
            GUILayout.EndHorizontal();

            if (GUILayout.Button("Set to Blank"))
            {
                foreach (var targ in targets)
                {
                    var l = (LetterTile)targ;

                    l.ChangeDefaultLetter(Letter.empty);
                    EditorUtility.SetDirty(l);
                }
            }

            EditorGUILayout.Separator();

            DrawDefaultInspector();
        }

        void OnLanguageLoadChangeDefaultLetter()
        {
            if ((targets.Length > 1 || m_NewLetter != m_LetterTile.defaultLetter.text) && !string.IsNullOrEmpty(m_NewLetter))
            {
                foreach (var targ in targets)
                {
                    var l = (LetterTile)targ;

                    l.ChangeDefaultLetter(WordGameLanguage.current.GetLetter(m_NewLetter));
                    EditorUtility.SetDirty(l);
                }
            }
        }

        void OnLanguageLoadRandomizeLetter()
        {
            foreach (var targ in targets)
            {
                var l = (LetterTile)targ;

                l.ChangeDefaultLetter(WordGameLanguage.current.GetRandomLetter());
                EditorUtility.SetDirty(l);
            }
        }

        void OnLanguageLoadCancel()
        {
            WGBBase.LogError("Language load cancelled by user.", "Word Game Builder", "LetterTile", target);
        }
    }    
}
//! \endcond
