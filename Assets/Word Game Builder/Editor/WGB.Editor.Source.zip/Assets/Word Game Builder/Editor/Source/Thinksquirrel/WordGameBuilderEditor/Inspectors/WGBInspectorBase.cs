// WGBInspectorBase.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEditor;
using UnityEngine;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilderEditor.Inspectors
{
    public abstract class WGBInspectorBase : Editor
    {
        public new bool DrawDefaultInspector()
        {
            return DrawDefaultInspector(true);
        }

        public bool DrawDefaultInspector(bool drawEvents)
        {
            EditorGUI.BeginChangeCheck();
            serializedObject.Update();
            SerializedProperty iterator = serializedObject.GetIterator();
            bool enterChildren = true;
            while (iterator.NextVisible (enterChildren))
            {
                if (iterator.name == "m_Script" || iterator.name == "m_Target" || iterator.name == "m_TargetGameObject" || iterator.name == "m_MethodName" || iterator.name == "m_SerializedInvocationList")
                    continue;

                if (iterator.type == "WGBEvent")
                {
                    enterChildren = false;

                    if (!drawEvents)
                        continue;

                    WGBEditorHelpers.DrawEventInternal(iterator);

                    continue;
                }

                EditorGUILayout.PropertyField(iterator, true);
                enterChildren = false;
            }
            serializedObject.ApplyModifiedProperties();
            return EditorGUI.EndChangeCheck();
        }

        [MenuItem("CONTEXT/WGBBase/Help")]
        static void OpenHelp(MenuCommand command)
        {
            Application.OpenURL(WGBPreferences.ComponentUrl(command.context.GetType()));
        }

        [MenuItem("CONTEXT/WGBBase/API Reference")]
        static void OpenAPIReference(MenuCommand command)
        {
            Application.OpenURL(WGBPreferences.ScriptingUrl(command.context.GetType()));
        }

        [MenuItem("CONTEXT/WordGameLanguage/API Reference")]
        static void OpenLanguageAPIReference(MenuCommand command)
        {
            Application.OpenURL(WGBPreferences.ScriptingUrl(command.context.GetType()));
        }
    }    
}
//! \endcond
