// LetterTileMouseInputInspector.cs
// Copyright (c) 2011-2016 Thinksquirrel Inc.
using UnityEditor;
using Thinksquirrel.WordGameBuilder.Tiles;

//! \cond PRIVATE
namespace Thinksquirrel.WordGameBuilderEditor.Inspectors
{
    [CustomEditor(typeof(LetterTileMouseInput))]
    [CanEditMultipleObjects]
    sealed class LetterTileMouseInputInspector : WGBInspectorBase
    {
        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
        }
    }    
}
//! \endcond